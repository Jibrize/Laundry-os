import json
from typing import Optional, Any
from sqlmodel import Session
from app.models import AuditLog, User

def log(session: Session, business_id: int, actor: Optional[User],
        action: str, entity_type: str, entity_id: Optional[int] = None,
        before: Any = None, after: Any = None):
    session.add(AuditLog(
        business_id=business_id,
        actor_id=actor.id if actor else None,
        action=action, entity_type=entity_type, entity_id=entity_id,
        before_json=json.dumps(before, default=str) if before is not None else None,
        after_json=json.dumps(after, default=str) if after is not None else None,
    ))
