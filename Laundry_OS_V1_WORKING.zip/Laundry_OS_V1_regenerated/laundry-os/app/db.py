from sqlmodel import SQLModel, create_engine, Session, select
from app.config import settings

connect_args = {"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(settings.DATABASE_URL, echo=False, connect_args=connect_args)

def init_db():
    SQLModel.metadata.create_all(engine)
    # Lightweight migration for early prototype databases.
    # Safe to run repeatedly: legacy staff roles are collapsed into v1 roles.
    try:
        with Session(engine) as session:
            from app.models import User
            mapping = {"owner": "admin", "manager": "admin",
                       "cashier": "attendant", "worker": "attendant"}
            changed = False
            for user in session.exec(select(User)).all():
                if user.role in mapping:
                    user.role = mapping[user.role]
                    session.add(user)
                    changed = True
            if changed:
                session.commit()
    except Exception:
        # Fresh databases or unusual legacy schemas should still be able to start.
        pass

def get_session():
    with Session(engine) as session:
        yield session
