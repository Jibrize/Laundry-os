from typing import List
from fastapi import HTTPException

TERMINAL = {"completed", "cancelled"}

def index_of(stages: List[str], status: str) -> int:
    try:
        return stages.index(status)
    except ValueError:
        return -1

def validate_transition(stages: List[str], current: str, target: str):
    if target == "cancelled":
        if current in TERMINAL:
            raise HTTPException(400, f"Order already {current}")
        return
    if target not in stages:
        raise HTTPException(400, f"Unknown stage '{target}'")
    if current not in stages:
        raise HTTPException(400, f"Order is in unknown state '{current}'")
    if target == current:
        raise HTTPException(400, "Already in that stage")
    if index_of(stages, target) < index_of(stages, current):
        raise HTTPException(400, "Cannot move backwards. Use QC send-back instead.")
