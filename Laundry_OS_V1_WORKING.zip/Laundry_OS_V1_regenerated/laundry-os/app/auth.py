import hashlib
import secrets
from typing import Optional
from fastapi import Header, HTTPException, Depends
from sqlmodel import Session, select
from app.config import settings
from app.db import get_session
from app.models import User, Business

# Simple v1 role model. Customer accounts are separate from staff accounts.
ROLE_RANK = {"rider": 1, "attendant": 2, "admin": 3}

LEGACY_ROLE_MAP = {
    "owner": "admin",
    "manager": "admin",
    "cashier": "attendant",
    "worker": "attendant",
}

def canonical_role(role: str) -> str:
    return LEGACY_ROLE_MAP.get(role, role)

def hash_password(password: str, salt: str = None) -> str:
    salt = salt or settings.SECRET_SALT
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100_000).hex()

def new_api_key() -> str:
    return secrets.token_urlsafe(24)

def get_actor(x_api_key: Optional[str] = Header(None),
              session: Session = Depends(get_session)) -> Optional[User]:
    if not x_api_key:
        return None
    actor = session.exec(select(User).where(User.api_key == x_api_key,
                                            User.active == True)).first()
    if actor and actor.role in LEGACY_ROLE_MAP:
        actor.role = LEGACY_ROLE_MAP[actor.role]
        session.add(actor)
        session.commit()
    return actor

def current_user(actor: Optional[User] = Depends(get_actor)) -> User:
    if not actor:
        raise HTTPException(401, "Missing or invalid API key")
    return actor

def current_business(session: Session = Depends(get_session),
                      actor: User = Depends(current_user)) -> Business:
    b = session.get(Business, actor.business_id)
    if not b:
        raise HTTPException(500, "Business not found for user")
    return b

def require_role(min_role: str):
    min_role = canonical_role(min_role)
    def dep(actor: User = Depends(current_user)) -> User:
        role = canonical_role(actor.role)
        if role not in ROLE_RANK or ROLE_RANK[role] < ROLE_RANK.get(min_role, 0):
            raise HTTPException(403, f"Requires {min_role} access")
        return actor
    return dep
