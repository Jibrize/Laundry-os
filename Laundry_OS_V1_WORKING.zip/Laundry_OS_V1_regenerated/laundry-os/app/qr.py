from urllib.parse import quote

def order_qr_payload(business_id: int, order_code: str) -> str:
    return f"LAUNDRYOS:{business_id}:{order_code.lstrip('#')}"

def qr_image_url(payload: str, size: int = 200) -> str:
    return f"https://api.qrserver.com/v1/create-qr-code/?size={size}x{size}&data={quote(payload)}"
