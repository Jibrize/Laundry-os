from typing import Optional
from fastapi import APIRouter, Depends
from sqlmodel import Session, select
from app.db import get_session
from app.models import AuditLog, User, Business
from app.auth import current_business, require_role

router = APIRouter(prefix="/api/audit", tags=["audit"])

@router.get("")
def list_audit(entity_type: Optional[str] = None, actor_id: Optional[int] = None,
               limit: int = 200,
               session: Session = Depends(get_session),
               b: Business = Depends(current_business),
               actor=Depends(require_role("attendant"))):
    stmt = select(AuditLog).where(AuditLog.business_id == b.id)
    if entity_type: stmt = stmt.where(AuditLog.entity_type == entity_type)
    if actor_id: stmt = stmt.where(AuditLog.actor_id == actor_id)
    rows = session.exec(stmt.order_by(AuditLog.created_at.desc())
                        .limit(min(limit, 500))).all()
    out = []
    for r in rows:
        u = session.get(User, r.actor_id) if r.actor_id else None
        out.append({"id": r.id, "action": r.action, "entity_type": r.entity_type,
                    "entity_id": r.entity_id,
                    "actor_name": u.name if u else "system",
                    "actor_role": u.role if u else None,
                    "before": r.before_json, "after": r.after_json,
                    "created_at": r.created_at.isoformat()})
    return out
