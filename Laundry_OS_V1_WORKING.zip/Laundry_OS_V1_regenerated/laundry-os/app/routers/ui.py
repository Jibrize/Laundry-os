import os
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

router = APIRouter(tags=["ui"])
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
templates = Jinja2Templates(directory=os.path.join(BASE, "templates"))

@router.get("/", response_class=HTMLResponse)
def app_ui(request: Request):
    return templates.TemplateResponse("app.html", {"request": request})

@router.get("/book/{token}", response_class=HTMLResponse)
def book_page(request: Request, token: str):
    return templates.TemplateResponse("book.html", {"request": request})

@router.get("/customer", response_class=HTMLResponse)
def customer_page(request: Request):
    return templates.TemplateResponse("customer.html", {"request": request})
