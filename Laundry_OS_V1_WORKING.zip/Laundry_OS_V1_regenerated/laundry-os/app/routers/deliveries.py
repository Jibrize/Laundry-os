from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session, select
from app.db import get_session
from app.models import Delivery, Order, Customer, Business, User, IdempotencyKey
from app.schemas import DeliveryCreate, DeliveryUpdate
from app.auth import current_business, current_user, require_role
from app.audit import log

router = APIRouter(prefix="/api/deliveries", tags=["deliveries"])

@router.get("")
def list_deliveries(status: str = None, session: Session = Depends(get_session),
                    b: Business = Depends(current_business)):
    stmt = select(Delivery).where(Delivery.business_id == b.id)
    if status: stmt = stmt.where(Delivery.status == status)
    rows = session.exec(stmt.order_by(Delivery.created_at.desc())).all()
    out = []
    for d in rows:
        o = session.get(Order, d.order_id)
        c = session.get(Customer, o.customer_id) if o else None
        r = session.get(User, d.rider_id) if d.rider_id else None
        out.append({"id": d.id, "kind": d.kind, "status": d.status,
                    "order_code": o.code if o else None,
                    "customer_name": c.full_name if c else None,
                    "customer_phone": c.phone if c else None,
                    "rider_name": r.name if r else None,
                    "address": d.address, "fee": d.fee,
                    "scheduled_at": d.scheduled_at.isoformat() if d.scheduled_at else None})
    return out

@router.get("/me")
def my_jobs(session: Session = Depends(get_session), actor=Depends(current_user)):
    b = session.get(Business, actor.business_id)
    if actor.role not in ("rider", "admin"):
        raise HTTPException(403, "Only riders and managers see this")
    stmt = select(Delivery).where(Delivery.business_id == b.id,
                                    Delivery.status.notin_(["delivered", "cancelled"]))
    if actor.role == "rider": stmt = stmt.where(Delivery.rider_id == actor.id)
    rows = session.exec(stmt).all()
    out = []
    for d in rows:
        o = session.get(Order, d.order_id)
        c = session.get(Customer, o.customer_id) if o else None
        out.append({"id": d.id, "kind": d.kind, "status": d.status,
                    "order_code": o.code if o else None,
                    "address": d.address, "phone": d.phone or (c.phone if c else None),
                    "customer_name": c.full_name if c else None})
    return out

@router.post("", dependencies=[Depends(require_role("attendant"))])
def create_delivery(payload: DeliveryCreate,
                    session: Session = Depends(get_session),
                    b: Business = Depends(current_business),
                    actor=Depends(require_role("attendant"))):
    o = session.get(Order, payload.order_id)
    if not o or o.business_id != b.id: raise HTTPException(404, "Order not found")
    d = Delivery(business_id=b.id, **payload.dict())
    session.add(d); session.commit(); session.refresh(d)
    log(session, b.id, actor, "delivery_created", "delivery", d.id, after=payload.dict())
    session.commit()
    return d

@router.patch("/{did}", dependencies=[Depends(require_role("rider"))])
async def update_delivery(did: int, payload: DeliveryUpdate,
                           session: Session = Depends(get_session),
                           b: Business = Depends(current_business),
                           actor=Depends(require_role("rider"))):
    d = session.get(Delivery, did)
    if not d or d.business_id != b.id: raise HTTPException(404, "Delivery not found")
    if actor.role == "rider" and d.rider_id not in (None, actor.id):
        raise HTTPException(403, "Not your delivery")
    if actor.role == "rider" and d.rider_id is None and payload.status:
        d.rider_id = actor.id
    before = {k: getattr(d, k) for k in payload.dict(exclude_unset=True)}
    for k, v in payload.dict(exclude_unset=True).items(): setattr(d, k, v)
    d.updated_at = datetime.now(timezone.utc)
    if d.status == "delivered" and not d.delivered_at:
        d.delivered_at = datetime.now(timezone.utc)
    session.add(d)
    log(session, b.id, actor, "delivery_updated", "delivery", d.id,
        before=before, after=payload.dict(exclude_unset=True))
    session.commit(); session.refresh(d)
    if payload.status:
        from app.notifications import notify_delivery_status
        await notify_delivery_status(session, d, d.status)
    return d

class IdemDeliveryStatus(BaseModel):
    idempotency_key: str
    status: str

@router.post("/{did}/idempotent-status",
              dependencies=[Depends(require_role("rider"))])
async def idempotent_status(did: int, payload: IdemDeliveryStatus,
                             session: Session = Depends(get_session),
                             b: Business = Depends(current_business),
                             actor=Depends(require_role("rider"))):
    existing = session.exec(select(IdempotencyKey).where(
        IdempotencyKey.key == payload.idempotency_key)).first()
    if existing:
        d = session.get(Delivery, did)
        return {"ok": True, "duplicate": True, "status": d.status if d else None}
    d = session.get(Delivery, did)
    if not d or d.business_id != b.id: raise HTTPException(404, "Delivery not found")
    if actor.role == "rider" and d.rider_id not in (None, actor.id):
        raise HTTPException(403, "Not your delivery")
    if actor.role == "rider" and d.rider_id is None: d.rider_id = actor.id
    d.status = payload.status
    d.updated_at = datetime.now(timezone.utc)
    if d.status == "delivered" and not d.delivered_at:
        d.delivered_at = datetime.now(timezone.utc)
    session.add(d)
    session.add(IdempotencyKey(business_id=b.id, key=payload.idempotency_key,
                                action="delivery.status",
                                entity_type="delivery", entity_id=d.id))
    log(session, b.id, actor, "delivery_status_offline", "delivery", d.id,
        after={"status": payload.status})
    session.commit(); session.refresh(d)
    from app.notifications import notify_delivery_status
    await notify_delivery_status(session, d, d.status)
    return {"ok": True, "status": d.status}
