from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import PlainTextResponse
from sqlmodel import Session, select
from app.db import get_session
from app.models import (Business, WhatsAppNumber, WhatsAppSession,
                         WhatsAppMessage, Customer, Service, Order,
                         OrderItem, OrderStatusEvent, Delivery)
from app.pricing import build_order_items
from app.qr import order_qr_payload
from app.audit import log
from app.notifications import _send_whatsapp

router = APIRouter(prefix="/webhooks", tags=["whatsapp"])

@router.get("/whatsapp")
def verify(hub_mode: str = Query(None, alias="hub.mode"),
           hub_verify_token: str = Query(None, alias="hub.verify_token"),
           hub_challenge: str = Query(None, alias="hub.challenge"),
           session: Session = Depends(get_session)):
    if hub_mode != "subscribe": raise HTTPException(403, "Invalid")
    row = session.exec(select(WhatsAppNumber).where(
        WhatsAppNumber.verify_token == hub_verify_token,
        WhatsAppNumber.active == True)).first()
    if not row: raise HTTPException(403, "Unknown verify token")
    return PlainTextResponse(hub_challenge)

@router.post("/whatsapp")
async def receive(request: Request, session: Session = Depends(get_session)):
    body = await request.json()
    try:
        change = body["entry"][0]["changes"][0]["value"]
        meta = change.get("metadata", {})
        pid = meta.get("phone_number_id")
        if not pid: return {"ok": True}
        wa = session.exec(select(WhatsAppNumber).where(
            WhatsAppNumber.phone_number_id == pid,
            WhatsAppNumber.active == True)).first()
        if not wa: return {"ok": True}
        biz_id = wa.business_id
        msgs = change.get("messages", [])
        if not msgs: return {"ok": True}
        m = msgs[0]; msg_id = m["id"]; phone = m["from"]
        if session.exec(select(WhatsAppMessage).where(
                WhatsAppMessage.message_id == msg_id)).first():
            return {"ok": True}
        text = m.get("text", {}).get("body", "").strip() if m["type"] == "text" else ""
        session.add(WhatsAppMessage(business_id=biz_id, message_id=msg_id,
                                     direction="in", phone=phone, body=text))
        session.commit()
        await _handle(session, biz_id, phone, text, msg_id, pid)
    except Exception as e:
        print(f"WA webhook error: {e}")
    return {"ok": True}

async def _handle(session, biz_id, phone, text, msg_id, pid):
    b = session.get(Business, biz_id)
    sess = session.exec(select(WhatsAppSession).where(
        WhatsAppSession.business_id == biz_id,
        WhatsAppSession.phone == phone)).first()
    if not sess:
        sess = WhatsAppSession(business_id=biz_id, phone=phone, state="start", data={})
        session.add(sess); session.commit(); session.refresh(sess)

    state = sess.state; data = dict(sess.data or {})
    lower = text.lower()
    services = session.exec(select(Service).where(
        Service.business_id == biz_id, Service.active == True)).all()

    async def reply(msg):
        session.add(WhatsAppMessage(business_id=biz_id, message_id=f"out:{msg_id}",
                                     direction="out", phone=phone, body=msg))
        session.commit()
        await _send_whatsapp(phone, msg, pid)

    if lower in ("cancel", "reset", "menu", "hi", "hello", "start", ""):
        sess.state = "service"; sess.data = {}
        session.add(sess); session.commit()
        lines = [f"Welcome to {b.name}. What would you like?"]
        for i, s in enumerate(services[:8], 1):
            lines.append(f"{i}. {s.name} ({s.measurement} · {b.currency} {s.price})")
        lines.append("\nReply with the number.")
        await reply("\n".join(lines)); return

    if state == "service":
        try: s = services[int(lower) - 1]
        except (ValueError, IndexError):
            await reply("Please reply with a number from the list."); return
        data.update({"service_id": s.id, "service_name": s.name,
                      "measurement": s.measurement})
        sess.state = "quantity"; sess.data = data
        session.add(sess); session.commit()
        await reply(f"How many {s.measurement}? (e.g. 5)"); return

    if state == "quantity":
        try: qty = float(lower)
        except ValueError: await reply("Please enter a number."); return
        data["quantity"] = qty; sess.state = "pickup"; sess.data = data
        session.add(sess); session.commit()
        await reply("Pickup or drop-off? Reply 1 or 2."); return

    if state == "pickup":
        if lower in ("1", "pickup"): data["pickup"] = True
        elif lower in ("2", "drop", "dropoff"): data["pickup"] = False
        else: await reply("Reply 1 for pickup, 2 for drop-off."); return
        sess.state = "address"; sess.data = data
        session.add(sess); session.commit()
        await reply("Send your address for pickup." if data["pickup"]
                     else "Drop-off at our shop. Send your name."); return

    if state == "address":
        data["address"] = text; sess.state = "name"; sess.data = data
        session.add(sess); session.commit()
        await reply("Your full name?"); return

    if state == "name":
        data["full_name"] = text; sess.state = "confirm"; sess.data = data
        session.add(sess); session.commit()
        s = session.get(Service, data["service_id"])
        sub = max(data["quantity"] * s.price, s.min_charge or 0)
        await reply(f"Confirm:\n{data['full_name']} · {phone}\n"
                    f"{data['quantity']} {data['measurement']} {data['service_name']}\n"
                    f"Total: {b.currency} {sub:.2f}\n"
                    f"{'Pickup' if data['pickup'] else 'Drop-off'} · {data['address']}\n"
                    "Reply YES to confirm or NO to cancel."); return

    if state == "confirm":
        if lower in ("yes", "y"):
            await _finalize(session, b, phone, data, reply, pid)
            sess.state = "start"; sess.data = {}
            session.add(sess); session.commit()
        elif lower in ("no", "n"):
            sess.state = "start"; sess.data = {}
            session.add(sess); session.commit()
            await reply("Cancelled. Reply HI to start again.")
        else: await reply("Reply YES or NO.")
        return

    await reply("Reply HI to see the menu.")

async def _finalize(session, b, phone, data, reply, pid):
    customer = session.exec(select(Customer).where(
        Customer.business_id == b.id, Customer.phone == phone)).first()
    if not customer:
        customer = Customer(business_id=b.id, full_name=data["full_name"],
                             phone=phone, address=data.get("address"))
        session.add(customer); session.commit(); session.refresh(customer)
    class _I:
        def __init__(self, d): self.__dict__.update(d)
    items_in = [_I({"service_id": data["service_id"],
                     "quantity": data["quantity"], "notes": None})]
    items, sub = build_order_items(session, b.id, items_in)
    b.next_order_number += 1; session.add(b)
    code = f"#{b.next_order_number}"
    order = Order(business_id=b.id, code=code, customer_id=customer.id,
                   status=b.workflow_stages[0] if b.workflow_stages else "received",
                   subtotal=sub,
                   delivery_method="delivery" if data.get("pickup") else "pickup",
                   notes="Order placed via WhatsApp",
                   qr_payload=order_qr_payload(b.id, code))
    order.total = sub; order.balance = sub
    session.add(order); session.commit(); session.refresh(order)
    for it in items: it.order_id = order.id; session.add(it)
    session.add(OrderStatusEvent(order_id=order.id, to_status=order.status,
                                  note="Created via WhatsApp"))
    if data.get("pickup"):
        session.add(Delivery(business_id=b.id, order_id=order.id, kind="pickup",
                              address=data.get("address") or customer.address,
                              phone=customer.phone, status="pending"))
    log(session, b.id, None, "whatsapp_order_created", "order", order.id,
        after={"code": code})
    session.commit()
    from app.notifications import notify_order_created
    await notify_order_created(session, order)
    await reply(f"Order {code} created. Total {b.currency} {sub:.2f}. "
                f"We'll notify you when it's ready.")
