from datetime import datetime, timezone
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select

from app.db import get_session
from app.models import (Business, Customer, Order, Partnership,
                         PartnershipReferral, PartnershipCommission)
from app.schemas import (PartnershipCreate, PartnershipUpdate,
                          ReferralCreate, CommissionCreate)
from app.auth import current_business, require_role, current_user
from app.audit import log

router = APIRouter(prefix="/api/partnerships", tags=["partnerships"])

def _get_partnership(session: Session, pid: int, business_id: int) -> Partnership:
    p = session.get(Partnership, pid)
    if not p:
        raise HTTPException(404, "Partnership not found")
    if p.from_business_id != business_id and p.to_business_id != business_id:
        raise HTTPException(404, "Partnership not found")
    return p

@router.get("")
def list_partnerships(session: Session = Depends(get_session),
                        b: Business = Depends(current_business),
                        actor=Depends(require_role("attendant"))):
    rows = session.exec(select(Partnership).where(
        (Partnership.from_business_id == b.id) |
        (Partnership.to_business_id == b.id))
        .order_by(Partnership.created_at.desc())).all()
    out = []
    for p in rows:
        other_id = p.to_business_id if p.from_business_id == b.id else p.from_business_id
        other = session.get(Business, other_id)
        referrals = session.exec(select(PartnershipReferral).where(
            PartnershipReferral.partnership_id == p.id)).all()
        out.append({
            "id": p.id, "kind": p.kind, "status": p.status,
            "direction": "outbound" if p.from_business_id == b.id else "inbound",
            "partner": {"id": other.id, "name": other.name} if other else None,
            "revenue_split_pct": p.revenue_split_pct,
            "referral_count": len(referrals),
            "commission_owed": round(sum(r.commission_owed for r in referrals), 2),
            "commission_paid": round(sum(r.commission_paid for r in referrals), 2),
            "started_at": p.started_at.isoformat(),
        })
    return out

@router.post("", dependencies=[Depends(require_role("attendant"))])
def create_partnership(payload: PartnershipCreate,
                        session: Session = Depends(get_session),
                        b: Business = Depends(current_business),
                        actor=Depends(require_role("attendant"))):
    if payload.to_business_id == b.id:
        raise HTTPException(400, "Cannot partner with yourself")
    target = session.get(Business, payload.to_business_id)
    if not target:
        raise HTTPException(404, "Target business not found")
    if payload.revenue_split_pct < 0 or payload.revenue_split_pct > 100:
        raise HTTPException(400, "revenue_split_pct must be 0-100")

    existing = session.exec(select(Partnership).where(
        Partnership.from_business_id == b.id,
        Partnership.to_business_id == payload.to_business_id,
        Partnership.status.in_(["pending", "active"]))).first()
    if existing:
        raise HTTPException(400, "A partnership with this business already exists")

    p = Partnership(
        from_business_id=b.id, to_business_id=payload.to_business_id,
        kind=payload.kind, revenue_split_pct=payload.revenue_split_pct,
        status="pending", terms=payload.terms, created_by_id=actor.id,
    )
    session.add(p); session.commit(); session.refresh(p)
    log(session, b.id, actor, "partnership_created", "partnership", p.id,
        after={"to_business": p.to_business_id, "split": p.revenue_split_pct})
    session.commit()
    return p

@router.patch("/{pid}", dependencies=[Depends(require_role("attendant"))])
def update_partnership(pid: int, payload: PartnershipUpdate,
                        session: Session = Depends(get_session),
                        b: Business = Depends(current_business),
                        actor=Depends(require_role("attendant"))):
    p = _get_partnership(session, pid, b.id)
    # Accepting a partnership: only the receiving side can flip to active
    if payload.status == "active" and p.from_business_id == b.id and p.status == "pending":
        raise HTTPException(403, "Only the receiving business can accept")
    before = {k: getattr(p, k) for k in payload.dict(exclude_unset=True)}
    for k, v in payload.dict(exclude_unset=True).items():
        setattr(p, k, v)
    if payload.status == "ended" and not p.ended_at:
        p.ended_at = datetime.now(timezone.utc)
    session.add(p)
    log(session, b.id, actor, "partnership_updated", "partnership", p.id,
        before=before, after=payload.dict(exclude_unset=True))
    session.commit(); session.refresh(p)
    return p

@router.get("/{pid}/referrals")
def list_referrals(pid: int,
                    session: Session = Depends(get_session),
                    b: Business = Depends(current_business),
                    actor=Depends(require_role("attendant"))):
    p = _get_partnership(session, pid, b.id)
    rows = session.exec(select(PartnershipReferral).where(
        PartnershipReferral.partnership_id == p.id)
        .order_by(PartnershipReferral.referred_at.desc())).all()
    return rows

@router.post("/{pid}/referrals", dependencies=[Depends(require_role("attendant"))])
def create_referral(pid: int, payload: ReferralCreate,
                     session: Session = Depends(get_session),
                     b: Business = Depends(current_business),
                     actor=Depends(require_role("attendant"))):
    """
    Record that a customer of this business was referred to the partner.
    Only the phone number is shared across the two businesses.
    """
    p = _get_partnership(session, pid, b.id)
    if p.status != "active":
        raise HTTPException(400, f"Partnership is {p.status}")
    if p.from_business_id != b.id:
        raise HTTPException(403, "Only the referring business creates referrals")

    phone = payload.phone.strip()
    if not phone:
        raise HTTPException(400, "Phone required")

    existing = session.exec(select(PartnershipReferral).where(
        PartnershipReferral.partnership_id == p.id,
        PartnershipReferral.phone == phone)).first()
    if existing:
        raise HTTPException(400, "This phone is already referred on this partnership")

    # Snapshot of referring customer (may be None if they aren't a customer yet)
    from_customer = session.exec(select(Customer).where(
        Customer.business_id == b.id,
        Customer.phone == phone)).first()

    ref = PartnershipReferral(
        partnership_id=p.id,
        from_business_id=b.id, to_business_id=p.to_business_id,
        phone=phone,
        from_customer_id=from_customer.id if from_customer else None,
        to_customer_id=payload.to_customer_id,
        notes=payload.notes,
    )
    session.add(ref); session.commit(); session.refresh(ref)
    log(session, b.id, actor, "referral_created", "partnershipreferral", ref.id,
        after={"partnership": p.id, "phone": phone})
    session.commit()
    return ref

@router.post("/{pid}/referrals/{rid}/convert",
              dependencies=[Depends(require_role("attendant"))])
def convert_referral(pid: int, rid: int, revenue: float = 0.0,
                      session: Session = Depends(get_session),
                      b: Business = Depends(current_business),
                      actor=Depends(require_role("attendant"))):
    """The receiving business confirms the referral converted into an order."""
    p = _get_partnership(session, pid, b.id)
    if p.to_business_id != b.id:
        raise HTTPException(403, "Only the receiving business confirms conversion")
    ref = session.get(PartnershipReferral, rid)
    if not ref or ref.partnership_id != p.id:
        raise HTTPException(404, "Referral not found")
    if ref.status != "open":
        raise HTTPException(400, f"Referral is {ref.status}")

    to_customer = session.exec(select(Customer).where(
        Customer.business_id == b.id,
        Customer.phone == ref.phone)).first()

    ref.to_customer_id = to_customer.id if to_customer else None
    ref.first_order_at = datetime.now(timezone.utc)
    ref.revenue_attributed = round(revenue, 2)
    ref.commission_owed = round(revenue * p.revenue_split_pct / 100.0, 2)
    ref.status = "converted"
    session.add(ref)
    log(session, b.id, actor, "referral_converted",
        "partnershipreferral", ref.id,
        after={"revenue": ref.revenue_attributed,
               "commission": ref.commission_owed})
    session.commit(); session.refresh(ref)
    return ref

@router.post("/{pid}/commissions", dependencies=[Depends(require_role("admin"))])
def record_commission(pid: int, payload: CommissionCreate,
                       session: Session = Depends(get_session),
                       b: Business = Depends(current_business),
                       actor=Depends(require_role("admin"))):
    """Mark the commission as paid out. Called by the receiving business."""
    p = _get_partnership(session, pid, b.id)
    if p.from_business_id != b.id:
        raise HTTPException(403, "Only the referring business is paid")
    if payload.amount <= 0:
        raise HTTPException(400, "Amount must be positive")
    if p.status != "active":
        raise HTTPException(400, f"Partnership is {p.status}")

    now = datetime.now(timezone.utc)
    c = PartnershipCommission(
        partnership_id=p.id, amount=payload.amount,
        period_start=None, period_end=now,
        method=payload.method, reference=payload.reference,
        note=payload.note, recorded_by_id=actor.id,
    )
    session.add(c)

    # Mark converted referrals as paid, up to the amount
    remaining = payload.amount
    unconverted = session.exec(select(PartnershipReferral).where(
        PartnershipReferral.partnership_id == p.id,
        PartnershipReferral.status == "converted")
        .order_by(PartnershipReferral.first_order_at)).all()
    for ref in unconverted:
        owed = ref.commission_owed - ref.commission_paid
        if owed <= 0:
            continue
        take = min(owed, remaining)
        ref.commission_paid = round(ref.commission_paid + take, 2)
        if ref.commission_paid >= ref.commission_owed - 0.005:
            ref.status = "paid"
        remaining = round(remaining - take, 2)
        session.add(ref)
        if remaining <= 0:
            break

    log(session, b.id, actor, "commission_recorded", "partnershipcommission",
        None, after={"partnership": p.id, "amount": payload.amount})
    session.commit()
    return {"ok": True, "commission_id": c.id, "amount": payload.amount}

@router.get("/{pid}/summary")
def partnership_summary(pid: int,
                         session: Session = Depends(get_session),
                         b: Business = Depends(current_business),
                         actor=Depends(require_role("attendant"))):
    p = _get_partnership(session, pid, b.id)
    referrals = session.exec(select(PartnershipReferral).where(
        PartnershipReferral.partnership_id == p.id)).all()
    open_count = sum(1 for r in referrals if r.status == "open")
    converted_count = sum(1 for r in referrals if r.status == "converted")
    paid_count = sum(1 for r in referrals if r.status == "paid")
    revenue = round(sum(r.revenue_attributed for r in referrals), 2)
    owed = round(sum(r.commission_owed - r.commission_paid for r in referrals), 2)
    paid = round(sum(r.commission_paid for r in referrals), 2)
    return {
        "partnership_id": p.id,
        "kind": p.kind, "status": p.status,
        "revenue_split_pct": p.revenue_split_pct,
        "referrals": {
            "total": len(referrals),
            "open": open_count,
            "converted": converted_count,
            "paid": paid_count,
        },
        "revenue_attributed": revenue,
        "commission_owed": owed,
        "commission_paid": paid,
    }

@router.get("/by-phone/{phone}")
def partnerships_for_phone(phone: str,
                            session: Session = Depends(get_session),
                            b: Business = Depends(current_business),
                            actor=Depends(require_role("attendant"))):
    """
    Cashier-facing: when a customer's phone appears at this business,
    tell the cashier which partners they've been referred through.
    """
    rows = session.exec(select(PartnershipReferral).where(
        (PartnershipReferral.from_business_id == b.id) |
        (PartnershipReferral.to_business_id == b.id),
        PartnershipReferral.phone == phone)).all()
    out = []
    for r in rows:
        p = session.get(Partnership, r.partnership_id)
        other_id = r.to_business_id if r.from_business_id == b.id else r.from_business_id
        other = session.get(Business, other_id)
        out.append({
            "partnership_id": p.id,
            "partner_name": other.name if other else None,
            "direction": "outbound" if r.from_business_id == b.id else "inbound",
            "status": r.status,
            "referred_at": r.referred_at.isoformat(),
        })
    return out
