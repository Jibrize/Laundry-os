from fastapi import APIRouter, Depends, HTTPException, Header
from pydantic import BaseModel
from typing import Optional
from sqlmodel import Session, select
from app.db import get_session
from app.models import Business, BookingLink, Customer, CustomerUser
from app.auth import hash_password, new_api_key

router = APIRouter(prefix="/api/customer", tags=["customer"])

class RegisterRequest(BaseModel):
    token: str
    phone: str
    full_name: str
    password: str

class LoginRequest(BaseModel):
    token: str
    phone: str
    password: str

def _resolve(session: Session, token: str) -> Business:
    link = session.exec(select(BookingLink).where(
        BookingLink.token == token, BookingLink.active == True)).first()
    if not link: raise HTTPException(404, "Invalid link")
    b = session.get(Business, link.business_id)
    if not b: raise HTTPException(404, "Business not found")
    return b

def get_customer_actor(x_api_key: Optional[str] = Header(None),
                        session: Session = Depends(get_session)) -> Optional[CustomerUser]:
    if not x_api_key: return None
    return session.exec(select(CustomerUser).where(
        CustomerUser.api_key == x_api_key, CustomerUser.active == True)).first()

def require_customer(actor: Optional[CustomerUser] = Depends(get_customer_actor)) -> CustomerUser:
    if not actor: raise HTTPException(401, "Sign in required")
    return actor

@router.post("/register")
def register(payload: RegisterRequest, session: Session = Depends(get_session)):
    if len(payload.password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters")
    b = _resolve(session, payload.token)
    customer = session.exec(select(Customer).where(
        Customer.business_id == b.id, Customer.phone == payload.phone)).first()
    if not customer:
        customer = Customer(business_id=b.id, full_name=payload.full_name,
                             phone=payload.phone)
        session.add(customer); session.commit(); session.refresh(customer)
    if session.exec(select(CustomerUser).where(
            CustomerUser.business_id == b.id,
            CustomerUser.phone == payload.phone)).first():
        raise HTTPException(400, "Phone already registered. Sign in instead.")
    cu = CustomerUser(business_id=b.id, customer_id=customer.id,
                       phone=payload.phone,
                       password_hash=hash_password(payload.password),
                       api_key=new_api_key())
    session.add(cu); session.commit(); session.refresh(cu)
    return {"api_key": cu.api_key, "name": customer.full_name}

@router.post("/login")
def login(payload: LoginRequest, session: Session = Depends(get_session)):
    b = _resolve(session, payload.token)
    cu = session.exec(select(CustomerUser).where(
        CustomerUser.business_id == b.id,
        CustomerUser.phone == payload.phone,
        CustomerUser.active == True)).first()
    if not cu or cu.password_hash != hash_password(payload.password):
        raise HTTPException(401, "Invalid phone or password")
    return {"api_key": cu.api_key}

@router.get("/me")
def me(cu: CustomerUser = Depends(require_customer),
        session: Session = Depends(get_session)):
    b = session.get(Business, cu.business_id)
    c = session.get(Customer, cu.customer_id)
    return {"business": {"name": b.name, "phone": b.phone, "whatsapp": b.whatsapp,
                          "address": b.address, "currency": b.currency},
            "customer": {"id": c.id, "full_name": c.full_name, "phone": c.phone,
                          "address": c.address}}
