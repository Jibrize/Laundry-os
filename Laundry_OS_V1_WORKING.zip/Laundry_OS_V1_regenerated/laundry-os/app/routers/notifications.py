from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlmodel import Session, select
from app.db import get_session
from app.models import NotificationTemplate, NotificationLog, Business
from app.auth import current_business, require_role
from app.notifications import DEFAULTS

router = APIRouter(prefix="/api/notifications", tags=["notifications"])

class TemplateUpsert(BaseModel):
    event: str
    body: str
    active: bool = True

@router.get("/templates")
def list_templates(session: Session = Depends(get_session),
                   b: Business = Depends(current_business)):
    rows = session.exec(select(NotificationTemplate).where(
        NotificationTemplate.business_id == b.id)).all()
    have = {r.event: r for r in rows}
    return [{"event": ev,
              "body": have[ev].body if ev in have else DEFAULTS[ev],
              "active": have[ev].active if ev in have else True,
              "custom": ev in have} for ev in DEFAULTS]

@router.post("/templates", dependencies=[Depends(require_role("attendant"))])
def upsert_template(payload: TemplateUpsert,
                     session: Session = Depends(get_session),
                     b: Business = Depends(current_business)):
    row = session.exec(select(NotificationTemplate).where(
        NotificationTemplate.business_id == b.id,
        NotificationTemplate.event == payload.event)).first()
    if row:
        row.body = payload.body; row.active = payload.active; session.add(row)
    else:
        row = NotificationTemplate(business_id=b.id, event=payload.event,
                                     body=payload.body, active=payload.active)
        session.add(row)
    session.commit(); session.refresh(row)
    return row

@router.get("/log")
def list_log(session: Session = Depends(get_session),
              b: Business = Depends(current_business),
              actor=Depends(require_role("attendant"))):
    return session.exec(select(NotificationLog).where(
        NotificationLog.business_id == b.id)
        .order_by(NotificationLog.created_at.desc()).limit(100)).all()
