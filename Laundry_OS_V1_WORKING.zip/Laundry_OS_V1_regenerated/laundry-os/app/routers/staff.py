from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from sqlmodel import Session, select
from app.db import get_session
from app.models import User, Business
from app.schemas import StaffCreate
from app.auth import (current_business, require_role, hash_password,
                       new_api_key, ROLE_RANK)
from app.audit import log

router = APIRouter(prefix="/api/staff", tags=["staff"])

class StaffUpdate(BaseModel):
    name: Optional[str] = None
    role: Optional[str] = None
    active: Optional[bool] = None

class PasswordReset(BaseModel):
    new_password: str

@router.get("")
def list_staff(session: Session = Depends(get_session),
               b: Business = Depends(current_business),
               actor=Depends(require_role("attendant"))):
    rows = session.exec(select(User).where(User.business_id == b.id)
                        .order_by(User.name)).all()
    return [{"id": u.id, "name": u.name, "phone": u.phone, "role": u.role,
              "active": u.active, "created_at": u.created_at.isoformat()} for u in rows]

@router.post("", dependencies=[Depends(require_role("attendant"))])
def create_staff(payload: StaffCreate,
                 session: Session = Depends(get_session),
                 b: Business = Depends(current_business),
                 actor=Depends(require_role("attendant"))):
    if payload.role not in ROLE_RANK: raise HTTPException(400, f"Unknown role: {payload.role}")
    if payload.role == "admin" and actor.role != "admin":
        raise HTTPException(403, "Only an owner can create another owner")
    if session.exec(select(User).where(User.business_id == b.id,
                                        User.phone == payload.phone)).first():
        raise HTTPException(400, "Phone already in use")
    u = User(business_id=b.id, name=payload.name, phone=payload.phone,
             role=payload.role, api_key=new_api_key(),
             password_hash=hash_password(payload.password))
    session.add(u); session.commit(); session.refresh(u)
    log(session, b.id, actor, "staff_created", "user", u.id,
        after={"name": u.name, "role": u.role})
    session.commit()
    return {"id": u.id, "name": u.name, "phone": u.phone, "role": u.role,
             "api_key": u.api_key}

@router.patch("/{user_id}", dependencies=[Depends(require_role("attendant"))])
def update_staff(user_id: int, payload: StaffUpdate,
                 session: Session = Depends(get_session),
                 b: Business = Depends(current_business),
                 actor=Depends(require_role("attendant"))):
    u = session.get(User, user_id)
    if not u or u.business_id != b.id: raise HTTPException(404, "Staff not found")
    if u.role == "admin" and actor.role != "admin":
        raise HTTPException(403, "Only an owner can edit an owner")
    before = {k: getattr(u, k) for k in payload.dict(exclude_unset=True)}
    for k, v in payload.dict(exclude_unset=True).items():
        if k == "role":
            if v not in ROLE_RANK: raise HTTPException(400, f"Unknown role: {v}")
            if v == "admin" and actor.role != "admin":
                raise HTTPException(403, "Only an owner can grant owner role")
        setattr(u, k, v)
    session.add(u)
    log(session, b.id, actor, "staff_updated", "user", u.id,
        before=before, after=payload.dict(exclude_unset=True))
    session.commit(); session.refresh(u)
    return {"id": u.id, "name": u.name, "role": u.role, "active": u.active}

@router.post("/{user_id}/reset-password",
              dependencies=[Depends(require_role("attendant"))])
def reset_password(user_id: int, payload: PasswordReset,
                   session: Session = Depends(get_session),
                   b: Business = Depends(current_business),
                   actor=Depends(require_role("attendant"))):
    u = session.get(User, user_id)
    if not u or u.business_id != b.id: raise HTTPException(404, "Staff not found")
    if len(payload.new_password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters")
    u.password_hash = hash_password(payload.new_password)
    u.api_key = new_api_key()
    session.add(u)
    log(session, b.id, actor, "staff_password_reset", "user", u.id)
    session.commit()
    return {"ok": True, "new_api_key": u.api_key}
