from fastapi import APIRouter, Depends, File, UploadFile, Form
from sqlmodel import Session

from app.db import get_session
from app.models import Business
from app.auth import current_business, require_role
from app.storage import upload_photo
from app.audit import log

router = APIRouter(prefix="/api/uploads", tags=["uploads"])

@router.post("/photo", dependencies=[Depends(require_role("attendant"))])
async def upload(
    file: UploadFile = File(...),
    folder: str = Form("photos"),
    session: Session = Depends(get_session),
    b: Business = Depends(current_business),
    actor=Depends(require_role("attendant")),
):
    """
    folder: photos | inspections | deliveries | qc | intake
    """
    if folder not in ("photos", "inspections", "deliveries", "qc", "intake", "misc"):
        folder = "photos"
    result = await upload_photo(file, b.id, folder)
    log(session, b.id, actor, "photo_uploaded", "upload", None,
        after={"key": result["key"], "folder": folder})
    session.commit()
    return result
