from fastapi import APIRouter, Depends, HTTPException
from typing import Optional
from sqlmodel import Session, select
from app.db import get_session
from app.models import Customer, Order, Business
from app.schemas import CustomerCreate, CustomerUpdate
from app.auth import current_business, require_role
from app.audit import log

router = APIRouter(prefix="/api/customers", tags=["customers"])

@router.get("")
def list_customers(q: Optional[str] = None,
                   session: Session = Depends(get_session),
                   b: Business = Depends(current_business)):
    stmt = select(Customer).where(Customer.business_id == b.id)
    if q:
        like = f"%{q}%"
        stmt = stmt.where((Customer.full_name.ilike(like)) | (Customer.phone.ilike(like)))
    return session.exec(stmt.order_by(Customer.full_name)).all()

@router.post("", dependencies=[Depends(require_role("attendant"))])
def create_customer(payload: CustomerCreate,
                    session: Session = Depends(get_session),
                    b: Business = Depends(current_business),
                    actor=Depends(require_role("attendant"))):
    c = Customer(business_id=b.id, **payload.dict())
    session.add(c); session.commit(); session.refresh(c)
    log(session, b.id, actor, "customer_created", "customer", c.id, after=payload.dict())
    session.commit()
    return c

@router.get("/{cid}")
def get_customer(cid: int, session: Session = Depends(get_session),
                 b: Business = Depends(current_business)):
    c = session.get(Customer, cid)
    if not c or c.business_id != b.id: raise HTTPException(404, "Customer not found")
    orders = session.exec(select(Order).where(Order.customer_id == cid)
                          .order_by(Order.created_at.desc())).all()
    return {
        "customer": c, "orders": orders,
        "stats": {
            "orders_count": len(orders),
            "total_spent": round(sum(o.amount_paid for o in orders), 2),
            "outstanding": round(sum(o.balance for o in orders), 2),
            "last_order_at": orders[0].created_at.isoformat() if orders else None,
        }
    }

@router.patch("/{cid}", dependencies=[Depends(require_role("attendant"))])
def update_customer(cid: int, payload: CustomerUpdate,
                    session: Session = Depends(get_session),
                    b: Business = Depends(current_business),
                    actor=Depends(require_role("attendant"))):
    c = session.get(Customer, cid)
    if not c or c.business_id != b.id: raise HTTPException(404, "Customer not found")
    before = {k: getattr(c, k) for k in payload.dict(exclude_unset=True)}
    for k, v in payload.dict(exclude_unset=True).items(): setattr(c, k, v)
    session.add(c)
    log(session, b.id, actor, "customer_updated", "customer", c.id,
        before=before, after=payload.dict(exclude_unset=True))
    session.commit(); session.refresh(c)
    return c
