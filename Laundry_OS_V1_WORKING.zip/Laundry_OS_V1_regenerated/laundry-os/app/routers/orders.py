from datetime import datetime, timezone
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session, select
from app.db import get_session
from app.models import (Order, OrderItem, OrderStatusEvent, Customer,
                         Business, Inspection, QCResult, IdempotencyKey)
from app.schemas import OrderCreate, StatusUpdate, InspectionCreate, QCCreate
from app.auth import current_business, require_role
from app.pricing import build_order_items
from app.workflow import validate_transition
from app.audit import log
from app.qr import order_qr_payload, qr_image_url
from app.notifications import notify_order_created, notify_status_change

router = APIRouter(prefix="/api/orders", tags=["orders"])

def _recompute(order: Order):
    order.total = round(order.subtotal + order.delivery_fee, 2)
    order.balance = round(order.total - order.amount_paid, 2)
    if order.balance <= 0.0001:
        order.balance = 0.0; order.payment_status = "paid"
    elif order.amount_paid > 0: order.payment_status = "partial"
    else: order.payment_status = "unpaid"

@router.get("")
def list_orders(status: Optional[str] = None,
                customer_id: Optional[int] = None,
                session: Session = Depends(get_session),
                b: Business = Depends(current_business)):
    stmt = select(Order).where(Order.business_id == b.id)
    if status: stmt = stmt.where(Order.status == status)
    if customer_id: stmt = stmt.where(Order.customer_id == customer_id)
    orders = session.exec(stmt.order_by(Order.created_at.desc())).all()
    out = []
    for o in orders:
        c = session.get(Customer, o.customer_id)
        out.append({"id": o.id, "code": o.code, "status": o.status,
                    "customer": {"id": c.id, "name": c.full_name, "phone": c.phone} if c else None,
                    "total": o.total, "amount_paid": o.amount_paid, "balance": o.balance,
                    "payment_status": o.payment_status,
                    "delivery_method": o.delivery_method,
                    "created_at": o.created_at.isoformat()})
    return out

@router.post("", dependencies=[Depends(require_role("attendant"))])
async def create_order(payload: OrderCreate,
                        session: Session = Depends(get_session),
                        b: Business = Depends(current_business),
                        actor=Depends(require_role("attendant"))):
    customer = None
    if payload.customer_id:
        customer = session.get(Customer, payload.customer_id)
        if not customer or customer.business_id != b.id:
            raise HTTPException(404, "Customer not found")
    else:
        if not payload.customer_phone or not payload.customer_name:
            raise HTTPException(400, "customer_phone and customer_name required")
        customer = Customer(business_id=b.id, full_name=payload.customer_name,
                             phone=payload.customer_phone, whatsapp=payload.customer_whatsapp,
                             address=payload.customer_address)
        session.add(customer); session.commit(); session.refresh(customer)

    if not payload.items: raise HTTPException(400, "At least one item is required")
    try:
        items, subtotal = build_order_items(session, b.id, payload.items)
    except ValueError as e:
        raise HTTPException(400, str(e))

    b.next_order_number += 1; session.add(b)
    code = f"#{b.next_order_number}"
    order = Order(business_id=b.id, code=code, customer_id=customer.id,
                   status=b.workflow_stages[0] if b.workflow_stages else "received",
                   subtotal=subtotal, delivery_fee=payload.delivery_fee,
                   delivery_method=payload.delivery_method, notes=payload.notes,
                   expected_at=payload.expected_at, created_by=actor.id,
                   qr_payload=order_qr_payload(b.id, code))
    _recompute(order)
    session.add(order); session.commit(); session.refresh(order)
    for it in items: it.order_id = order.id; session.add(it)
    session.add(OrderStatusEvent(order_id=order.id, to_status=order.status,
                                  note="Order created", actor_id=actor.id))
    if payload.delivery_method == "delivery":
        from app.models import Delivery
        session.add(Delivery(business_id=b.id, order_id=order.id, kind="delivery",
                              address=payload.delivery_address or customer.address,
                              phone=customer.phone, fee=payload.delivery_fee,
                              status="pending"))
    log(session, b.id, actor, "order_created", "order", order.id,
        after={"code": code, "total": order.total})
    session.commit(); session.refresh(order)

    await notify_order_created(session, order)
    return get_order(order.id, session, b)

@router.get("/{oid}")
def get_order(oid: int, session: Session = Depends(get_session),
              b: Business = Depends(current_business)):
    o = session.get(Order, oid)
    if not o or o.business_id != b.id: raise HTTPException(404, "Order not found")
    c = session.get(Customer, o.customer_id)
    items = session.exec(select(OrderItem).where(OrderItem.order_id == oid)).all()
    events = session.exec(select(OrderStatusEvent).where(OrderStatusEvent.order_id == oid)
                         .order_by(OrderStatusEvent.created_at)).all()
    inspections = session.exec(select(Inspection).where(Inspection.order_id == oid)).all()
    qc = session.exec(select(QCResult).where(QCResult.order_id == oid)
                      .order_by(QCResult.created_at.desc())).first()
    return {"order": o, "customer": c, "items": items,
            "timeline": events, "inspections": inspections, "latest_qc": qc,
            "qr": {"payload": o.qr_payload,
                    "image_url": qr_image_url(o.qr_payload) if o.qr_payload else None}}

@router.post("/{oid}/status", dependencies=[Depends(require_role("attendant"))])
async def change_status(oid: int, payload: StatusUpdate,
                         session: Session = Depends(get_session),
                         b: Business = Depends(current_business),
                         actor=Depends(require_role("attendant"))):
    o = session.get(Order, oid)
    if not o or o.business_id != b.id: raise HTTPException(404, "Order not found")
    validate_transition(b.workflow_stages, o.status, payload.to_status)
    before = o.status
    o.status = payload.to_status
    o.updated_at = datetime.now(timezone.utc)
    if payload.to_status == "completed": o.completed_at = datetime.now(timezone.utc)
    session.add(o)
    session.add(OrderStatusEvent(order_id=o.id, from_status=before,
                                  to_status=payload.to_status,
                                  note=payload.note, actor_id=actor.id))
    log(session, b.id, actor, "order_status_changed", "order", o.id,
        before={"status": before}, after={"status": payload.to_status})
    session.commit(); session.refresh(o)
    await notify_status_change(session, o, before, payload.to_status)
    return o

@router.post("/{oid}/inspection", dependencies=[Depends(require_role("attendant"))])
def add_inspection(oid: int, payload: InspectionCreate,
                    session: Session = Depends(get_session),
                    b: Business = Depends(current_business),
                    actor=Depends(require_role("attendant"))):
    o = session.get(Order, oid)
    if not o or o.business_id != b.id: raise HTTPException(404, "Order not found")
    i = Inspection(order_id=oid, condition=payload.condition, note=payload.note,
                    photo_url=payload.photo_url, recorded_by=actor.id)
    session.add(i)
    log(session, b.id, actor, "inspection_added", "order", oid, after=payload.dict())
    session.commit(); session.refresh(i)
    return i

@router.post("/{oid}/qc", dependencies=[Depends(require_role("attendant"))])
def record_qc(oid: int, payload: QCCreate,
              session: Session = Depends(get_session),
              b: Business = Depends(current_business),
              actor=Depends(require_role("attendant"))):
    o = session.get(Order, oid)
    if not o or o.business_id != b.id: raise HTTPException(404, "Order not found")
    qc = QCResult(order_id=oid, checklist=payload.checklist, result=payload.result,
                   reason=payload.reason, inspected_by=actor.id)
    session.add(qc)
    log(session, b.id, actor, "qc_recorded", "order", oid, after={"result": payload.result})
    session.commit(); session.refresh(qc)
    return qc

@router.post("/{oid}/repeat", dependencies=[Depends(require_role("attendant"))])
async def repeat_order(oid: int, session: Session = Depends(get_session),
                        b: Business = Depends(current_business),
                        actor=Depends(require_role("attendant"))):
    src = session.get(Order, oid)
    if not src or src.business_id != b.id: raise HTTPException(404, "Order not found")
    src_items = session.exec(select(OrderItem).where(OrderItem.order_id == oid)).all()
    payload = OrderCreate(
        customer_id=src.customer_id,
        items=[{"service_id": it.service_id, "quantity": it.quantity, "notes": it.notes}
               for it in src_items],
        delivery_method=src.delivery_method, delivery_fee=src.delivery_fee,
        notes=f"Repeat of {src.code}")
    return await create_order(payload, session, b, actor)

class IdempotentOrder(BaseModel):
    idempotency_key: str
    payload: dict

@router.post("/idempotent", dependencies=[Depends(require_role("attendant"))])
async def create_order_idempotent(body: IdempotentOrder,
                                   session: Session = Depends(get_session),
                                   b: Business = Depends(current_business),
                                   actor=Depends(require_role("attendant"))):
    existing = session.exec(select(IdempotencyKey).where(
        IdempotencyKey.key == body.idempotency_key)).first()
    if existing and existing.entity_id:
        return get_order(existing.entity_id, session, b)
    payload = OrderCreate(**body.payload)
    result = await create_order(payload, session, b, actor)
    session.add(IdempotencyKey(business_id=b.id, key=body.idempotency_key,
                                action="order.create", entity_type="order",
                                entity_id=result["order"].id))
    session.commit()
    return result
