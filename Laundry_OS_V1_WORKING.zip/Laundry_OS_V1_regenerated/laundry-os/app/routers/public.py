from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session, select
from app.db import get_session
from app.models import (Business, BookingLink, Customer, Service, Order,
                         OrderItem, OrderStatusEvent, Delivery)
from app.pricing import build_order_items
from app.qr import order_qr_payload
from app.audit import log
from app.notifications import notify_order_created

router = APIRouter(prefix="/api/public", tags=["public"])

def _resolve_business(session: Session, token: str) -> Business:
    link = session.exec(select(BookingLink).where(
        BookingLink.token == token, BookingLink.active == True)).first()
    if not link: raise HTTPException(404, "Invalid booking link")
    b = session.get(Business, link.business_id)
    if not b: raise HTTPException(404, "Business not found")
    return b

@router.get("/{token}/info")
def booking_info(token: str, session: Session = Depends(get_session)):
    b = _resolve_business(session, token)
    services = session.exec(select(Service).where(
        Service.business_id == b.id, Service.active == True)
        .order_by(Service.name)).all()
    return {
        "business": {"name": b.name, "phone": b.phone, "whatsapp": b.whatsapp,
                     "address": b.address, "logo_url": b.logo_url,
                     "currency": b.currency, "opening_hours": b.opening_hours,
                     "brand_color": b.brand_color or "#3b82f6",
                     "tagline": b.tagline, "hero_url": b.hero_url, "terms": b.terms},
        "services": [{"id": s.id, "name": s.name, "measurement": s.measurement,
                       "price": s.price, "min_charge": s.min_charge,
                       "category": s.category, "instructions": s.instructions} for s in services],
    }

class PublicOrderItem(BaseModel):
    service_id: int
    quantity: float

class PublicOrderCreate(BaseModel):
    full_name: str
    phone: str
    whatsapp: Optional[str] = None
    address: Optional[str] = None
    pickup: bool = True
    pickup_at: Optional[str] = None
    notes: Optional[str] = None
    items: List[PublicOrderItem]

@router.post("/{token}/orders")
async def create_public_order(token: str, payload: PublicOrderCreate,
                               session: Session = Depends(get_session)):
    b = _resolve_business(session, token)
    if not payload.full_name or not payload.phone:
        raise HTTPException(400, "Name and phone required")
    if not payload.items: raise HTTPException(400, "At least one item required")
    customer = session.exec(select(Customer).where(
        Customer.business_id == b.id, Customer.phone == payload.phone)).first()
    if not customer:
        customer = Customer(business_id=b.id, full_name=payload.full_name,
                             phone=payload.phone, whatsapp=payload.whatsapp,
                             address=payload.address)
        session.add(customer); session.commit(); session.refresh(customer)

    class _I:
        def __init__(self, d): self.__dict__.update(d)
    items_in = [_I({"service_id": i.service_id, "quantity": i.quantity, "notes": None})
                for i in payload.items]
    try:
        items, subtotal = build_order_items(session, b.id, items_in)
    except ValueError as e:
        raise HTTPException(400, str(e))

    b.next_order_number += 1; session.add(b)
    code = f"#{b.next_order_number}"
    order = Order(business_id=b.id, code=code, customer_id=customer.id,
                   status=b.workflow_stages[0] if b.workflow_stages else "received",
                   subtotal=subtotal,
                   delivery_method="delivery" if payload.pickup else "pickup",
                   notes=(payload.notes or "") + (f"\nPreferred pickup: {payload.pickup_at}"
                                                    if payload.pickup_at else ""),
                   qr_payload=order_qr_payload(b.id, code))
    order.total = subtotal; order.balance = subtotal
    session.add(order); session.commit(); session.refresh(order)
    for it in items: it.order_id = order.id; session.add(it)
    session.add(OrderStatusEvent(order_id=order.id, to_status=order.status,
                                  note="Order placed via public booking page"))
    if payload.pickup:
        session.add(Delivery(business_id=b.id, order_id=order.id, kind="pickup",
                              address=payload.address or customer.address,
                              phone=customer.phone, status="pending"))
    log(session, b.id, None, "public_order_created", "order", order.id,
        after={"code": code, "source": "public_booking"})
    session.commit(); session.refresh(order)
    await notify_order_created(session, order)
    return {"ok": True, "order_code": order.code, "total": order.total,
            "business_name": b.name, "business_phone": b.phone}
