from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from app.db import get_session
from app.models import User
from app.schemas import LoginRequest
from app.auth import hash_password, current_user

router = APIRouter(prefix="/api/auth", tags=["auth"])

@router.post("/login")
def login(payload: LoginRequest, session: Session = Depends(get_session)):
    user = session.exec(select(User).where(User.phone == payload.phone,
                                            User.active == True)).first()
    if not user or user.password_hash != hash_password(payload.password):
        raise HTTPException(401, "Invalid phone or password")
    return {"api_key": user.api_key,
            "user": {"id": user.id, "name": user.name, "role": user.role,
                      "business_id": user.business_id}}

@router.get("/me")
def me(actor: User = Depends(current_user)):
    return {"id": actor.id, "name": actor.name, "role": actor.role,
            "business_id": actor.business_id}
