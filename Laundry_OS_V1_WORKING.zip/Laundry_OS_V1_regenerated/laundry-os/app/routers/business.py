import secrets
from datetime import datetime, timezone
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from app.db import get_session
from app.models import Business, BookingLink, WhatsAppNumber
from app.schemas import BusinessUpdate
from app.auth import current_business, require_role
from app.audit import log

router = APIRouter(prefix="/api/business", tags=["business"])

@router.get("")
def get_business(b: Business = Depends(current_business)):
    return b

@router.patch("")
def update_business(payload: BusinessUpdate,
                    session: Session = Depends(get_session),
                    b: Business = Depends(current_business),
                    actor=Depends(require_role("admin"))):
    before = payload.dict(exclude_unset=True) and {
        k: getattr(b, k) for k in payload.dict(exclude_unset=True)}
    for k, v in payload.dict(exclude_unset=True).items():
        setattr(b, k, v)
    b.updated_at = datetime.now(timezone.utc)
    session.add(b)
    log(session, b.id, actor, "business_updated", "business", b.id,
        before=before, after=payload.dict(exclude_unset=True))
    session.commit(); session.refresh(b)
    return b

@router.post("/booking-link", dependencies=[Depends(require_role("admin"))])
def ensure_booking_link(session: Session = Depends(get_session),
                         b: Business = Depends(current_business)):
    link = session.exec(select(BookingLink).where(BookingLink.business_id == b.id)).first()
    if link: return link
    link = BookingLink(business_id=b.id, token=secrets.token_urlsafe(16))
    session.add(link); session.commit(); session.refresh(link)
    return link

@router.post("/booking-link/rotate", dependencies=[Depends(require_role("admin"))])
def rotate_booking_link(session: Session = Depends(get_session),
                         b: Business = Depends(current_business),
                         actor=Depends(require_role("admin"))):
    old = session.exec(select(BookingLink).where(BookingLink.business_id == b.id)).first()
    if old: old.active = False; session.add(old)
    new_link = BookingLink(business_id=b.id, token=secrets.token_urlsafe(16))
    session.add(new_link); session.commit(); session.refresh(new_link)
    log(session, b.id, actor, "booking_link_rotated", "bookinglink", new_link.id)
    session.commit()
    return new_link

@router.post("/whatsapp-numbers", dependencies=[Depends(require_role("admin"))])
def add_wa_number(phone_number_id: str,
                   display_number: Optional[str] = None,
                   session: Session = Depends(get_session),
                   b: Business = Depends(current_business)):
    existing = session.exec(select(WhatsAppNumber).where(
        WhatsAppNumber.phone_number_id == phone_number_id)).first()
    if existing and existing.business_id != b.id:
        raise HTTPException(400, "Number already registered to another business")
    if existing: return existing
    row = WhatsAppNumber(business_id=b.id, phone_number_id=phone_number_id,
                          display_number=display_number,
                          verify_token=secrets.token_urlsafe(24))
    session.add(row); session.commit(); session.refresh(row)
    return row

@router.get("/whatsapp-numbers")
def list_wa_numbers(session: Session = Depends(get_session),
                     b: Business = Depends(current_business)):
    return session.exec(select(WhatsAppNumber).where(
        WhatsAppNumber.business_id == b.id)).all()
