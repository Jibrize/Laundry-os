from fastapi import APIRouter, Depends
from sqlmodel import Session, select
from app.db import get_session
from app.models import Order, Customer, Business, OrderItem
from app.auth import current_business

router = APIRouter(prefix="/api/work", tags=["work"])

@router.get("")
def work_queue(session: Session = Depends(get_session),
               b: Business = Depends(current_business)):
    stages = [s for s in b.workflow_stages if s != "completed"]
    out = {s: [] for s in stages}
    orders = session.exec(select(Order).where(
        Order.business_id == b.id,
        Order.status.notin_(["completed", "cancelled"]))).all()
    for o in orders:
        if o.status not in out: continue
        c = session.get(Customer, o.customer_id)
        items = session.exec(select(OrderItem).where(OrderItem.order_id == o.id)).all()
        out[o.status].append({"id": o.id, "code": o.code, "status": o.status,
                               "customer_name": c.full_name if c else "?",
                               "customer_phone": c.phone if c else None,
                               "summary": _summary(items),
                               "intake_at": o.intake_at.isoformat()})
    return {"stages": stages, "queue": out}

def _summary(items):
    if not items: return ""
    kg = sum(i.quantity for i in items if i.measurement == "kg")
    cnt = sum(i.quantity for i in items if i.measurement != "kg")
    bits = []
    if kg: bits.append(f"{round(kg,1)}kg")
    if cnt: bits.append(f"{int(cnt)} items")
    return f"{items[0].service_name}" + (" · " + " + ".join(bits) if bits else "")
