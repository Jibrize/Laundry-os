from datetime import datetime, timezone, timedelta
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session, select
from sqlalchemy import func
from app.db import get_session
from app.models import Expense, Business
from app.auth import current_business, require_role
from app.audit import log

router = APIRouter(prefix="/api/expenses", tags=["expenses"])

CATEGORIES = ["Detergent", "Electricity", "Water", "Rent", "Salaries",
              "Delivery", "Packaging", "Repairs", "Other"]

class ExpenseCreate(BaseModel):
    category: str
    amount: float
    note: Optional[str] = None
    created_at: Optional[datetime] = None

@router.get("")
def list_expenses(since_days: int = 30, session: Session = Depends(get_session),
                  b: Business = Depends(current_business)):
    since = datetime.now(timezone.utc) - timedelta(days=since_days)
    return session.exec(select(Expense).where(
        Expense.business_id == b.id, Expense.created_at >= since)
        .order_by(Expense.created_at.desc())).all()

@router.post("", dependencies=[Depends(require_role("attendant"))])
def create_expense(payload: ExpenseCreate,
                   session: Session = Depends(get_session),
                   b: Business = Depends(current_business),
                   actor=Depends(require_role("attendant"))):
    if payload.amount <= 0: raise HTTPException(400, "Amount must be positive")
    e = Expense(business_id=b.id, category=payload.category,
                 amount=payload.amount, note=payload.note,
                 recorded_by=actor.id)
    if payload.created_at: e.created_at = payload.created_at
    session.add(e); session.commit(); session.refresh(e)
    log(session, b.id, actor, "expense_created", "expense", e.id,
        after={"category": e.category, "amount": e.amount})
    session.commit()
    return e

@router.get("/summary")
def expense_summary(since_days: int = 30, session: Session = Depends(get_session),
                    b: Business = Depends(current_business)):
    since = datetime.now(timezone.utc) - timedelta(days=since_days)
    rows = session.exec(select(Expense.category, func.sum(Expense.amount))
        .where(Expense.business_id == b.id, Expense.created_at >= since)
        .group_by(Expense.category)).all()
    total = sum(r[1] for r in rows) if rows else 0
    return {"window_days": since_days, "total": round(total, 2),
            "by_category": [{"category": r[0], "amount": round(r[1], 2)} for r in rows],
            "categories_available": CATEGORIES}

@router.delete("/{expense_id}", dependencies=[Depends(require_role("admin"))])
def delete_expense(expense_id: int, session: Session = Depends(get_session),
                    b: Business = Depends(current_business),
                    actor=Depends(require_role("admin"))):
    e = session.get(Expense, expense_id)
    if not e or e.business_id != b.id: raise HTTPException(404, "Expense not found")
    log(session, b.id, actor, "expense_deleted", "expense", e.id,
        before={"category": e.category, "amount": e.amount})
    session.delete(e); session.commit()
    return {"ok": True}
