from datetime import datetime, timezone
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session, select
from app.db import get_session
from app.models import InventoryItem, InventoryTxn, Business
from app.auth import current_business, require_role
from app.audit import log

router = APIRouter(prefix="/api/inventory", tags=["inventory"])

class ItemCreate(BaseModel):
    name: str
    unit: str = "unit"
    quantity: float = 0.0
    min_level: float = 0.0
    unit_cost: float = 0.0
    supplier: Optional[str] = None

class TxnCreate(BaseModel):
    delta: float
    reason: Optional[str] = None

@router.get("")
def list_items(low_only: bool = False,
               session: Session = Depends(get_session),
               b: Business = Depends(current_business)):
    rows = session.exec(select(InventoryItem).where(
        InventoryItem.business_id == b.id).order_by(InventoryItem.name)).all()
    if low_only: rows = [r for r in rows if r.quantity <= r.min_level]
    return rows

@router.get("/low-stock")
def low_stock(session: Session = Depends(get_session),
              b: Business = Depends(current_business)):
    rows = session.exec(select(InventoryItem).where(
        InventoryItem.business_id == b.id)).all()
    return [r for r in rows if r.quantity <= r.min_level]

@router.post("", dependencies=[Depends(require_role("attendant"))])
def create_item(payload: ItemCreate,
                session: Session = Depends(get_session),
                b: Business = Depends(current_business),
                actor=Depends(require_role("attendant"))):
    it = InventoryItem(business_id=b.id, **payload.dict())
    session.add(it); session.commit(); session.refresh(it)
    if payload.quantity:
        session.add(InventoryTxn(item_id=it.id, delta=payload.quantity,
                                  reason="initial", actor_id=actor.id))
    log(session, b.id, actor, "inventory_item_created", "inventoryitem", it.id,
        after=payload.dict())
    session.commit(); session.refresh(it)
    return it

@router.post("/{item_id}/txn", dependencies=[Depends(require_role("attendant"))])
def add_txn(item_id: int, payload: TxnCreate,
            session: Session = Depends(get_session),
            b: Business = Depends(current_business),
            actor=Depends(require_role("attendant"))):
    it = session.get(InventoryItem, item_id)
    if not it or it.business_id != b.id: raise HTTPException(404, "Item not found")
    before_qty = it.quantity
    it.quantity = round(it.quantity + payload.delta, 3)
    if it.quantity < 0: raise HTTPException(400, "Stock cannot go negative")
    it.updated_at = datetime.now(timezone.utc)
    session.add(it)
    session.add(InventoryTxn(item_id=it.id, delta=payload.delta,
                              reason=payload.reason, actor_id=actor.id))
    log(session, b.id, actor, "inventory_txn", "inventoryitem", it.id,
        before={"quantity": before_qty}, after={"quantity": it.quantity})
    session.commit(); session.refresh(it)
    return it

@router.get("/{item_id}/history")
def item_history(item_id: int, session: Session = Depends(get_session),
                 b: Business = Depends(current_business)):
    it = session.get(InventoryItem, item_id)
    if not it or it.business_id != b.id: raise HTTPException(404, "Item not found")
    txns = session.exec(select(InventoryTxn).where(InventoryTxn.item_id == item_id)
                        .order_by(InventoryTxn.created_at.desc()).limit(200)).all()
    return {"item": it, "transactions": txns}
