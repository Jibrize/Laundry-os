from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends
from sqlmodel import Session, select
from sqlalchemy import func
from app.db import get_session
from app.models import Order, Payment, Expense, Business, OrderItem, Customer
from app.auth import current_business

router = APIRouter(prefix="/api/reports", tags=["reports"])

@router.get("/daily")
def daily(session: Session = Depends(get_session),
          b: Business = Depends(current_business)):
    now = datetime.now(timezone.utc)
    return _window(session, b, now.replace(hour=0, minute=0, second=0, microsecond=0), now)

@router.get("/weekly")
def weekly(session: Session = Depends(get_session),
           b: Business = Depends(current_business)):
    now = datetime.now(timezone.utc)
    return _window(session, b, now - timedelta(days=7), now)

@router.get("/monthly")
def monthly(session: Session = Depends(get_session),
            b: Business = Depends(current_business)):
    now = datetime.now(timezone.utc)
    return _window(session, b, now.replace(day=1, hour=0, minute=0, second=0, microsecond=0), now)

@router.get("/service-performance")
def service_performance(since_days: int = 30,
                        session: Session = Depends(get_session),
                        b: Business = Depends(current_business)):
    since = datetime.now(timezone.utc) - timedelta(days=since_days)
    rows = session.exec(select(OrderItem.service_name,
                                 func.sum(OrderItem.quantity),
                                 func.sum(OrderItem.subtotal),
                                 func.count(OrderItem.id))
        .join(Order, Order.id == OrderItem.order_id)
        .where(Order.business_id == b.id, Order.created_at >= since)
        .group_by(OrderItem.service_name)).all()
    rows = sorted(rows, key=lambda r: r[2] or 0, reverse=True)
    return {"window_days": since_days,
            "services": [{"service": r[0], "total_quantity": round(r[1] or 0, 2),
                           "total_revenue": round(r[2] or 0, 2), "line_count": r[3]}
                          for r in rows]}

@router.get("/customer-growth")
def customer_growth(since_days: int = 90,
                    session: Session = Depends(get_session),
                    b: Business = Depends(current_business)):
    since = datetime.now(timezone.utc) - timedelta(days=since_days)
    rows = session.exec(select(func.date(Customer.created_at), func.count(Customer.id))
        .where(Customer.business_id == b.id, Customer.created_at >= since)
        .group_by(func.date(Customer.created_at))).all()
    return {"window_days": since_days,
            "by_day": [{"date": str(r[0]), "count": r[1]} for r in rows],
            "total_new": sum(r[1] for r in rows)}

def _window(session, b, start, end):
    orders = session.exec(select(Order).where(
        Order.business_id == b.id, Order.created_at >= start, Order.created_at <= end)).all()
    payments = session.exec(select(Payment).where(
        Payment.business_id == b.id, Payment.created_at >= start,
        Payment.created_at <= end)).all()
    expenses = session.exec(select(Expense).where(
        Expense.business_id == b.id, Expense.created_at >= start,
        Expense.created_at <= end)).all()
    billed = round(sum(o.total for o in orders), 2)
    collected = round(sum(p.amount for p in payments), 2)
    outstanding = round(sum(o.balance for o in orders), 2)
    expense_total = round(sum(e.amount for e in expenses), 2)
    cnt = len(orders)
    return {"window": {"start": start.isoformat(), "end": end.isoformat()},
            "orders_count": cnt, "revenue_billed": billed,
            "revenue_collected": collected, "outstanding": outstanding,
            "expenses": expense_total, "net_collected": round(collected - expense_total, 2),
            "average_order_value": round(billed / cnt, 2) if cnt else 0,
            "note": "Net = cash collected minus recorded expenses. Not an accounting substitute."}
