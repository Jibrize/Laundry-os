from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from app.db import get_session
from app.models import Order, Payment, Business
from app.schemas import PaymentCreate
from app.auth import current_business, require_role
from app.audit import log
from app.notifications import notify_payment_received

router = APIRouter(prefix="/api", tags=["payments"])

@router.get("/orders/{oid}/payments")
def list_payments(oid: int, session: Session = Depends(get_session),
                  b: Business = Depends(current_business)):
    o = session.get(Order, oid)
    if not o or o.business_id != b.id: raise HTTPException(404, "Order not found")
    return session.exec(select(Payment).where(Payment.order_id == oid)
                        .order_by(Payment.created_at)).all()

@router.post("/orders/{oid}/payments",
              dependencies=[Depends(require_role("attendant"))])
async def record_payment(oid: int, payload: PaymentCreate,
                          session: Session = Depends(get_session),
                          b: Business = Depends(current_business),
                          actor=Depends(require_role("attendant"))):
    o = session.get(Order, oid)
    if not o or o.business_id != b.id: raise HTTPException(404, "Order not found")
    if payload.amount <= 0: raise HTTPException(400, "Amount must be positive")
    if not b.allow_credit and payload.amount > o.balance + 0.005:
        raise HTTPException(400, "Payment cannot exceed outstanding balance")
    p = Payment(business_id=b.id, order_id=oid, amount=payload.amount,
                method=payload.method, reference=payload.reference,
                note=payload.note, recorded_by=actor.id)
    session.add(p); session.commit(); session.refresh(p)
    p.code = f"PY-{p.id:05d}"; session.add(p)

    from app.routers.orders import _recompute
    o.amount_paid = round(o.amount_paid + payload.amount, 2)
    _recompute(o); session.add(o)
    log(session, b.id, actor, "payment_recorded", "order", oid,
        after={"amount": payload.amount, "method": payload.method,
               "amount_paid": o.amount_paid, "balance": o.balance})
    session.commit(); session.refresh(p)
    await notify_payment_received(session, o, payload.amount)
    return {"payment": p, "order": o}
