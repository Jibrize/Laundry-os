from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlmodel import Session, select
from app.db import get_session
from app.models import Business, Order, MpesaPayment, Customer
from app.auth import current_business, require_role
from app.mpesa import initiate_stk_push, handle_callback, _apply_success

router = APIRouter(prefix="/api/mpesa", tags=["mpesa"])

class StkRequest(BaseModel):
    order_id: int
    phone: Optional[str] = None
    amount: Optional[float] = None

@router.post("/stk", dependencies=[Depends(require_role("attendant"))])
async def stk(payload: StkRequest, request: Request,
              session: Session = Depends(get_session),
              b: Business = Depends(current_business)):
    order = session.get(Order, payload.order_id)
    if not order or order.business_id != b.id: raise HTTPException(404, "Order not found")
    customer = session.get(Customer, order.customer_id)
    phone = payload.phone or (customer.phone if customer else None)
    if not phone: raise HTTPException(400, "No phone number")
    amount = payload.amount if payload.amount is not None else order.balance
    callback_url = str(request.url_for("mpesa_callback"))
    rec = await initiate_stk_push(session, b, order, phone, amount, callback_url)
    return {"id": rec.id, "status": rec.status,
            "checkout_request_id": rec.checkout_request_id,
            "receipt": rec.mpesa_receipt, "message": rec.result_desc}

@router.post("/callback", name="mpesa_callback")
async def mpesa_callback(request: Request, session: Session = Depends(get_session)):
    body = await request.json()
    try: await handle_callback(session, body)
    except Exception as e: print(f"M-Pesa callback error: {e}")
    return {"ResultCode": 0, "ResultDesc": "Accepted"}

@router.get("/payments")
def list_mpesa(session: Session = Depends(get_session),
               b: Business = Depends(current_business),
               actor=Depends(require_role("attendant"))):
    rows = session.exec(select(MpesaPayment).where(MpesaPayment.business_id == b.id)
        .order_by(MpesaPayment.created_at.desc()).limit(100)).all()
    return [{"id": r.id, "order_id": r.order_id, "phone": r.phone,
              "amount": r.amount, "status": r.status,
              "receipt": r.mpesa_receipt, "desc": r.result_desc,
              "created_at": r.created_at.isoformat()} for r in rows]

@router.post("/stk/{payment_id}/simulate",
              dependencies=[Depends(require_role("attendant"))])
async def simulate(payment_id: int, session: Session = Depends(get_session),
                    b: Business = Depends(current_business)):
    import secrets
    from datetime import datetime, timezone
    rec = session.get(MpesaPayment, payment_id)
    if not rec or rec.business_id != b.id: raise HTTPException(404, "Not found")
    if rec.status != "pending": raise HTTPException(400, f"Already {rec.status}")
    rec.status = "success"; rec.result_code = 0; rec.result_desc = "Simulated"
    rec.mpesa_receipt = f"SIM{secrets.randbelow(90_000_000) + 10_000_000}"
    rec.completed_at = datetime.now(timezone.utc)
    _apply_success(session, b, rec)
    session.commit(); session.refresh(rec)
    return {"status": rec.status, "receipt": rec.mpesa_receipt}
