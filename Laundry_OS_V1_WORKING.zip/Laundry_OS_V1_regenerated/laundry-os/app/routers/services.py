from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from app.db import get_session
from app.models import Service, Business
from app.schemas import ServiceCreate, ServiceUpdate
from app.auth import current_business, require_role
from app.audit import log

router = APIRouter(prefix="/api/services", tags=["services"])

@router.get("")
def list_services(active_only: bool = False,
                  session: Session = Depends(get_session),
                  b: Business = Depends(current_business)):
    stmt = select(Service).where(Service.business_id == b.id)
    if active_only: stmt = stmt.where(Service.active == True)
    return session.exec(stmt.order_by(Service.name)).all()

@router.post("", dependencies=[Depends(require_role("attendant"))])
def create_service(payload: ServiceCreate,
                   session: Session = Depends(get_session),
                   b: Business = Depends(current_business),
                   actor=Depends(require_role("attendant"))):
    s = Service(business_id=b.id, **payload.dict())
    session.add(s); session.commit(); session.refresh(s)
    log(session, b.id, actor, "service_created", "service", s.id, after=payload.dict())
    session.commit()
    return s

@router.patch("/{sid}", dependencies=[Depends(require_role("attendant"))])
def update_service(sid: int, payload: ServiceUpdate,
                   session: Session = Depends(get_session),
                   b: Business = Depends(current_business),
                   actor=Depends(require_role("attendant"))):
    s = session.get(Service, sid)
    if not s or s.business_id != b.id: raise HTTPException(404, "Service not found")
    before = {k: getattr(s, k) for k in payload.dict(exclude_unset=True)}
    for k, v in payload.dict(exclude_unset=True).items(): setattr(s, k, v)
    session.add(s)
    log(session, b.id, actor, "service_updated", "service", s.id,
        before=before, after=payload.dict(exclude_unset=True))
    session.commit(); session.refresh(s)
    return s
