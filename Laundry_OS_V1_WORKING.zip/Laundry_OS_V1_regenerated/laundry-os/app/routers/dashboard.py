from datetime import datetime, timezone
from fastapi import APIRouter, Depends
from sqlmodel import Session, select
from app.db import get_session
from app.models import Order, Payment, Business
from app.auth import current_business

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])

@router.get("")
def dashboard(session: Session = Depends(get_session),
              b: Business = Depends(current_business)):
    now = datetime.now(timezone.utc)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    active = session.exec(select(Order).where(
        Order.business_id == b.id,
        Order.status.notin_(["completed", "cancelled"]))).all()
    counts = {s: 0 for s in b.workflow_stages}
    for o in active:
        if o.status in counts: counts[o.status] += 1
    todays = session.exec(select(Order).where(
        Order.business_id == b.id, Order.created_at >= start)).all()
    todays_payments = session.exec(select(Payment).where(
        Payment.business_id == b.id, Payment.created_at >= start)).all()
    outstanding = round(sum(o.balance for o in session.exec(select(Order).where(
        Order.business_id == b.id, Order.balance > 0)).all()), 2)
    return {"today": {"orders_received": len(todays),
                       "sales_collected": round(sum(p.amount for p in todays_payments), 2)},
            "processing": {"active_orders": len(active), "counts_by_stage": counts},
            "outstanding_total": outstanding,
            "workflow_stages": b.workflow_stages}
