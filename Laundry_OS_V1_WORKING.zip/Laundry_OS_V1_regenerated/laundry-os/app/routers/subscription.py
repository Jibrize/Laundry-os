from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select

from app.db import get_session
from app.models import Subscription, SubscriptionPayment, Business
from app.schemas import SubscriptionUpsert, SubscriptionPaymentCreate
from app.auth import current_business, require_role, get_actor
from app.audit import log

router = APIRouter(prefix="/api/subscription", tags=["subscription"])

def _ensure_sub(session: Session, business_id: int) -> Subscription:
    sub = session.exec(select(Subscription).where(
        Subscription.business_id == business_id)).first()
    if sub:
        return sub
    # New business: 14-day trial
    now = datetime.now(timezone.utc)
    sub = Subscription(
        business_id=business_id, plan="trial", status="active",
        price_monthly=0.0,
        started_at=now, current_period_start=now,
        current_period_end=now + timedelta(days=14),
        grace_days=7,
    )
    session.add(sub); session.commit(); session.refresh(sub)
    return sub

@router.get("/me")
def my_subscription(session: Session = Depends(get_session),
                     b: Business = Depends(current_business)):
    sub = _ensure_sub(session, b.id)
    now = datetime.now(timezone.utc)
    days_left = None
    if sub.current_period_end:
        days_left = (sub.current_period_end - now).days
    return {
        "plan": sub.plan, "status": sub.status,
        "price_monthly": sub.price_monthly, "currency": sub.currency,
        "billing_cycle": sub.billing_cycle,
        "current_period_start": sub.current_period_start.isoformat(),
        "current_period_end": sub.current_period_end.isoformat() if sub.current_period_end else None,
        "days_left": days_left,
        "grace_days": sub.grace_days,
        "suspended_at": sub.suspended_at.isoformat() if sub.suspended_at else None,
    }

@router.patch("/me", dependencies=[Depends(require_role("admin"))])
def update_subscription(payload: SubscriptionUpsert,
                         session: Session = Depends(get_session),
                         b: Business = Depends(current_business),
                         actor=Depends(require_role("admin"))):
    """Owners can change plan + price. Status changes are admin-only (below)."""
    sub = _ensure_sub(session, b.id)
    before = payload.dict(exclude_unset=True) and {
        k: getattr(sub, k) for k in payload.dict(exclude_unset=True)
        if k != "status"}
    allowed = {"plan", "price_monthly", "currency", "billing_cycle",
                "current_period_end", "grace_days", "notes"}
    for k, v in payload.dict(exclude_unset=True).items():
        if k not in allowed:
            continue
        setattr(sub, k, v)
    sub.updated_at = datetime.now(timezone.utc)
    session.add(sub)
    log(session, b.id, actor, "subscription_updated", "subscription", sub.id,
        before=before, after=payload.dict(exclude_unset=True))
    session.commit(); session.refresh(sub)
    return sub

@router.post("/payments", dependencies=[Depends(require_role("admin"))])
def record_payment(payload: SubscriptionPaymentCreate,
                    session: Session = Depends(get_session),
                    b: Business = Depends(current_business),
                    actor=Depends(require_role("admin"))):
    if payload.amount <= 0:
        raise HTTPException(400, "Amount must be positive")
    sub = _ensure_sub(session, b.id)
    now = datetime.now(timezone.utc)

    p = SubscriptionPayment(
        business_id=b.id, subscription_id=sub.id,
        amount=payload.amount, method=payload.method,
        reference=payload.reference, note=payload.note,
        period_start=sub.current_period_start,
        period_end=payload.period_end or (now + timedelta(days=30)),
        recorded_by_id=actor.id,
    )
    session.add(p)

    # Extend period
    sub.status = "active"
    sub.suspended_at = None
    sub.current_period_start = now
    sub.current_period_end = payload.period_end or (now + timedelta(days=30))
    sub.updated_at = now
    session.add(sub)

    log(session, b.id, actor, "subscription_paid", "subscription", sub.id,
        after={"amount": payload.amount, "method": payload.method,
               "new_period_end": sub.current_period_end.isoformat()})
    session.commit(); session.refresh(p)

    # Existing SubscriptionPayment without code — could add code later
    return {"payment_id": p.id, "subscription": {
        "status": sub.status,
        "current_period_end": sub.current_period_end.isoformat(),
    }}

@router.get("/payments")
def list_payments(session: Session = Depends(get_session),
                    b: Business = Depends(current_business)):
    return session.exec(select(SubscriptionPayment).where(
        SubscriptionPayment.business_id == b.id)
        .order_by(SubscriptionPayment.created_at.desc())).all()
