from fastapi import APIRouter, Depends, Query
from sqlmodel import Session, select
from app.db import get_session
from app.models import Customer, Order, User, Business
from app.auth import current_business

router = APIRouter(prefix="/api/search", tags=["search"])

@router.get("")
def search(q: str = Query(..., min_length=1),
           session: Session = Depends(get_session),
           b: Business = Depends(current_business)):
    like = f"%{q}%"
    customers = session.exec(select(Customer).where(Customer.business_id == b.id)
        .where((Customer.full_name.ilike(like)) | (Customer.phone.ilike(like))).limit(10)).all()
    orders = session.exec(select(Order).where(Order.business_id == b.id,
                                                Order.code.ilike(like)).limit(10)).all()
    users = session.exec(select(User).where(User.business_id == b.id,
                                              User.name.ilike(like)).limit(5)).all()
    return {"customers": [{"id": c.id, "label": c.full_name, "sub": c.phone} for c in customers],
            "orders": [{"id": o.id, "label": o.code, "sub": o.status} for o in orders],
            "staff": [{"id": u.id, "label": u.name, "sub": u.role} for u in users]}
