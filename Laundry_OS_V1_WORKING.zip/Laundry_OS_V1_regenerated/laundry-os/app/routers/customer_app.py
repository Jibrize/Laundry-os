from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session, select
from app.db import get_session
from app.models import (Business, Customer, CustomerUser, Service, Order,
                         OrderItem, OrderStatusEvent, Delivery)
from app.pricing import build_order_items
from app.qr import order_qr_payload
from app.audit import log
from app.notifications import notify_order_created
from app.routers.customer_auth import require_customer

router = APIRouter(prefix="/api/customer", tags=["customer-app"])

@router.get("/services")
def services(cu: CustomerUser = Depends(require_customer),
              session: Session = Depends(get_session)):
    rows = session.exec(select(Service).where(
        Service.business_id == cu.business_id, Service.active == True)
        .order_by(Service.name)).all()
    return [{"id": s.id, "name": s.name, "measurement": s.measurement,
              "price": s.price, "min_charge": s.min_charge} for s in rows]

@router.get("/orders")
def my_orders(cu: CustomerUser = Depends(require_customer),
               session: Session = Depends(get_session)):
    rows = session.exec(select(Order).where(
        Order.business_id == cu.business_id,
        Order.customer_id == cu.customer_id)
        .order_by(Order.created_at.desc())).all()
    out = []
    for o in rows:
        items = session.exec(select(OrderItem).where(OrderItem.order_id == o.id)).all()
        out.append({"id": o.id, "code": o.code, "status": o.status,
                    "total": o.total, "balance": o.balance,
                    "payment_status": o.payment_status,
                    "delivery_method": o.delivery_method,
                    "created_at": o.created_at.isoformat(),
                    "items": [{"name": i.service_name, "quantity": i.quantity,
                                "measurement": i.measurement, "subtotal": i.subtotal}
                               for i in items]})
    return out

@router.get("/orders/{oid}")
def order_detail(oid: int, cu: CustomerUser = Depends(require_customer),
                  session: Session = Depends(get_session)):
    o = session.get(Order, oid)
    if not o or o.business_id != cu.business_id or o.customer_id != cu.customer_id:
        raise HTTPException(404, "Order not found")
    items = session.exec(select(OrderItem).where(OrderItem.order_id == oid)).all()
    timeline = session.exec(select(OrderStatusEvent).where(
        OrderStatusEvent.order_id == oid).order_by(OrderStatusEvent.created_at)).all()
    return {"order": {"code": o.code, "status": o.status, "total": o.total,
                       "balance": o.balance, "payment_status": o.payment_status,
                       "delivery_method": o.delivery_method,
                       "created_at": o.created_at.isoformat()},
            "items": [{"name": i.service_name, "quantity": i.quantity,
                        "measurement": i.measurement, "unit_price": i.unit_price,
                        "subtotal": i.subtotal} for i in items],
            "timeline": [{"status": t.to_status, "at": t.created_at.isoformat(),
                           "note": t.note} for t in timeline]}

class CustomerOrderItem(BaseModel):
    service_id: int
    quantity: float

class CustomerOrderCreate(BaseModel):
    items: List[CustomerOrderItem]
    delivery_method: str = "delivery"
    address: Optional[str] = None
    notes: Optional[str] = None

@router.post("/orders")
async def create_order(payload: CustomerOrderCreate,
                        cu: CustomerUser = Depends(require_customer),
                        session: Session = Depends(get_session)):
    b = session.get(Business, cu.business_id)
    customer = session.get(Customer, cu.customer_id)
    if not payload.items: raise HTTPException(400, "At least one item required")
    class _I:
        def __init__(self, d): self.__dict__.update(d)
    items_in = [_I({"service_id": i.service_id, "quantity": i.quantity, "notes": None})
                for i in payload.items]
    items, subtotal = build_order_items(session, b.id, items_in)
    b.next_order_number += 1; session.add(b)
    code = f"#{b.next_order_number}"
    order = Order(business_id=b.id, code=code, customer_id=customer.id,
                   status=b.workflow_stages[0] if b.workflow_stages else "received",
                   subtotal=subtotal, delivery_method=payload.delivery_method,
                   notes=payload.notes, qr_payload=order_qr_payload(b.id, code))
    order.total = subtotal; order.balance = subtotal
    session.add(order); session.commit(); session.refresh(order)
    for it in items: it.order_id = order.id; session.add(it)
    session.add(OrderStatusEvent(order_id=order.id, to_status=order.status,
                                  note="Created via customer app"))
    if payload.delivery_method == "delivery":
        session.add(Delivery(business_id=b.id, order_id=order.id, kind="pickup",
                              address=payload.address or customer.address,
                              phone=customer.phone, status="pending"))
    log(session, b.id, None, "customer_app_order", "order", order.id,
        after={"code": code})
    session.commit()
    await notify_order_created(session, order)
    return {"ok": True, "code": code, "total": subtotal}

@router.post("/orders/{oid}/repeat")
async def repeat(oid: int, cu: CustomerUser = Depends(require_customer),
                  session: Session = Depends(get_session)):
    src = session.get(Order, oid)
    if not src or src.customer_id != cu.customer_id:
        raise HTTPException(404, "Order not found")
    src_items = session.exec(select(OrderItem).where(OrderItem.order_id == oid)).all()
    payload = CustomerOrderCreate(
        items=[{"service_id": it.service_id, "quantity": it.quantity} for it in src_items],
        delivery_method=src.delivery_method,
        notes=f"Repeat of {src.code}")
    return await create_order(payload, cu, session)
