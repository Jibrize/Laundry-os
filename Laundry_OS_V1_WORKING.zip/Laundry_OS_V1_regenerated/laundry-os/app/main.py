import os
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.db import init_db
from app.config import settings
from app.routers import (auth, business, customers, services, orders, payments,
                          work, deliveries, reports, dashboard, search,
                          inventory, expenses, audit, staff,
                          public, whatsapp, customer_auth, customer_app,
                          mpesa, notifications, ui,
                          uploads, subscription, partnerships)

app = FastAPI(title="Laundry OS", version="1.0.0")

from app.middleware import SubscriptionGateMiddleware
app.add_middleware(SubscriptionGateMiddleware)

@app.on_event("startup")
def on_startup():
    if settings.AUTO_CREATE_TABLES:
        init_db()

for r in (auth, business, customers, services, orders, payments,
          work, deliveries, reports, dashboard, search,
          inventory, expenses, audit, staff,
          public, whatsapp, customer_auth, customer_app,
          mpesa, notifications,
          uploads, subscription, partnerships,
          ui):
    app.include_router(r.router)

STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
app.mount("/static", StaticFiles(directory=STATIC), name="static")

# serve mock uploads when no real S3 credentials are configured
if settings.s3_mock:
    from app.storage import MOCK_DIR
    app.mount("/uploads", StaticFiles(directory=str(MOCK_DIR)), name="uploads")

RIDER_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "rider")
if os.path.isdir(RIDER_DIR):
    app.mount("/rider", StaticFiles(directory=RIDER_DIR, html=True), name="rider")

@app.get("/health")
def health():
    return {"ok": True}
