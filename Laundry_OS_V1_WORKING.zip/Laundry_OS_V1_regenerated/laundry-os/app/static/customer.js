const TOKEN = new URLSearchParams(location.search).get("t") || "";
const el = (id) => document.getElementById(id);
const esc = (s) => (s ?? "").toString().replace(/[&<>"']/g,
  c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
const fmtKes = (n) => "KES " + Math.round(n * 100) / 100;

const KEY = "laundryos_customer_key";
let state = { me: null, view: "orders", orders: [], services: [] };

async function api(path, opts = {}) {
  const k = localStorage.getItem(KEY);
  const headers = { "Content-Type": "application/json", ...(opts.headers || {}) };
  if (k) headers["x-api-key"] = k;
  const res = await fetch(path, { ...opts, headers });
  if (res.status === 401) { showAuth(); throw new Error("unauth"); }
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

function showAuth() {
  el("nav").innerHTML = "";
  el("main").innerHTML = `
    <div class="card">
      <h3>Sign in or register</h3>
      <label>Phone</label><input id="a_phone" />
      <label>Full name (for new accounts)</label><input id="a_name" />
      <label>Password</label><input id="a_pass" type="password" />
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px">
        <button class="primary" onclick="doRegister()">Register</button>
        <button class="ghost" onclick="doLogin()">Sign in</button>
      </div>
      <div class="muted" id="a_result" style="margin-top:8px"></div>
    </div>`;
}

window.doRegister = async function () {
  const res = await fetch("/api/customer/register", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token: TOKEN, phone: el("a_phone").value,
      full_name: el("a_name").value, password: el("a_pass").value }),
  });
  if (!res.ok) { el("a_result").textContent = await res.text(); return; }
  const data = await res.json();
  localStorage.setItem(KEY, data.api_key);
  location.reload();
};

window.doLogin = async function () {
  const res = await fetch("/api/customer/login", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token: TOKEN, phone: el("a_phone").value,
      password: el("a_pass").value }),
  });
  if (!res.ok) { el("a_result").textContent = await res.text(); return; }
  const data = await res.json();
  localStorage.setItem(KEY, data.api_key);
  location.reload();
};

const TABS = [
  { id: "orders", label: "Orders" },
  { id: "book", label: "Book" },
  { id: "me", label: "Me" },
];

function renderNav() {
  const nav = el("nav"); nav.innerHTML = "";
  TABS.forEach(t => {
    const b = document.createElement("button");
    b.className = state.view === t.id ? "active" : "";
    b.textContent = t.label;
    b.onclick = () => { state.view = t.id; render(); };
    nav.appendChild(b);
  });
}

async function viewOrders() {
  const list = await api("/api/customer/orders");
  return `
    <div class="card">
      <h3>My orders</h3>
      ${list.map(o => `
        <div class="list-row" onclick="openOrder(${o.id})">
          <div class="meta">
            <div><b>${esc(o.code)}</b> · ${esc(o.status)}</div>
            <div class="muted">${new Date(o.created_at).toLocaleDateString()} · bal ${fmtKes(o.balance)}</div>
          </div>
          <span class="chip ${o.payment_status}">${esc(o.payment_status)}</span>
        </div>`).join("") || `<div class="muted">No orders yet. Tap Book.</div>`}
    </div>`;
}

window.openOrder = async function (id) {
  const d = await api(`/api/customer/orders/${id}`);
  el("main").innerHTML = `
    <div class="card">
      <button class="ghost sm" onclick="render()">← Back</button>
      <h3 style="margin-top:10px">${esc(d.order.code)}</h3>
      <div><span class="chip">${esc(d.order.status)}</span> <span class="chip ${d.order.payment_status}">${esc(d.order.payment_status)}</span></div>
      <div class="muted">Total ${fmtKes(d.order.total)} · Balance ${fmtKes(d.order.balance)}</div>
      <div style="margin-top:10px">
        ${d.items.map(i => `<div class="muted">${i.quantity} ${esc(i.measurement)} ${esc(i.name)} — ${fmtKes(i.subtotal)}</div>`).join("")}
      </div>
      <h3 style="margin-top:14px">Timeline</h3>
      ${d.timeline.map(t => `<div class="muted">${new Date(t.at).toLocaleString()} · ${esc(t.status)}</div>`).join("")}
      <div style="margin-top:12px">
        <button class="ghost sm" onclick="repeatOrder(${id})">🔁 Repeat</button>
      </div>
    </div>`;
};

window.repeatOrder = async function (id) {
  await api(`/api/customer/orders/${id}/repeat`, { method: "POST" });
  state.view = "orders";
  render();
};

async function viewBook() {
  if (!state.services.length) state.services = await api("/api/customer/services");
  return `
    <div class="card">
      <h3>New booking</h3>
      <label>Pickup or drop-off?</label>
      <select id="bk_mode"><option value="delivery">Pickup</option><option value="pickup">Drop-off</option></select>
      <label>Address (if pickup)</label>
      <input id="bk_addr" />
      <div id="bk_items" style="margin-top:8px"></div>
      <button class="ghost sm" onclick="addLine()">+ Add item</button>
      <div class="stat" style="margin-top:10px"><b id="bk_total">KES 0</b><span class="muted">total</span></div>
      <div style="margin-top:10px"><button class="primary" onclick="submitBooking()">Place booking</button></div>
      <div class="muted" id="bk_result" style="margin-top:6px"></div>
    </div>`;
}

window.addLine = function () {
  const wrap = el("bk_items");
  const row = document.createElement("div");
  row.className = "line-row";
  row.innerHTML = `
    <select onchange="calcBook()">${state.services.map(s =>
      `<option value="${s.id}">${esc(s.name)} (${fmtKes(s.price)}/${esc(s.measurement)})</option>`).join("")}</select>
    <input type="number" step="0.1" oninput="calcBook()" placeholder="qty" />
    <button class="ghost sm" onclick="this.parentElement.remove();calcBook()">×</button>`;
  wrap.appendChild(row);
  calcBook();
};

window.calcBook = function () {
  let t = 0;
  [...document.querySelectorAll("#bk_items .line-row")].forEach(r => {
    const sid = parseInt(r.querySelector("select").value);
    const q = parseFloat(r.querySelector("input").value) || 0;
    const s = state.services.find(x => x.id === sid);
    if (s && q > 0) t += Math.max(q * s.price, s.min_charge || 0);
  });
  el("bk_total").textContent = fmtKes(t);
};

window.submitBooking = async function () {
  const items = [...document.querySelectorAll("#bk_items .line-row")].map(r => ({
    service_id: parseInt(r.querySelector("select").value),
    quantity: parseFloat(r.querySelector("input").value),
  })).filter(i => i.quantity > 0);
  try {
    const res = await api("/api/customer/orders", { method: "POST",
      body: JSON.stringify({ items, delivery_method: el("bk_mode").value,
        address: el("bk_addr").value || null }) });
    el("bk_result").innerHTML = `<span style="color:var(--ok)">Order ${esc(res.code)} created</span>`;
    state.view = "orders";
    setTimeout(render, 700);
  } catch (e) { el("bk_result").innerHTML = `<span style="color:var(--bad)">${esc(e.message)}</span>`; }
};

async function viewMe() {
  const me = await api("/api/customer/me");
  return `
    <div class="card">
      <h3>${esc(me.customer.full_name)}</h3>
      <div class="muted">${esc(me.customer.phone)}</div>
      <div class="muted">${esc(me.business.name)} · ${esc(me.business.phone || '')}</div>
      <div style="margin-top:10px">
        <button class="ghost sm" onclick="logout()">Sign out</button>
      </div>
    </div>`;
}

window.logout = function () { localStorage.removeItem(KEY); location.reload(); };

async function render() {
  renderNav();
  const main = el("main");
  try {
    if (state.view === "orders") main.innerHTML = await viewOrders();
    else if (state.view === "book") { main.innerHTML = await viewBook(); addLine(); }
    else if (state.view === "me") main.innerHTML = await viewMe();
  } catch (e) { main.innerHTML = `<div class="card"><div class="muted">${esc(e.message)}</div></div>`; }
}

(async function init() {
  if (!TOKEN) { el("main").innerHTML = `<div class="card"><div class="muted">Missing token. Use the link from your laundry.</div></div>`; return; }
  if (!localStorage.getItem(KEY)) { showAuth(); return; }
  try {
    state.me = await api("/api/customer/me");
    el("brand").textContent = state.me.business.name;
    render();
  } catch { showAuth(); }
})();
