const API_KEY = localStorage.getItem("laundryos_key") || "";
let state = {
  me: null, business: null, view: "home",
  orders: [], customers: [], services: [], work: { queue: {}, stages: [] },
  deliveries: [], selectedOrder: null, customersSearch: "",
};

const el = (id) => document.getElementById(id);
const esc = (s) => (s ?? "").toString().replace(/[&<>"']/g,
  c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
const fmtKes = (n) => "KES " + (Math.round(n * 100) / 100).toLocaleString();

function toast(msg) {
  const t = el("toast"); t.textContent = msg; t.classList.add("on");
  setTimeout(() => t.classList.remove("on"), 2200);
}

async function api(path, opts = {}) {
  const headers = { "Content-Type": "application/json", ...(opts.headers || {}) };
  if (API_KEY) headers["x-api-key"] = API_KEY;
  const res = await fetch(path, { ...opts, headers });
  if (res.status === 401) { loginScreen(); throw new Error("Unauthorized"); }
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

// ---------- Login ----------
function loginScreen() {
  el("nav").innerHTML = "";
  el("main").innerHTML = `
    <div class="card">
      <h2>Sign in</h2>
      <label>Phone</label>
      <input id="login_phone" placeholder="07..." />
      <label>Password</label>
      <input id="login_pass" type="password" />
      <div style="margin-top:12px">
        <button class="primary" onclick="doLogin()">Sign in</button>
      </div>
      <div class="muted" style="margin-top:10px">Demo (from seed): 0700000001 / owner123</div>
    </div>`;
}

window.doLogin = async function () {
  try {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        phone: el("login_phone").value.trim(),
        password: el("login_pass").value,
      }),
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    localStorage.setItem("laundryos_key", data.api_key);
    location.reload();
  } catch (e) { alert(e.message); }
};

// ---------- Nav ----------
const TABS = [
  { id: "home", label: "Home" },
  { id: "orders", label: "Orders" },
  { id: "customers", label: "Customers" },
  { id: "work", label: "Work" },
  { id: "more", label: "More" },
];

function renderNav() {
  const nav = el("nav"); nav.innerHTML = "";
  TABS.forEach(t => {
    const b = document.createElement("button");
    b.className = state.view === t.id ? "active" : "";
    b.textContent = t.label;
    b.onclick = () => { state.view = t.id; state.selectedOrder = null; render(); };
    nav.appendChild(b);
  });
  if (state.me) el("who").textContent = `${state.me.name} · ${state.me.role}`;
}

// ---------- Data loading ----------
async function loadAll() {
  state.business = await api("/api/business");
  state.orders = await api("/api/orders");
  state.customers = await api("/api/customers");
  state.services = await api("/api/services?active_only=true");
  state.work = await api("/api/work");
  state.deliveries = await api("/api/deliveries").catch(() => []);
}

// ---------- Home ----------
async function viewHome() {
  const d = await api("/api/dashboard");
  const t = d.today, p = d.processing;
  const isOwner = state.me && (state.me.role === "admin");
  return `
    <div class="card">
      <h3>Today</h3>
      <div class="grid2">
        <div><div class="stat"><b>${t.orders_received}</b><span class="muted">orders received</span></div></div>
        <div><div class="stat"><b>${fmtKes(t.sales_collected)}</b><span class="muted">collected</span></div></div>
      </div>
    </div>

    <div class="card">
      <h3>Work queue</h3>
      ${d.workflow_stages.map(s => `
        <div class="stage" onclick="gotoStage('${s}')">
          <span class="name">${s}</span>
          <span class="count">${p.counts_by_stage[s] || 0}</span>
        </div>
      `).join("")}
    </div>

    ${isOwner ? `
      <div class="card">
        <h3>Outstanding</h3>
        <div class="stat"><b>${fmtKes(d.outstanding_total)}</b></div>
      </div>` : ""}

    <div class="card">
      <h3>Quick actions</h3>
      <div class="grid2" style="gap:8px">
        <button class="quick" onclick="newOrderView()">+ NEW ORDER</button>
        <button class="quick" onclick="state.view='customers';render()">+ CUSTOMER</button>
        <button class="quick" onclick="recordPaymentFlow()">RECORD PAYMENT</button>
        <button class="quick" onclick="state.view='work';render()">VIEW WORK</button>
        <button class="quick" onclick="state.view='more';render()">DELIVERIES</button>
        <button class="quick" onclick="state.view='orders';render()">ALL ORDERS</button>
      </div>
    </div>`;
}

window.gotoStage = function (stage) {
  state.view = "orders";
  state.stageFilter = stage;
  render();
};

window.recordPaymentFlow = async function () {
  const code = prompt("Order number (e.g. #1042) or customer phone");
  if (!code) return;
  const found = state.orders.find(o =>
    o.code.toLowerCase() === code.toLowerCase() ||
    (o.customer && o.customer.phone === code));
  if (!found) return alert("Order not found");
  await openOrder(found.id);
  setTimeout(() => {
    const p = document.getElementById("pay_amt");
    if (p) p.focus();
  }, 200);
};

// ---------- Orders ----------
async function viewOrders() {
  const f = state.stageFilter;
  const list = f ? state.orders.filter(o => o.status === f) : state.orders;
  return `
    <div class="tabs">
      <button class="${!f ? 'active':''}" onclick="state.stageFilter=null;render()">All (${state.orders.length})</button>
      ${state.business.workflow_stages.map(s =>
        `<button class="${f===s?'active':''}" onclick="state.stageFilter='${s}';render()">${s} (${state.orders.filter(o=>o.status===s).length})</button>`
      ).join("")}
    </div>
    <div class="card">
      <div class="row">
        <input id="ord_q" placeholder="Search orders..." value="${esc(state.ordersSearch||'')}" oninput="state.ordersSearch=this.value;render()" />
        <button class="primary" onclick="newOrderView()">+ New order</button>
      </div>
    </div>
    <div class="card">
      ${list.filter(o => {
        const q = (state.ordersSearch||"").toLowerCase();
        return !q || (o.code.toLowerCase().includes(q)) ||
                     (o.customer && (o.customer.name.toLowerCase().includes(q) || o.customer.phone.includes(q)));
      }).map(o => `
        <div class="list-row" onclick="openOrder(${o.id})">
          <div class="meta">
            <div class="k">${esc(o.code)} · ${esc(o.customer?.name || '—')}</div>
            <div class="muted">${esc(o.customer?.phone || '')} · ${fmtKes(o.total)} · bal ${fmtKes(o.balance)}</div>
          </div>
          <span class="chip ${o.status}">${esc(o.status)}</span>
          <span class="chip ${o.payment_status}">${esc(o.payment_status)}</span>
        </div>`).join("") || `<div class="empty">No orders yet.<br><br><button class="primary" onclick="newOrderView()">+ New order</button></div>`}
    </div>`;
}

async function openOrder(id) {
  const data = await api(`/api/orders/${id}`);
  state.selectedOrder = data;
  render();
}

function viewOrderDetail() {
  const d = state.selectedOrder;
  if (!d) return viewOrders();
  const o = d.order, c = d.customer;
  const stages = state.business.workflow_stages;
  const curIdx = stages.indexOf(o.status);
  const nextStage = curIdx >= 0 && curIdx < stages.length - 1 ? stages[curIdx + 1] : null;

  return `
    <div class="card">
      <button class="ghost sm" onclick="state.selectedOrder=null;render()">← Back</button>
      <h2 style="margin-top:10px">${esc(o.code)} · ${esc(c.full_name)}</h2>
      <div class="muted">${esc(c.phone)} · ${esc(o.delivery_method)} · ${new Date(o.created_at).toLocaleString()}</div>
      <div style="margin-top:8px">
        <span class="chip ${o.status}">${esc(o.status)}</span>
        <span class="chip ${o.payment_status}">${esc(o.payment_status)}</span>
        <span class="pill">${fmtKes(o.total)} total</span>
        <span class="pill">${fmtKes(o.amount_paid)} paid</span>
        <span class="pill">${fmtKes(o.balance)} balance</span>
      </div>
    </div>

    <div class="card">
      <h3>Items</h3>
      ${d.items.map(i => `
        <div class="list-row" style="cursor:default">
          <div class="meta">
            <div class="k">${esc(i.service_name)}</div>
            <div class="muted">${i.quantity} ${esc(i.measurement)} × ${fmtKes(i.unit_price)}</div>
          </div>
          <div>${fmtKes(i.subtotal)}</div>
        </div>`).join("")}
      <div class="hr"></div>
      <div class="stat"><b>${fmtKes(o.subtotal)}</b><span class="muted">subtotal</span></div>
      ${o.delivery_fee ? `<div class="stat"><b>${fmtKes(o.delivery_fee)}</b><span class="muted">delivery fee</span></div>` : ""}
      <div class="stat"><b>${fmtKes(o.total)}</b><span class="muted">total</span></div>
    </div>

    <div class="card">
      <h3>Move production</h3>
      ${nextStage ? `<button class="primary" onclick="setStatus(${o.id},'${nextStage}')">→ ${nextStage}</button>` : ""}
      <div class="row3" style="margin-top:8px">
        ${stages.map(s => `<button class="ghost sm" onclick="setStatus(${o.id},'${s}')">${s}</button>`).join("")}
      </div>
      ${o.status !== "cancelled" && o.status !== "completed" ? `
        <div style="margin-top:8px">
          <button class="ghost sm" onclick="setStatus(${o.id},'cancelled')">Cancel order</button>
        </div>` : ""}
    </div>

    <div class="card">
      <h3>Payment</h3>
      <div class="row3">
        <input id="pay_amt" type="number" step="0.01" placeholder="Amount" />
        <select id="pay_meth"><option>mpesa</option><option>cash</option><option>card</option><option>other</option></select>
        <input id="pay_ref" placeholder="Reference" />
      </div>
      <div style="margin-top:8px">
        <button class="primary" onclick="recordPayment(${o.id})">Record payment</button>
      </div>
    </div>

    <div class="card">
      <h3>Inspection</h3>
      ${d.inspections.map(i => `
        <div class="list-row" style="cursor:default">
          <div class="meta"><div class="k">${esc(i.condition)}</div>
          <div class="muted">${esc(i.note||'')} · ${new Date(i.created_at).toLocaleString()}</div></div>
        </div>`).join("")}
      <div class="row3" style="margin-top:8px">
        <select id="ins_cond">
          <option value="stain">stain</option>
          <option value="tear">tear</option>
          <option value="missing_button">missing button</option>
          <option value="colour">colour</option>
          <option value="damage">damage</option>
          <option value="delicate">delicate</option>
          <option value="other">other</option>
        </select>
        <input id="ins_note" placeholder="note" />
        <button class="ghost sm" onclick="addInspection(${o.id})">Add</button>
      </div>
    </div>

    <div class="card">
      <h3>QR / tag</h3>
      ${d.qr.image_url ? `<img src="${d.qr.image_url}" style="background:#fff;border-radius:8px" width="150" />` : ""}
      <div class="muted" style="margin-top:6px">${esc(d.qr.payload || '')}</div>
    </div>

    <div class="card">
      <h3>Timeline</h3>
      ${d.timeline.map(t => `
        <div class="list-row" style="cursor:default">
          <div class="meta">
            <div class="k">${esc(t.to_status)}</div>
            <div class="muted">${new Date(t.created_at).toLocaleString()} ${t.note ? '· ' + esc(t.note) : ''}</div>
          </div>
        </div>`).join("")}
    </div>

    <div class="card">
      <button class="ghost sm" onclick="repeatOrder(${o.id})">🔁 Repeat order</button>
    </div>`;
}

window.setStatus = async function (oid, to) {
  try {
    await api(`/api/orders/${oid}/status`, {
      method: "POST", body: JSON.stringify({ to_status: to }),
    });
    toast(`Moved to ${to}`);
    state.selectedOrder = await api(`/api/orders/${oid}`);
    await loadAll(); render();
  } catch (e) { alert(e.message); }
};

window.recordPayment = async function (oid) {
  const amt = parseFloat(el("pay_amt").value);
  if (!amt) return;
  try {
    await api(`/api/orders/${oid}/payments`, {
      method: "POST",
      body: JSON.stringify({
        amount: amt, method: el("pay_meth").value,
        reference: el("pay_ref").value || null,
      }),
    });
    toast("Payment recorded");
    state.selectedOrder = await api(`/api/orders/${oid}`);
    await loadAll(); render();
  } catch (e) { alert(e.message); }
};

window.addInspection = async function (oid) {
  try {
    await api(`/api/orders/${oid}/inspection`, {
      method: "POST",
      body: JSON.stringify({
        condition: el("ins_cond").value,
        note: el("ins_note").value || null,
      }),
    });
    state.selectedOrder = await api(`/api/orders/${oid}`);
    render();
  } catch (e) { alert(e.message); }
};

window.repeatOrder = async function (oid) {
  try {
    const res = await api(`/api/orders/${oid}/repeat`, { method: "POST" });
    toast(`Created ${res.order.code}`);
    await loadAll();
    state.selectedOrder = res;
    render();
  } catch (e) { alert(e.message); }
};

// ---------- New order ----------
window.newOrderView = function () {
  state.selectedOrder = null;
  state.view = "new-order";
  render();
};

function viewNewOrder() {
  return `
    <div class="card">
      <button class="ghost sm" onclick="state.view='orders';render()">← Back</button>
      <h2 style="margin-top:10px">New order</h2>
      <label>Customer phone</label>
      <input id="no_phone" placeholder="07..." oninput="lookupCustomer()" />
      <div class="muted" id="no_lookup"></div>
      <div class="hr"></div>
      <div class="row">
        <div><label>Name</label><input id="no_name" /></div>
        <div><label>WhatsApp</label><input id="no_wa" /></div>
      </div>
      <label>Address</label>
      <input id="no_addr" />
    </div>

    <div class="card">
      <h3>Items</h3>
      <div id="no_items"></div>
      <div style="margin-top:8px">
        <button class="ghost sm" onclick="addItemLine()">+ Add item</button>
      </div>
      <div class="stat" style="margin-top:10px"><b id="no_total">KES 0</b><span class="muted">subtotal</span></div>
    </div>

    <div class="card">
      <h3>Delivery</h3>
      <div class="row">
        <select id="no_method" onchange="toggleDelivery()">
          <option value="pickup">Customer pickup</option>
          <option value="delivery">Delivery</option>
        </select>
        <input id="no_fee" type="number" step="10" placeholder="delivery fee" value="0" disabled />
      </div>
      <div id="no_delivery_addr" style="display:none">
        <label>Delivery address</label>
        <input id="no_daddr" />
      </div>
    </div>

    <div class="card">
      <button class="primary" onclick="submitOrder()">Create order</button>
    </div>`;
}

window.lookupCustomer = function () {
  const phone = el("no_phone").value.trim();
  const c = state.customers.find(x => x.phone === phone);
  if (c) {
    el("no_name").value = c.full_name;
    el("no_wa").value = c.whatsapp || "";
    el("no_addr").value = c.address || "";
    el("no_lookup").textContent = `Existing customer: ${c.full_name}`;
    state.lookupCustomerId = c.id;
  } else {
    el("no_lookup").textContent = phone ? "New customer — details below" : "";
    state.lookupCustomerId = null;
  }
};

window.toggleDelivery = function () {
  const m = el("no_method").value;
  el("no_fee").disabled = m !== "delivery";
  el("no_delivery_addr").style.display = m === "delivery" ? "block" : "none";
  el("no_fee").value = m === "delivery" ? (el("no_fee").value || 0) : 0;
  recalcTotal();
};

window.addItemLine = function (preset = {}) {
  const wrap = el("no_items");
  const row = document.createElement("div");
  row.className = "line-row";
  const options = state.services.map(s =>
    `<option value="${s.id}" ${preset.service_id===s.id?'selected':''}>${esc(s.name)} (${esc(s.measurement)} · ${fmtKes(s.price)})</option>`).join("");
  row.innerHTML = `
    <select class="ln_svc" onchange="recalcTotal()">${options}</select>
    <input class="ln_qty" type="number" step="0.1" placeholder="qty / kg" value="${preset.quantity||''}" oninput="recalcTotal()" />
    <span class="ln_sub muted">—</span>
    <button class="ghost sm" onclick="this.parentElement.remove();recalcTotal()">×</button>`;
  wrap.appendChild(row);
  recalcTotal();
};

window.recalcTotal = function () {
  let total = 0;
  [...document.querySelectorAll("#no_items .line-row")].forEach(r => {
    const sid = parseInt(r.querySelector(".ln_svc").value);
    const qty = parseFloat(r.querySelector(".ln_qty").value) || 0;
    const svc = state.services.find(s => s.id === sid);
    if (!svc || qty <= 0) { r.querySelector(".ln_sub").textContent = "—"; return; }
    let line = qty * svc.price;
    if (svc.min_charge) line = Math.max(line, svc.min_charge);
    r.querySelector(".ln_sub").textContent = fmtKes(line);
    total += line;
  });
  const fee = parseFloat(el("no_fee")?.value || 0) || 0;
  el("no_total").textContent = fmtKes(total + fee);
  state.newOrderSubtotal = total;
};

window.submitOrder = async function () {
  const items = [...document.querySelectorAll("#no_items .line-row")].map(r => ({
    service_id: parseInt(r.querySelector(".ln_svc").value),
    quantity: parseFloat(r.querySelector(".ln_qty").value),
  })).filter(i => i.quantity > 0);
  if (!items.length) return alert("Add at least one item");

  const payload = {
    items,
    delivery_method: el("no_method").value,
    delivery_fee: parseFloat(el("no_fee").value) || 0,
    delivery_address: el("no_daddr")?.value || null,
    customer_id: state.lookupCustomerId || null,
    customer_name: el("no_name").value || null,
    customer_phone: el("no_phone").value || null,
    customer_whatsapp: el("no_wa").value || null,
    customer_address: el("no_addr").value || null,
  };
  if (!payload.customer_id && (!payload.customer_phone || !payload.customer_name)) {
    return alert("Customer name and phone required");
  }
  try {
    const res = await api("/api/orders", {
      method: "POST", body: JSON.stringify(payload),
    });
    toast(`Order ${res.order.code} created`);
    await loadAll();
    state.selectedOrder = res;
    state.view = "orders";
    render();
  } catch (e) { alert(e.message); }
};

// ---------- Customers ----------
async function viewCustomers() {
  const q = (state.customersSearch || "").toLowerCase();
  const list = state.customers.filter(c =>
    !q || c.full_name.toLowerCase().includes(q) || c.phone.includes(q));
  return `
    <div class="card">
      <div class="row">
        <input placeholder="Search..." value="${esc(state.customersSearch||'')}" oninput="state.customersSearch=this.value;render()" />
        <button class="primary" onclick="newCustomerView()">+ New</button>
      </div>
    </div>
    <div class="card">
      ${list.map(c => `
        <div class="list-row" onclick="openCustomer(${c.id})">
          <div class="meta">
            <div class="k">${esc(c.full_name)}</div>
            <div class="muted">${esc(c.phone)} ${c.address ? '· ' + esc(c.address) : ''}</div>
          </div>
        </div>`).join("") || `<div class="empty">Your customer list will appear here as orders are created.</div>`}
    </div>`;
}

window.newCustomerView = function () {
  const name = prompt("Full name"); if (!name) return;
  const phone = prompt("Phone"); if (!phone) return;
  const addr = prompt("Address (optional)") || null;
  api("/api/customers", { method: "POST",
    body: JSON.stringify({ full_name: name, phone, address: addr }) })
    .then(async () => { await loadAll(); toast("Customer added"); render(); })
    .catch(e => alert(e.message));
};

async function openCustomer(id) {
  const data = await api(`/api/customers/${id}`);
  const c = data.customer, s = data.stats;
  state.selectedCustomer = data;
  state.view = "customer-detail";
  render();
}

function viewCustomerDetail() {
  const d = state.selectedCustomer;
  if (!d) return viewCustomers();
  const c = d.customer, s = d.stats;
  return `
    <div class="card">
      <button class="ghost sm" onclick="state.view='customers';render()">← Back</button>
      <h2 style="margin-top:10px">${esc(c.full_name)}</h2>
      <div class="muted">${esc(c.phone)} ${c.whatsapp ? '· wa ' + esc(c.whatsapp) : ''}</div>
      <div class="muted">${esc(c.address || '')}</div>
      <div class="grid3" style="margin-top:10px">
        <div><div class="stat"><b>${s.orders_count}</b><span class="muted">orders</span></div></div>
        <div><div class="stat"><b>${fmtKes(s.total_spent)}</b><span class="muted">spent</span></div></div>
        <div><div class="stat"><b>${fmtKes(s.outstanding)}</b><span class="muted">outstanding</span></div></div>
      </div>
    </div>
    <div class="card">
      <h3>Order history</h3>
      ${d.orders.map(o => `
        <div class="list-row" onclick="openOrder(${o.id})">
          <div class="meta">
            <div class="k">${esc(o.code)} · ${fmtKes(o.total)}</div>
            <div class="muted">${new Date(o.created_at).toLocaleDateString()} · bal ${fmtKes(o.balance)}</div>
          </div>
          <span class="chip ${o.status}">${esc(o.status)}</span>
        </div>`).join("") || `<div class="muted">No orders yet.</div>`}
    </div>`;
}

// ---------- Work ----------
async function viewWork() {
  const w = state.work;
  return `
    ${w.stages.map(stage => `
      <div class="card">
        <h3>${stage.toUpperCase()}</h3>
        ${(w.queue[stage] || []).map(o => `
          <div class="list-row" onclick="openOrder(${o.id})">
            <div class="meta">
              <div class="k">${esc(o.code)} · ${esc(o.customer_name)}</div>
              <div class="muted">${esc(o.summary)}</div>
            </div>
            <span class="chip">${esc(o.status)}</span>
          </div>`).join("") || `<div class="muted">Empty</div>`}
      </div>
    `).join("")}`;
}

// ---------- More / settings / deliveries / reports / staff ----------
function viewMore() {
  const me = state.me || {};
  const isOwner = me.role === "admin";
  return `
    <div class="card">
      <h3>Signed in</h3>
      <div class="muted">${esc(me.name)} · ${esc(me.role)} · business ${me.business_id}</div>
      <div style="margin-top:8px">
        <button class="ghost sm" onclick="logout()">Sign out</button>
      </div>
    </div>
    <div class="card">
      <h3>Sections</h3>
      <div class="grid2" style="gap:8px">
        <button class="quick" onclick="state.view='deliveries';render()">DELIVERIES</button>
        <button class="quick" onclick="state.view='reports';render()">REPORTS</button>
        <button class="quick" onclick="state.view='services';render()">SERVICES</button>
        ${isOwner ? `<button class="quick" onclick="state.view='business';render()">BUSINESS</button>` : ""}
      </div>
    </div>`;
}

window.logout = function () {
  localStorage.removeItem("laundryos_key");
  location.reload();
};

async function viewDeliveries() {
  const d = await api("/api/deliveries");
  return `
    <div class="card">
      <button class="ghost sm" onclick="state.view='more';render()">← Back</button>
      <h3 style="margin-top:10px">Deliveries</h3>
      ${d.map(x => `
        <div class="list-row" style="cursor:default">
          <div class="meta">
            <div class="k">${esc(x.order_code || '')} · ${esc(x.customer_name || '')}</div>
            <div class="muted">${esc(x.kind)} · ${esc(x.address || '')} ${x.rider_name ? '· ' + esc(x.rider_name) : ''}</div>
          </div>
          <span class="chip ${x.status}">${esc(x.status)}</span>
        </div>`).join("") || `<div class="empty">No deliveries scheduled.</div>`}
    </div>`;
}

async function viewReports() {
  const r = await api("/api/reports/daily");
  return `
    <div class="card">
      <button class="ghost sm" onclick="state.view='more';render()">← Back</button>
      <h3 style="margin-top:10px">Today</h3>
      <div class="stat"><b>${r.orders_count}</b><span class="muted">orders</span></div>
      <div class="stat"><b>${fmtKes(r.revenue_billed)}</b><span class="muted">billed</span></div>
      <div class="stat"><b>${fmtKes(r.revenue_collected)}</b><span class="muted">collected</span></div>
      <div class="stat"><b>${fmtKes(r.outstanding)}</b><span class="muted">outstanding</span></div>
      <div class="muted" style="margin-top:8px">${esc(r.note)}</div>
    </div>`;
}

async function viewServices() {
  const s = await api("/api/services");
  const isManager = state.me && ["admin"].includes(state.me.role);
  return `
    <div class="card">
      <button class="ghost sm" onclick="state.view='more';render()">← Back</button>
      <h3 style="margin-top:10px">Services</h3>
      ${isManager ? `<button class="primary sm" onclick="addServiceFlow()">+ Add service</button>` : ""}
      <div style="margin-top:10px">
        ${s.map(x => `
          <div class="list-row" style="cursor:default">
            <div class="meta">
              <div class="k">${esc(x.name)}</div>
              <div class="muted">${esc(x.measurement)} · ${fmtKes(x.price)}${x.min_charge ? ' · min ' + fmtKes(x.min_charge) : ''} ${x.active ? '' : ' · INACTIVE'}</div>
            </div>
            ${isManager ? `<button class="ghost sm" onclick="editServiceFlow(${x.id}, ${x.price})">edit</button>` : ""}
          </div>`).join("")}
      </div>
    </div>`;
}

window.addServiceFlow = function () {
  const name = prompt("Service name"); if (!name) return;
  const measurement = prompt("Measurement (item / kg / pair / sqm / piece)", "item");
  const price = parseFloat(prompt("Price per " + measurement, "0"));
  const min_charge = parseFloat(prompt("Minimum charge (0 if none)", "0")) || 0;
  api("/api/services", { method: "POST", body: JSON.stringify({
    name, measurement, price, min_charge,
  })}).then(async () => { await loadAll(); toast("Service added"); render(); })
      .catch(e => alert(e.message));
};

window.editServiceFlow = function (id, current) {
  const price = parseFloat(prompt("New price", current));
  if (isNaN(price)) return;
  api(`/api/services/${id}`, { method: "PATCH", body: JSON.stringify({ price }) })
    .then(async () => { await loadAll(); toast("Price updated"); render(); })
    .catch(e => alert(e.message));
};

async function viewBusiness() {
  const b = state.business;
  return `
    <div class="card">
      <button class="ghost sm" onclick="state.view='more';render()">← Back</button>
      <h3 style="margin-top:10px">Business settings</h3>
      <label>Name</label><input id="biz_name" value="${esc(b.name)}" />
      <label>Phone</label><input id="biz_phone" value="${esc(b.phone||'')}" />
      <label>WhatsApp</label><input id="biz_wa" value="${esc(b.whatsapp||'')}" />
      <label>Address</label><input id="biz_addr" value="${esc(b.address||'')}" />
      <label>Workflow stages (comma-separated)</label>
      <input id="biz_flow" value="${esc((b.workflow_stages||[]).join(', '))}" />
      <div style="margin-top:8px">
        <label><input type="checkbox" id="biz_credit" ${b.allow_credit ? 'checked' : ''} /> Allow credit (overpayment)</label>
      </div>
      <div style="margin-top:12px">
        <button class="primary" onclick="saveBusiness()">Save</button>
      </div>
    </div>`;
}

window.saveBusiness = async function () {
  const stages = el("biz_flow").value.split(",").map(s => s.trim()).filter(Boolean);
  try {
    await api("/api/business", { method: "PATCH", body: JSON.stringify({
      name: el("biz_name").value,
      phone: el("biz_phone").value || null,
      whatsapp: el("biz_wa").value || null,
      address: el("biz_addr").value || null,
      workflow_stages: stages,
      allow_credit: el("biz_credit").checked,
    })});
    toast("Saved");
    await loadAll(); render();
  } catch (e) { alert(e.message); }
};

// ---------- Render ----------
async function render() {
  renderNav();
  const main = el("main");
  try {
    if (state.view === "home") main.innerHTML = await viewHome();
    else if (state.view === "orders") main.innerHTML = state.selectedOrder ? viewOrderDetail() : await viewOrders();
    else if (state.view === "new-order") { main.innerHTML = viewNewOrder(); addItemLine(); }
    else if (state.view === "customers") main.innerHTML = await viewCustomers();
    else if (state.view === "customer-detail") main.innerHTML = viewCustomerDetail();
    else if (state.view === "work") main.innerHTML = await viewWork();
    else if (state.view === "more") main.innerHTML = viewMore();
    else if (state.view === "deliveries") main.innerHTML = await viewDeliveries();
    else if (state.view === "reports") main.innerHTML = await viewReports();
    else if (state.view === "services") main.innerHTML = await viewServices();
    else if (state.view === "business") main.innerHTML = await viewBusiness();
  } catch (e) {
    main.innerHTML = `<div class="card"><div class="muted">Error: ${esc(e.message)}</div></div>`;
  }
}

// ---------- Init ----------
(async function init() {
  if (!API_KEY) { loginScreen(); return; }
  try {
    state.me = await api("/api/auth/me");
    await loadAll();
    render();
    setInterval(async () => { try { await loadAll(); if (!state.selectedOrder) render(); } catch {} }, 12000);
  } catch (e) {
    loginScreen();
  }
})();
