const TOKEN = location.pathname.split("/")[2];
const el = (id) => document.getElementById(id);
const esc = (s) => (s ?? "").toString().replace(/[&<>"']/g,
  c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
const fmtKes = (n) => "KES " + Math.round(n * 100) / 100;

let services = [];

async function api(path, opts = {}) {
  const res = await fetch(path, {
    ...opts, headers: { "Content-Type": "application/json", ...(opts.headers || {}) },
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

async function load() {
  try {
    const info = await api(`/api/public/${TOKEN}/info`);
    services = info.services;
    el("bizname").textContent = info.business.name;
    el("main").innerHTML = view(info);
    addLine();
  } catch (e) {
    el("main").innerHTML = `<div class="card"><div class="muted">Invalid booking link.</div></div>`;
  }
}

function view(info) {
  const b = info.business;
  return `
    <div class="card">
      <div class="muted">${esc(b.address||'')} · ${esc(b.phone||'')}</div>
      <h3 style="margin-top:10px">Your details</h3>
      <label>Full name</label><input id="c_name" />
      <label>Phone</label><input id="c_phone" />
      <label>WhatsApp (optional)</label><input id="c_wa" />
      <label>Address</label><input id="c_addr" />
    </div>
    <div class="card">
      <h3>Items</h3>
      <div id="items"></div>
      <button class="ghost" style="margin-top:8px" onclick="addLine()">+ Add item</button>
      <div class="stat" style="margin-top:10px"><b id="total">KES 0</b><span class="muted">total</span></div>
    </div>
    <div class="card">
      <h3>Pickup or drop-off</h3>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <button class="ghost" id="pk_pickup" onclick="setPickup(true)">Pickup</button>
        <button class="ghost" id="pk_dropoff" onclick="setPickup(false)">Drop-off</button>
      </div>
      <div id="pickup_hint" class="muted" style="margin-top:6px"></div>
    </div>
    <div class="card">
      <label>Notes (optional)</label>
      <textarea id="c_notes" rows="2"></textarea>
    </div>
    <div class="card">
      <button class="primary" onclick="submit()">Place booking</button>
      <div id="result" class="muted" style="margin-top:8px"></div>
    </div>`;
}

let isPickup = true;
window.setPickup = function (v) {
  isPickup = v;
  el("pk_pickup").style.background = v ? "#1a2745" : "";
  el("pk_dropoff").style.background = !v ? "#1a2745" : "";
  el("pickup_hint").textContent = v
    ? "We'll pick up from your address."
    : "Bring it to our shop. Address above.";
};

window.addLine = function () {
  const wrap = el("items");
  const row = document.createElement("div");
  row.className = "line-row";
  row.innerHTML = `
    <select onchange="calc()">${services.map(s =>
      `<option value="${s.id}">${esc(s.name)} (${esc(s.measurement)} · ${fmtKes(s.price)})</option>`).join("")}</select>
    <input type="number" step="0.1" placeholder="qty" oninput="calc()" />
    <button class="ghost" onclick="this.parentElement.remove();calc()">×</button>`;
  wrap.appendChild(row);
  calc();
};

window.calc = function () {
  let t = 0;
  [...document.querySelectorAll("#items .line-row")].forEach(r => {
    const sid = parseInt(r.querySelector("select").value);
    const q = parseFloat(r.querySelector("input").value) || 0;
    const s = services.find(x => x.id === sid);
    if (s && q > 0) t += Math.max(q * s.price, s.min_charge || 0);
  });
  el("total").textContent = fmtKes(t);
};

window.submit = async function () {
  const items = [...document.querySelectorAll("#items .line-row")].map(r => ({
    service_id: parseInt(r.querySelector("select").value),
    quantity: parseFloat(r.querySelector("input").value),
  })).filter(i => i.quantity > 0);

  const payload = {
    full_name: el("c_name").value.trim(),
    phone: el("c_phone").value.trim(),
    whatsapp: el("c_wa").value.trim() || null,
    address: el("c_addr").value.trim() || null,
    pickup: isPickup,
    notes: el("c_notes").value.trim() || null,
    items,
  };
  try {
    const res = await api(`/api/public/${TOKEN}/orders`, {
      method: "POST", body: JSON.stringify(payload),
    });
    el("result").innerHTML = `
      <div style="color:var(--ok);font-weight:600">Booked! Order ${esc(res.order_code)}</div>
      <div class="muted">Total ${fmtKes(res.total)}. We'll call ${esc(res.business_phone||'')}.</div>`;
  } catch (e) {
    el("result").innerHTML = `<span style="color:var(--bad)">${esc(e.message)}</span>`;
  }
};

load();
