import os
import uuid
import mimetypes
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import boto3
from botocore.exceptions import BotoCoreError, ClientError
from fastapi import HTTPException, UploadFile

from app.config import settings

MOCK_DIR = Path(os.getenv("UPLOAD_MOCK_DIR", "./uploads"))
MOCK_DIR.mkdir(parents=True, exist_ok=True)

def _ext_for(filename: Optional[str], content_type: Optional[str]) -> str:
    if filename and "." in filename:
        return "." + filename.rsplit(".", 1)[1].lower()
    if content_type:
        ext = mimetypes.guess_extension(content_type.split(";")[0].strip())
        if ext:
            return ext
    return ".bin"

def _key(business_id: int, folder: str, ext: str) -> str:
    date = datetime.now(timezone.utc).strftime("%Y/%m/%d")
    return f"businesses/{business_id}/{folder}/{date}/{uuid.uuid4().hex}{ext}"

def _s3_client():
    return boto3.client(
        "s3",
        endpoint_url=settings.S3_ENDPOINT or None,
        region_name=settings.S3_REGION,
        aws_access_key_id=settings.S3_ACCESS_KEY,
        aws_secret_access_key=settings.S3_SECRET_KEY,
    )

async def upload_photo(file: UploadFile, business_id: int,
                        folder: str = "photos") -> dict:
    """
    Upload an image. Returns {url, key, size_bytes, content_type}.
    Mock mode (no S3 creds): writes to ./uploads/ and returns a /uploads/<key> URL.
    """
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(400, "Only image uploads are accepted")

    data = await file.read()
    max_bytes = settings.UPLOAD_MAX_MB * 1024 * 1024
    if len(data) > max_bytes:
        raise HTTPException(413, f"File larger than {settings.UPLOAD_MAX_MB}MB")
    if len(data) == 0:
        raise HTTPException(400, "Empty file")

    ext = _ext_for(file.filename, file.content_type)
    key = _key(business_id, folder, ext)

    if settings.s3_mock:
        local_path = MOCK_DIR / key
        local_path.parent.mkdir(parents=True, exist_ok=True)
        local_path.write_bytes(data)
        return {
            "url": f"/uploads/{key}",
            "key": key,
            "size_bytes": len(data),
            "content_type": file.content_type,
            "mock": True,
        }

    try:
        client = _s3_client()
        client.put_object(
            Bucket=settings.S3_BUCKET,
            Key=key,
            Body=data,
            ContentType=file.content_type,
            CacheControl="public, max-age=31536000, immutable",
        )
    except (BotoCoreError, ClientError) as e:
        raise HTTPException(500, f"Upload failed: {e}")

    base = settings.S3_PUBLIC_BASE_URL.rstrip("/") if settings.S3_PUBLIC_BASE_URL \
        else f"{settings.S3_ENDPOINT.rstrip('/')}/{settings.S3_BUCKET}"
    return {
        "url": f"{base}/{key}",
        "key": key,
        "size_bytes": len(data),
        "content_type": file.content_type,
        "mock": False,
    }
