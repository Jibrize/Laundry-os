import base64, json, os, secrets
from datetime import datetime, timezone
from typing import Optional
import httpx
from fastapi import HTTPException
from sqlmodel import Session, select
from app.models import Business, MpesaPayment, Order, Payment

BASE_URLS = {
    "sandbox": "https://sandbox.safaricom.co.ke",
    "production": "https://api.safaricom.co.ke",
}

def _creds(b: Business) -> dict:
    return {
        "consumer_key": b.mpesa_consumer_key or os.getenv("MPESA_CONSUMER_KEY", ""),
        "consumer_secret": b.mpesa_consumer_secret or os.getenv("MPESA_CONSUMER_SECRET", ""),
        "shortcode": b.mpesa_shortcode or os.getenv("MPESA_SHORTCODE", ""),
        "passkey": b.mpesa_passkey or os.getenv("MPESA_PASSKEY", ""),
        "env": b.mpesa_env or os.getenv("MPESA_ENV", "sandbox"),
    }

def _is_mock(b: Business) -> bool:
    c = _creds(b)
    return not (c["consumer_key"] and c["consumer_secret"]
                and c["shortcode"] and c["passkey"])

def _normalize_phone(phone: str) -> str:
    p = phone.strip().replace(" ", "").replace("+", "")
    if p.startswith("0"): p = "254" + p[1:]
    elif p.startswith("7") and len(p) == 9: p = "254" + p
    return p

async def _access_token(creds: dict) -> str:
    url = f"{BASE_URLS[creds['env']]}/oauth/v1/generate?grant_type=client_credentials"
    auth = base64.b64encode(f"{creds['consumer_key']}:{creds['consumer_secret']}".encode()).decode()
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(url, headers={"Authorization": f"Basic {auth}"})
        r.raise_for_status()
        return r.json()["access_token"]

def _apply_success(session: Session, business: Business, rec: MpesaPayment):
    order = session.get(Order, rec.order_id)
    if not order: return
    p = Payment(business_id=business.id, order_id=order.id,
                 amount=rec.amount, method="mpesa",
                 reference=rec.mpesa_receipt,
                 note=f"STK push {rec.checkout_request_id}")
    session.add(p); session.commit(); session.refresh(p)
    p.code = f"PY-{p.id:05d}"; session.add(p)
    from app.routers.orders import _recompute
    order.amount_paid = round(order.amount_paid + rec.amount, 2)
    _recompute(order); session.add(order)
    rec.payment_id = p.id

async def initiate_stk_push(session: Session, business: Business, order: Order,
                             phone: str, amount: float, callback_url: str,
                             account_reference: Optional[str] = None) -> MpesaPayment:
    creds = _creds(business)
    phone_norm = _normalize_phone(phone)
    amount = round(amount, 2)
    if amount <= 0: raise HTTPException(400, "Amount must be positive")

    rec = MpesaPayment(business_id=business.id, order_id=order.id,
                        phone=phone_norm, amount=amount,
                        account_reference=account_reference or order.code,
                        status="pending")
    session.add(rec); session.commit(); session.refresh(rec)

    if _is_mock(business):
        rec.status = "success"; rec.result_code = 0
        rec.result_desc = "Mock success"
        rec.mpesa_receipt = f"MOCK{secrets.randbelow(90_000_000) + 10_000_000}"
        rec.completed_at = datetime.now(timezone.utc)
        _apply_success(session, business, rec)
        session.commit(); session.refresh(rec)
        return rec

    token = await _access_token(creds)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    password = base64.b64encode(f"{creds['shortcode']}{creds['passkey']}{ts}".encode()).decode()
    body = {
        "BusinessShortCode": creds["shortcode"],
        "Password": password, "Timestamp": ts,
        "TransactionType": "CustomerPayBillOnline",
        "Amount": int(amount), "PartyA": phone_norm, "PartyB": creds["shortcode"],
        "PhoneNumber": phone_norm, "CallBackURL": callback_url,
        "AccountReference": (rec.account_reference or "LaundryOS")[:12],
        "TransactionDesc": f"Laundry order {order.code}",
    }
    url = f"{BASE_URLS[creds['env']]}/mpesa/stkpush/v1/processrequest"
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post(url, json=body, headers={"Authorization": f"Bearer {token}"})
    data = r.json() if r.status_code == 200 else {"error": r.text}
    rec.raw_callback = json.dumps(data)
    if r.status_code == 200 and data.get("CheckoutRequestID"):
        rec.checkout_request_id = data["CheckoutRequestID"]
        rec.merchant_request_id = data.get("MerchantRequestID")
    else:
        rec.status = "failed"
        rec.result_desc = data.get("errorMessage") or str(data)[:200]
    session.add(rec); session.commit(); session.refresh(rec)
    return rec

async def handle_callback(session: Session, body: dict):
    stk = (body or {}).get("Body", {}).get("stkCallback", {})
    checkout_id = stk.get("CheckoutRequestID")
    if not checkout_id: return
    rec = session.exec(select(MpesaPayment).where(
        MpesaPayment.checkout_request_id == checkout_id)).first()
    if not rec or rec.status != "pending": return
    rec.raw_callback = json.dumps(body)
    code = stk.get("ResultCode"); rec.result_code = code
    rec.result_desc = stk.get("ResultDesc")
    if code == 0:
        items = stk.get("CallbackMetadata", {}).get("Item", [])
        for it in items:
            if it.get("Name") == "MpesaReceiptNumber":
                rec.mpesa_receipt = str(it.get("Value"))
        rec.status = "success"; rec.completed_at = datetime.now(timezone.utc)
        biz = session.get(Business, rec.business_id)
        if biz: _apply_success(session, biz, rec)
    elif code == 1032:
        rec.status = "cancelled"; rec.completed_at = datetime.now(timezone.utc)
    else:
        rec.status = "failed"; rec.completed_at = datetime.now(timezone.utc)
    session.add(rec); session.commit()
    if rec.status in ("success", "failed") and rec.order_id:
        from app.notifications import notify_payment_result
        o = session.get(Order, rec.order_id)
        if o: await notify_payment_result(session, o, rec)
