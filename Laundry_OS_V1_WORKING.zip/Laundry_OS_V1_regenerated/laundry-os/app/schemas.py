from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel

class LoginRequest(BaseModel):
    phone: str
    password: str

class BusinessUpdate(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    whatsapp: Optional[str] = None
    address: Optional[str] = None
    opening_hours: Optional[str] = None
    logo_url: Optional[str] = None
    workflow_stages: Optional[List[str]] = None
    allow_credit: Optional[bool] = None
    brand_color: Optional[str] = None
    tagline: Optional[str] = None
    hero_url: Optional[str] = None
    terms: Optional[str] = None
    mpesa_shortcode: Optional[str] = None
    mpesa_passkey: Optional[str] = None
    mpesa_consumer_key: Optional[str] = None
    mpesa_consumer_secret: Optional[str] = None
    mpesa_env: Optional[str] = None
    notify_on_status_change: Optional[bool] = None
    notify_on_payment: Optional[bool] = None
    notify_on_delivery: Optional[bool] = None

class CustomerCreate(BaseModel):
    full_name: str
    phone: str
    whatsapp: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None

class CustomerUpdate(BaseModel):
    full_name: Optional[str] = None
    phone: Optional[str] = None
    whatsapp: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None

class ServiceCreate(BaseModel):
    name: str
    category: Optional[str] = None
    measurement: str = "item"
    price: float
    min_charge: float = 0.0
    turnaround_hours: int = 24
    instructions: Optional[str] = None

class ServiceUpdate(BaseModel):
    name: Optional[str] = None
    category: Optional[str] = None
    measurement: Optional[str] = None
    price: Optional[float] = None
    min_charge: Optional[float] = None
    turnaround_hours: Optional[int] = None
    active: Optional[bool] = None
    instructions: Optional[str] = None

class OrderItemInput(BaseModel):
    service_id: int
    quantity: float
    notes: Optional[str] = None

class OrderCreate(BaseModel):
    customer_id: Optional[int] = None
    customer_name: Optional[str] = None
    customer_phone: Optional[str] = None
    customer_whatsapp: Optional[str] = None
    customer_address: Optional[str] = None
    items: List[OrderItemInput] = []
    delivery_method: str = "pickup"
    delivery_fee: float = 0.0
    delivery_address: Optional[str] = None
    notes: Optional[str] = None
    expected_at: Optional[datetime] = None

class StatusUpdate(BaseModel):
    to_status: str
    note: Optional[str] = None

class InspectionCreate(BaseModel):
    condition: str
    note: Optional[str] = None
    photo_url: Optional[str] = None

class QCCreate(BaseModel):
    checklist: Dict[str, bool]
    result: str
    reason: Optional[str] = None

class PaymentCreate(BaseModel):
    amount: float
    method: str = "mpesa"
    reference: Optional[str] = None
    note: Optional[str] = None

class DeliveryCreate(BaseModel):
    order_id: int
    kind: str = "delivery"
    rider_id: Optional[int] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    fee: float = 0.0
    scheduled_at: Optional[datetime] = None
    notes: Optional[str] = None

class DeliveryUpdate(BaseModel):
    rider_id: Optional[int] = None
    status: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    fee: Optional[float] = None
    scheduled_at: Optional[datetime] = None
    notes: Optional[str] = None

class StaffCreate(BaseModel):
    name: str
    phone: str
    password: str
    role: str = "attendant"

class SubscriptionUpsert(BaseModel):
    plan: Optional[str] = None
    status: Optional[str] = None
    price_monthly: Optional[float] = None
    currency: Optional[str] = None
    billing_cycle: Optional[str] = None
    current_period_end: Optional[datetime] = None
    grace_days: Optional[int] = None
    notes: Optional[str] = None

class SubscriptionPaymentCreate(BaseModel):
    amount: float
    method: str = "mpesa"
    reference: Optional[str] = None
    period_end: Optional[datetime] = None
    note: Optional[str] = None

class PartnershipCreate(BaseModel):
    to_business_id: int
    kind: str = "referral"
    revenue_split_pct: float = 0.0
    terms: Optional[str] = None

class PartnershipUpdate(BaseModel):
    kind: Optional[str] = None
    revenue_split_pct: Optional[float] = None
    status: Optional[str] = None
    terms: Optional[str] = None

class ReferralCreate(BaseModel):
    phone: str
    to_customer_id: Optional[int] = None
    notes: Optional[str] = None

class CommissionCreate(BaseModel):
    amount: float
    method: str = "mpesa"
    reference: Optional[str] = None
    note: Optional[str] = None
