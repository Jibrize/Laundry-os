from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
from sqlmodel import SQLModel, Field
from sqlalchemy import Column, JSON

def utcnow():
    return datetime.now(timezone.utc)

# ================= Business & users =================
class Business(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    slug: Optional[str] = Field(default=None, index=True)
    phone: Optional[str] = None
    whatsapp: Optional[str] = None
    address: Optional[str] = None
    opening_hours: Optional[str] = None
    logo_url: Optional[str] = None
    currency: str = "KES"
    workflow_stages: List[str] = Field(
        default_factory=lambda: ["received", "washing", "drying", "ready", "completed"],
        sa_column=Column(JSON))
    allow_credit: bool = False
    next_order_number: int = 1000

    brand_color: str = "#3b82f6"
    tagline: Optional[str] = None
    hero_url: Optional[str] = None
    terms: Optional[str] = None

    mpesa_shortcode: Optional[str] = None
    mpesa_passkey: Optional[str] = None
    mpesa_consumer_key: Optional[str] = None
    mpesa_consumer_secret: Optional[str] = None
    mpesa_env: str = "sandbox"

    notify_on_status_change: bool = True
    notify_on_payment: bool = True
    notify_on_delivery: bool = True

    created_at: datetime = Field(default_factory=utcnow)
    updated_at: datetime = Field(default_factory=utcnow)

class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    name: str
    phone: str = Field(index=True)
    role: str = "attendant"     # admin | attendant | rider
    api_key: str = Field(index=True, unique=True)
    password_hash: str
    active: bool = True
    created_at: datetime = Field(default_factory=utcnow)

# ================= Customers =================
class Customer(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    full_name: str
    phone: str = Field(index=True)
    whatsapp: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=utcnow)

class CustomerUser(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    customer_id: int = Field(foreign_key="customer.id", index=True)
    phone: str = Field(index=True)
    password_hash: str
    api_key: str = Field(index=True, unique=True)
    active: bool = True
    created_at: datetime = Field(default_factory=utcnow)

# ================= Services =================
class Service(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    name: str
    category: Optional[str] = None
    measurement: str = "item"   # item | kg | pair | sqm | piece
    price: float = 0.0
    min_charge: float = 0.0
    turnaround_hours: int = 24
    active: bool = True
    instructions: Optional[str] = None
    created_at: datetime = Field(default_factory=utcnow)

# ================= Orders =================
class Order(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    code: str = Field(index=True)
    customer_id: int = Field(foreign_key="customer.id", index=True)
    status: str = "received"
    pricing_mode: str = "mixed"
    subtotal: float = 0.0
    delivery_fee: float = 0.0
    total: float = 0.0
    amount_paid: float = 0.0
    balance: float = 0.0
    payment_status: str = "unpaid"
    delivery_method: str = "pickup"
    notes: Optional[str] = None
    qr_payload: Optional[str] = None
    intake_at: datetime = Field(default_factory=utcnow)
    expected_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_by: Optional[int] = Field(default=None, foreign_key="user.id")
    assigned_to: Optional[int] = Field(default=None, foreign_key="user.id")
    created_at: datetime = Field(default_factory=utcnow)
    updated_at: datetime = Field(default_factory=utcnow)

class OrderItem(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    order_id: int = Field(foreign_key="order.id", index=True)
    service_id: int = Field(foreign_key="service.id")
    service_name: str
    measurement: str
    quantity: float
    unit_price: float
    subtotal: float
    notes: Optional[str] = None

class OrderStatusEvent(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    order_id: int = Field(foreign_key="order.id", index=True)
    from_status: Optional[str] = None
    to_status: str
    note: Optional[str] = None
    actor_id: Optional[int] = Field(default=None, foreign_key="user.id")
    created_at: datetime = Field(default_factory=utcnow)

class Inspection(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    order_id: int = Field(foreign_key="order.id", index=True)
    condition: str
    note: Optional[str] = None
    photo_url: Optional[str] = None
    recorded_by: Optional[int] = Field(default=None, foreign_key="user.id")
    created_at: datetime = Field(default_factory=utcnow)

class QCResult(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    order_id: int = Field(foreign_key="order.id", index=True)
    checklist: Dict[str, bool] = Field(default_factory=dict, sa_column=Column(JSON))
    result: str = "pass"
    reason: Optional[str] = None
    inspected_by: Optional[int] = Field(default=None, foreign_key="user.id")
    created_at: datetime = Field(default_factory=utcnow)

# ================= Payments =================
class Payment(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    order_id: int = Field(foreign_key="order.id", index=True)
    code: Optional[str] = None
    amount: float
    method: str = "mpesa"
    reference: Optional[str] = None
    note: Optional[str] = None
    recorded_by: Optional[int] = Field(default=None, foreign_key="user.id")
    created_at: datetime = Field(default_factory=utcnow)

class MpesaPayment(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    order_id: int = Field(foreign_key="order.id", index=True)
    merchant_request_id: Optional[str] = Field(default=None, index=True)
    checkout_request_id: Optional[str] = Field(default=None, index=True, unique=True)
    phone: str
    amount: float
    account_reference: Optional[str] = None
    status: str = "pending"
    result_code: Optional[int] = None
    result_desc: Optional[str] = None
    mpesa_receipt: Optional[str] = None
    raw_callback: Optional[str] = None
    payment_id: Optional[int] = Field(default=None, foreign_key="payment.id")
    created_at: datetime = Field(default_factory=utcnow)
    completed_at: Optional[datetime] = None

# ================= Deliveries =================
class Delivery(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    order_id: int = Field(foreign_key="order.id", index=True)
    rider_id: Optional[int] = Field(default=None, foreign_key="user.id")
    kind: str = "delivery"
    address: Optional[str] = None
    phone: Optional[str] = None
    fee: float = 0.0
    status: str = "pending"
    scheduled_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=utcnow)
    updated_at: datetime = Field(default_factory=utcnow)

# ================= Inventory & expenses =================
class InventoryItem(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    name: str
    unit: str = "unit"
    quantity: float = 0.0
    min_level: float = 0.0
    unit_cost: float = 0.0
    supplier: Optional[str] = None
    updated_at: datetime = Field(default_factory=utcnow)

class InventoryTxn(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    item_id: int = Field(foreign_key="inventoryitem.id", index=True)
    delta: float
    reason: Optional[str] = None
    actor_id: Optional[int] = Field(default=None, foreign_key="user.id")
    created_at: datetime = Field(default_factory=utcnow)

class Expense(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    category: str
    amount: float
    note: Optional[str] = None
    recorded_by: Optional[int] = Field(default=None, foreign_key="user.id")
    created_at: datetime = Field(default_factory=utcnow)

# ================= Audit & idempotency =================
class AuditLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    actor_id: Optional[int] = Field(default=None, foreign_key="user.id")
    action: str
    entity_type: str
    entity_id: Optional[int] = None
    before_json: Optional[str] = None
    after_json: Optional[str] = None
    created_at: datetime = Field(default_factory=utcnow)

class IdempotencyKey(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    key: str = Field(index=True, unique=True)
    action: str
    entity_type: Optional[str] = None
    entity_id: Optional[int] = None
    created_at: datetime = Field(default_factory=utcnow)

# ================= Channel adapters =================
class BookingLink(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True, unique=True)
    token: str = Field(index=True, unique=True)
    active: bool = True
    created_at: datetime = Field(default_factory=utcnow)

class WhatsAppNumber(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    phone_number_id: str = Field(index=True, unique=True)
    display_number: Optional[str] = None
    verify_token: str = "change-me-verify"
    active: bool = True
    created_at: datetime = Field(default_factory=utcnow)

class WhatsAppSession(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    phone: str = Field(index=True)
    state: str = "start"
    data: Dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    updated_at: datetime = Field(default_factory=utcnow)

class WhatsAppMessage(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    message_id: str = Field(index=True, unique=True)
    direction: str = "in"
    phone: str = Field(index=True)
    body: Optional[str] = None
    created_at: datetime = Field(default_factory=utcnow)

# ================= Notifications =================
class NotificationTemplate(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    event: str = Field(index=True)
    channel: str = "whatsapp"
    body: str
    active: bool = True
    created_at: datetime = Field(default_factory=utcnow)

class NotificationLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    customer_id: Optional[int] = Field(default=None, foreign_key="customer.id")
    channel: str
    event: str
    body: str
    phone: Optional[str] = None
    status: str = "sent"
    error: Optional[str] = None
    created_at: datetime = Field(default_factory=utcnow)

# ================= Subscription =================
class Subscription(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True, unique=True)
    plan: str = "standard"        # trial | starter | standard | pro | custom
    status: str = "active"        # active | past_due | suspended | cancelled
    price_monthly: float = 0.0
    currency: str = "KES"
    billing_cycle: str = "monthly"   # monthly | quarterly | annual
    started_at: datetime = Field(default_factory=utcnow)
    current_period_start: datetime = Field(default_factory=utcnow)
    current_period_end: Optional[datetime] = None
    grace_days: int = 7              # days past period_end before writes are blocked
    suspended_at: Optional[datetime] = None
    cancelled_at: Optional[datetime] = None
    notes: Optional[str] = None
    updated_at: datetime = Field(default_factory=utcnow)

class SubscriptionPayment(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    business_id: int = Field(foreign_key="business.id", index=True)
    subscription_id: int = Field(foreign_key="subscription.id", index=True)
    amount: float
    method: str = "mpesa"
    reference: Optional[str] = None
    period_start: Optional[datetime] = None
    period_end: Optional[datetime] = None
    note: Optional[str] = None
    recorded_by_id: Optional[int] = Field(default=None, foreign_key="user.id")
    created_at: datetime = Field(default_factory=utcnow)

# ================= Partnership =================
class Partnership(SQLModel, table=True):
    """
    Two businesses that refer customers to each other.
    No shared orders, no shared staff, no shared PII. Referral tracking only.
    """
    id: Optional[int] = Field(default=None, primary_key=True)
    from_business_id: int = Field(foreign_key="business.id", index=True)
    to_business_id: int = Field(foreign_key="business.id", index=True)
    kind: str = "referral"        # referral | bundle | cross_promo
    revenue_split_pct: float = 0.0    # what % of referred revenue goes to from_business
    status: str = "active"        # pending | active | paused | ended
    terms: Optional[str] = None
    started_at: datetime = Field(default_factory=utcnow)
    ended_at: Optional[datetime] = None
    created_by_id: Optional[int] = Field(default=None, foreign_key="user.id")
    created_at: datetime = Field(default_factory=utcnow)

class PartnershipReferral(SQLModel, table=True):
    """
    A single referred customer: same human, two businesses, no PII sharing.
    The laundry knows the customer as one of its own; the perfume shop knows
    the same phone as one of its own. The referral row is the only bridge.
    """
    id: Optional[int] = Field(default=None, primary_key=True)
    partnership_id: int = Field(foreign_key="partnership.id", index=True)
    from_business_id: int = Field(foreign_key="business.id", index=True)
    to_business_id: int = Field(foreign_key="business.id", index=True)
    phone: str = Field(index=True)       # the only shared field
    from_customer_id: Optional[int] = Field(default=None, foreign_key="customer.id")
    to_customer_id: Optional[int] = Field(default=None, foreign_key="customer.id")
    referred_at: datetime = Field(default_factory=utcnow)
    first_order_at: Optional[datetime] = None
    revenue_attributed: float = 0.0      # running total of referred revenue
    commission_owed: float = 0.0
    commission_paid: float = 0.0
    status: str = "open"                  # open | converted | paid | voided
    notes: Optional[str] = None

class PartnershipCommission(SQLModel, table=True):
    """Settlement event: how much from_business is owed for referred revenue."""
    id: Optional[int] = Field(default=None, primary_key=True)
    partnership_id: int = Field(foreign_key="partnership.id", index=True)
    amount: float
    period_start: Optional[datetime] = None
    period_end: Optional[datetime] = None
    method: str = "mpesa"                 # mpesa | bank | offset
    reference: Optional[str] = None
    note: Optional[str] = None
    recorded_by_id: Optional[int] = Field(default=None, foreign_key="user.id")
    created_at: datetime = Field(default_factory=utcnow)
