"""
Subscription gate.

If a business is past its subscription period + grace days, block write requests
(POST/PATCH/PUT/DELETE) with 402 Payment Required. GET requests always pass —
read-only data stays visible to the owner.

Skips:
  - /api/auth/* (login must work)
  - /api/subscription/* (must be able to pay to fix this)
  - /webhooks/* (external callers)
  - /health, /, /book/*, /customer/* (public surface)
"""
from datetime import datetime, timezone
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
from sqlmodel import Session, select

from app.db import engine
from app.models import User, Subscription, Business

WRITE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}
SKIP_PREFIXES = (
    "/api/auth/",
    "/api/subscription/",
    "/webhooks/",
    "/health",
    "/book/",
    "/customer",
    "/",
    "/static/",
    "/uploads/",
    "/rider/",
)

class SubscriptionGateMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        path = request.url.path
        if request.method not in WRITE_METHODS:
            return await call_next(request)
        if any(path.startswith(p) for p in SKIP_PREFIXES):
            return await call_next(request)

        api_key = request.headers.get("x-api-key")
        if not api_key:
            return await call_next(request)   # let auth handle it

        with Session(engine) as s:
            user = s.exec(select(User).where(User.api_key == api_key,
                                               User.active == True)).first()
            if not user:
                return await call_next(request)
            sub = s.exec(select(Subscription).where(
                Subscription.business_id == user.business_id)).first()
            if not sub:
                return await call_next(request)   # legacy business, no sub row

            now = datetime.now(timezone.utc)
            if sub.status == "suspended":
                return JSONResponse(
                    {"detail": "Subscription suspended. Contact support."},
                    status_code=402)
            if sub.status == "cancelled":
                return JSONResponse(
                    {"detail": "Subscription cancelled. Contact support."},
                    status_code=402)

            if sub.current_period_end:
                grace_end = sub.current_period_end
                # period_end already includes grace; treat as hard limit
                if now > grace_end:
                    return JSONResponse(
                        {"detail": f"Subscription past due. Please renew.",
                         "period_end": sub.current_period_end.isoformat(),
                         "grace_days": sub.grace_days},
                        status_code=402)

        return await call_next(request)
