import os
from dotenv import load_dotenv
load_dotenv()

class Settings:
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./laundryos.db")
    SECRET_SALT = os.getenv("SECRET_SALT", "change-me-salt")
    AUTO_CREATE_TABLES = os.getenv("AUTO_CREATE_TABLES", "true").lower() == "true"
    ALLOW_CREDIT_DEFAULT = os.getenv("ALLOW_CREDIT_DEFAULT", "false").lower() == "true"

    WHATSAPP_TOKEN = os.getenv("WHATSAPP_TOKEN", "")
    WHATSAPP_VERIFY_TOKEN = os.getenv("WHATSAPP_VERIFY_TOKEN", "change-me-verify")

    MPESA_CONSUMER_KEY = os.getenv("MPESA_CONSUMER_KEY", "")
    MPESA_CONSUMER_SECRET = os.getenv("MPESA_CONSUMER_SECRET", "")
    MPESA_SHORTCODE = os.getenv("MPESA_SHORTCODE", "")
    MPESA_PASSKEY = os.getenv("MPESA_PASSKEY", "")
    MPESA_ENV = os.getenv("MPESA_ENV", "sandbox")

    S3_ENDPOINT = os.getenv("S3_ENDPOINT", "")
    S3_REGION = os.getenv("S3_REGION", "us-east-1")
    S3_BUCKET = os.getenv("S3_BUCKET", "")
    S3_ACCESS_KEY = os.getenv("S3_ACCESS_KEY", "")
    S3_SECRET_KEY = os.getenv("S3_SECRET_KEY", "")
    S3_PUBLIC_BASE_URL = os.getenv("S3_PUBLIC_BASE_URL", "")
    UPLOAD_MAX_MB = int(os.getenv("UPLOAD_MAX_MB", "8"))

    @property
    def s3_mock(self) -> bool:
        return not (self.S3_BUCKET and self.S3_ACCESS_KEY and self.S3_SECRET_KEY)

settings = Settings()
