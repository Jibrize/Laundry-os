from sqlmodel import Session
from app.models import Service, OrderItem

def price_item(service: Service, quantity: float) -> float:
    if quantity <= 0:
        return 0.0
    raw = round(quantity * service.price, 2)
    return round(max(raw, service.min_charge or 0.0), 2)

def build_order_items(session: Session, business_id: int, items_input):
    out = []
    subtotal = 0.0
    for it in items_input:
        s = session.get(Service, it.service_id)
        if not s or s.business_id != business_id:
            raise ValueError(f"Service {it.service_id} not found")
        if not s.active:
            raise ValueError(f"Service {s.name} is inactive")
        line = price_item(s, it.quantity)
        subtotal += line
        out.append(OrderItem(
            service_id=s.id, service_name=s.name,
            measurement=s.measurement, quantity=it.quantity,
            unit_price=s.price, subtotal=line,
            notes=getattr(it, "notes", None),
        ))
    return out, round(subtotal, 2)
