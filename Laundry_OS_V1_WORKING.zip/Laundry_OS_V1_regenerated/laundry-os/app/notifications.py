import os
from typing import Optional
from sqlmodel import Session, select
import httpx
from app.models import Business, Customer, NotificationTemplate, NotificationLog, Order, Delivery

WA_TOKEN = os.getenv("WHATSAPP_TOKEN", "")

DEFAULTS = {
    "order.created": "Hi {customer_name}, we've received order {order_code} ({total}). — {business_name}",
    "order.status": "Hi {customer_name}, order {order_code} is now: {status}. — {business_name}",
    "order.ready": "Hi {customer_name}, order {order_code} is ready. Total {total}, balance {balance}. — {business_name}",
    "order.completed": "Hi {customer_name}, order {order_code} is complete. Thank you — {business_name}.",
    "payment.received": "Hi {customer_name}, we received {amount} for {order_code}. Balance {balance}. — {business_name}",
    "payment.failed": "Hi {customer_name}, payment for {order_code} did not go through. — {business_name}",
    "delivery.status": "Hi {customer_name}, delivery for {order_code} is now: {status}. — {business_name}",
}

def _template(session, business_id, event):
    row = session.exec(select(NotificationTemplate).where(
        NotificationTemplate.business_id == business_id,
        NotificationTemplate.event == event,
        NotificationTemplate.active == True)).first()
    return row.body if row else DEFAULTS.get(event, "")

def _render(t, ctx):
    try: return t.format(**{k: ("" if v is None else v) for k, v in ctx.items()})
    except KeyError: return t

def _phone_for_business(session, business_id):
    from app.models import WhatsAppNumber
    row = session.exec(select(WhatsAppNumber).where(
        WhatsAppNumber.business_id == business_id,
        WhatsAppNumber.active == True)).first()
    return row.phone_number_id if row else None

async def _send_whatsapp(to, text, phone_number_id=None):
    pid = phone_number_id
    if not (WA_TOKEN and pid):
        print(f"[WA-MOCK] to={to} :: {text}")
        return {"ok": True, "mock": True}
    url = f"https://graph.facebook.com/v20.0/{pid}/messages"
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.post(url, headers={"Authorization": f"Bearer {WA_TOKEN}"},
                               json={"messaging_product": "whatsapp", "to": to,
                                     "type": "text", "text": {"body": text}})
        return {"ok": r.status_code == 200, "status": r.status_code}

async def send_notification(session: Session, business: Business,
                             customer: Optional[Customer], event: str,
                             ctx: Optional[dict] = None):
    if not customer or not customer.phone: return
    tmpl = _template(session, business.id, event)
    if not tmpl: return
    full = {"business_name": business.name,
            "customer_name": customer.full_name or "there",
            "currency": business.currency, **(ctx or {})}
    body = _render(tmpl, full)
    log = NotificationLog(business_id=business.id, customer_id=customer.id,
                           channel="whatsapp", event=event, body=body,
                           phone=customer.phone)
    try:
        res = await _send_whatsapp(customer.phone, body,
                                     _phone_for_business(session, business.id))
        log.status = "sent" if res.get("ok") else "failed"
        if not res.get("ok"): log.error = str(res)[:200]
    except Exception as e:
        log.status = "failed"; log.error = str(e)[:200]
    session.add(log); session.commit()

async def notify_order_created(session, order: Order):
    b = session.get(Business, order.business_id)
    if not b or not b.notify_on_status_change: return
    c = session.get(Customer, order.customer_id)
    await send_notification(session, b, c, "order.created",
        {"order_code": order.code, "total": f"{b.currency} {order.total:.2f}"})

async def notify_status_change(session, order: Order, from_s, to_s):
    b = session.get(Business, order.business_id)
    if not b or not b.notify_on_status_change: return
    c = session.get(Customer, order.customer_id)
    event = "order.status"
    if to_s == "ready": event = "order.ready"
    elif to_s == "completed": event = "order.completed"
    await send_notification(session, b, c, event,
        {"order_code": order.code, "status": to_s,
         "total": f"{b.currency} {order.total:.2f}",
         "balance": f"{b.currency} {order.balance:.2f}"})

async def notify_payment_received(session, order: Order, amount: float):
    b = session.get(Business, order.business_id)
    if not b or not b.notify_on_payment: return
    c = session.get(Customer, order.customer_id)
    await send_notification(session, b, c, "payment.received",
        {"order_code": order.code, "amount": f"{b.currency} {amount:.2f}",
         "balance": f"{b.currency} {order.balance:.2f}"})

async def notify_payment_result(session, order: Order, rec):
    b = session.get(Business, order.business_id)
    if not b or not b.notify_on_payment: return
    c = session.get(Customer, order.customer_id)
    if rec.status == "success":
        await send_notification(session, b, c, "payment.received",
            {"order_code": order.code, "amount": f"{b.currency} {rec.amount:.2f}",
             "balance": f"{b.currency} {order.balance:.2f}"})
    else:
        await send_notification(session, b, c, "payment.failed", {"order_code": order.code})

async def notify_delivery_status(session, delivery: Delivery, to_s):
    b = session.get(Business, delivery.business_id)
    if not b or not b.notify_on_delivery: return
    o = session.get(Order, delivery.order_id)
    if not o: return
    c = session.get(Customer, o.customer_id)
    await send_notification(session, b, c, "delivery.status",
        {"order_code": o.code, "status": to_s})
