# Laundry OS

Multi-tenant SaaS for laundry businesses. Mixed pricing, configurable workflow, offline rider, M-Pesa STK push, WhatsApp + booking + customer app, photo uploads, subscriptions, and cross-business partnerships, on one backend.

## Run

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python seed.py
uvicorn app.main:app --reload
```

- Dashboard:    http://localhost:8000
- Booking page: http://localhost:8000/book/<token>  (printed by seed)
- Customer app: http://localhost:8000/customer?t=<token>
- Rider PWA:    http://localhost:8000/rider/
- API docs:     http://localhost:8000/docs

Login (from seed): `0700000001` / `admin123`
Demo partner business login: `0720000001` / `partner123`

## Tests

```bash
pytest -v
```

## Migrations

```bash
alembic revision --autogenerate -m "message"
alembic upgrade head
```

Set `AUTO_CREATE_TABLES=false` in `.env` once you use Alembic in production.

## Roles

admin · attendant · rider (customer accounts are separate)

## What's in the box

- Multi-tenant schema, one install hosts many laundries
- Mixed pricing (item / kg / piece / pair / sqm) in a single order
- Configurable workflow stages per business
- Inspection, QC, audit log, per-order QR payload
- Inventory, expenses, monthly/service reports
- Public booking page with per-business branding
- WhatsApp webhook, multi-tenant by `phone_number_id`
- Customer app (register, book, track, repeat)
- M-Pesa STK push + callback (real or mock)
- Auto-notifications with per-business templates
- Rider PWA with offline status queue
- Photo uploads (S3-compatible; falls back to local mock storage in dev)
- Per-business subscriptions with a payment-gate middleware
- Cross-business partnerships and referral tracking, with commission settlement
- Alembic migrations
- Pytest suite covering money paths, multi-tenancy isolation, M-Pesa idempotency, and offline replay
- GitHub Actions CI (lint, tests on 3.11/3.12, migrations check)
