from datetime import datetime, timezone, timedelta
from sqlmodel import Session, select
from app.db import init_db, engine
from app.models import (Business, User, Customer, Service, Order, OrderItem,
                         OrderStatusEvent, Payment, Delivery, Inspection,
                         QCResult, InventoryItem, Expense, AuditLog)
from app.auth import hash_password, new_api_key
from app.pricing import build_order_items
from app.schemas import OrderItemInput

init_db()

with Session(engine) as s:
    if s.exec(select(Business)).first():
        print("Already seeded."); raise SystemExit

    b = Business(
        name="FreshFold Laundry",
        phone="0700123456", whatsapp="0700123456",
        address="Kilimani, Nairobi",
        opening_hours="Mon–Sat 7am–8pm",
        workflow_stages=["received", "washing", "drying", "ready", "completed"],
        allow_credit=False,
        next_order_number=1040,
    )
    s.add(b); s.commit(); s.refresh(b)

    # Users
    def mk(name, phone, pw, role):
        u = User(business_id=b.id, name=name, phone=phone, role=role,
                 api_key=new_api_key(), password_hash=hash_password(pw))
        s.add(u); s.commit(); s.refresh(u); return u

    admin = mk("Alice (Admin)", "0700000001", "admin123", "admin")
    attendant = mk("Ben (Attendant)", "0700000002", "attendant123", "attendant")
    attendant2 = mk("Cate (Attendant)", "0700000003", "attendant2123", "attendant")
    attendant3 = mk("Wanjiru (Attendant)", "0700000004", "attendant3123", "attendant")
    rider   = mk("Kevin (Rider)",   "0700000005", "rider123",   "rider")

    # Services — measurement is a property of the service
    services = [
        Service(business_id=b.id, name="Wash + Fold", measurement="kg",
                price=120, min_charge=200, category="bulk"),
        Service(business_id=b.id, name="Wash + Iron", measurement="kg",
                price=150, min_charge=250, category="bulk"),
        Service(business_id=b.id, name="Iron Only", measurement="kg",
                price=90, min_charge=150, category="bulk"),
        Service(business_id=b.id, name="Shirt", measurement="item", price=100),
        Service(business_id=b.id, name="Trouser", measurement="item", price=120),
        Service(business_id=b.id, name="Dress", measurement="item", price=150),
        Service(business_id=b.id, name="Suit (2-piece)", measurement="item", price=600),
        Service(business_id=b.id, name="Duvet", measurement="piece", price=800),
        Service(business_id=b.id, name="Blanket", measurement="piece", price=500),
        Service(business_id=b.id, name="Shoes", measurement="pair", price=250),
        Service(business_id=b.id, name="Curtain (per sqm)", measurement="sqm", price=180),
        Service(business_id=b.id, name="Carpet (per sqm)", measurement="sqm", price=200),
    ]
    for x in services: s.add(x)
    s.commit()
    for x in services: s.refresh(x)
    S = {x.name: x for x in services}

    # Customers
    customers = [
        Customer(business_id=b.id, full_name="Ahmed Hassan", phone="0711000001",
                 whatsapp="0711000001", address="Lavington, House 14"),
        Customer(business_id=b.id, full_name="Mary Wanjiku", phone="0711000002",
                 whatsapp="0711000002", address="Kileleshwa Apt 3B"),
        Customer(business_id=b.id, full_name="John Otieno", phone="0711000003",
                 address="Kilimani"),
        Customer(business_id=b.id, full_name="Priya Shah", phone="0711000004",
                 whatsapp="0711000004", address="Westlands"),
        Customer(business_id=b.id, full_name="Brian Kimani", phone="0711000005",
                 address="Kileleshwa"),
    ]
    for x in customers: s.add(x)
    s.commit()
    for x in customers: s.refresh(x)

    # Helper: create a demo order with items, payments, events
    def make_order(customer, item_specs, status, delivery_method="pickup",
                   paid=0.0, fee=0.0, notes=None, days_ago=0, inspection=None,
                   delivery_status=None):
        items, subtotal = build_order_items(s, b.id,
            [OrderItemInput(service_id=S[n].id, quantity=q) for (n, q) in item_specs])
        b.next_order_number += 1
        order = Order(
            business_id=b.id,
            code=f"#{b.next_order_number}",
            customer_id=customer.id,
            status=status,
            subtotal=subtotal,
            delivery_fee=fee,
            delivery_method=delivery_method,
            notes=notes,
            created_by=attendant.id,
            intake_at=datetime.now(timezone.utc) - timedelta(days=days_ago),
            created_at=datetime.now(timezone.utc) - timedelta(days=days_ago),
        )
        order.total = round(subtotal + fee, 2)
        order.amount_paid = round(paid, 2)
        order.balance = round(order.total - order.amount_paid, 2)
        order.payment_status = "paid" if order.balance <= 0 else ("partial" if paid > 0 else "unpaid")
        s.add(order); s.commit(); s.refresh(order)
        order.qr_payload = f"LAUNDRYOS:{b.id}:{order.code.lstrip('#')}"
        s.add(order)
        for it in items:
            it.order_id = order.id; s.add(it)
        s.add(OrderStatusEvent(order_id=order.id, to_status="received",
                                note="Order created", actor_id=attendant.id))
        if status != "received":
            s.add(OrderStatusEvent(order_id=order.id, from_status="received",
                                    to_status=status, actor_id=attendant3.id))
        if paid > 0:
            p = Payment(business_id=b.id, order_id=order.id, amount=paid,
                        method="mpesa", reference=f"QK{order.id:06d}",
                        recorded_by=attendant.id)
            s.add(p); s.commit(); s.refresh(p)
            p.code = f"PY-{p.id:05d}"; s.add(p)
        if inspection:
            s.add(Inspection(order_id=order.id, condition=inspection[0],
                              note=inspection[1], recorded_by=attendant3.id))
        if delivery_method == "delivery":
            s.add(Delivery(business_id=b.id, order_id=order.id, kind="delivery",
                            rider_id=rider.id if delivery_status else None,
                            address=customer.address, phone=customer.phone,
                            fee=fee, status=delivery_status or "pending"))
        s.commit()
        return order

    # Example from the spec (#1042 — mixed pricing, washing, deposit paid)
    make_order(customers[0],
               [("Shirt", 5), ("Trouser", 3), ("Wash + Iron", 8.4)],
               status="washing", delivery_method="pickup",
               paid=500, fee=0, notes="Mixed order from spec example",
               inspection=("tear", "Existing tear on left sleeve."))

    # A few more, spread across stages
    make_order(customers[1], [("Wash + Fold", 12.5)], "drying",
               paid=1000, days_ago=1)
    make_order(customers[2], [("Shirt", 3), ("Iron Only", 2.0)], "ironing",
               paid=300, days_ago=1,
               inspection=("stain", "Coffee stain on collar."))
    make_order(customers[3], [("Duvet", 2), ("Blanket", 1)], "qc",
               paid=0, days_ago=2)
    make_order(customers[4], [("Wash + Iron", 6.0)], "ready",
               paid=900, days_ago=2)
    make_order(customers[0], [("Suit (2-piece)", 1), ("Shirt", 2)], "ready",
               paid=700, days_ago=3)
    make_order(customers[1], [("Shoes", 2), ("Wash + Fold", 5.0)], "completed",
               paid=900, days_ago=4)
    make_order(customers[2], [("Curtain (per sqm)", 8.5)], "completed",
               paid=1530, days_ago=5,
               inspection=("delicate", "Handle gently — hand wash only."))
    make_order(customers[3], [("Wash + Fold", 15.0)], "completed",
               paid=1800, delivery_method="delivery", fee=200, days_ago=6,
               delivery_status="delivered")
    make_order(customers[4], [("Carpet (per sqm)", 12.0)], "washing",
               paid=0, days_ago=0,
               inspection=("damage", "Pre-existing frayed edge."))
    make_order(customers[0], [("Shirt", 10)], "received", paid=0, days_ago=0)
    make_order(customers[2], [("Wash + Fold", 8.0), ("Duvet", 1)], "received",
               paid=0, days_ago=0)
    make_order(customers[1], [("Iron Only", 4.5)], "completed",
               paid=405, days_ago=7)

    # Inventory
    for name, qty, unit, mn, cost in [
        ("Detergent (5kg)", 12, "bag", 4, 850),
        ("Softener (5L)", 8, "bottle", 3, 600),
        ("Bleach (2L)", 5, "bottle", 2, 250),
        ("Packaging bags (large)", 320, "piece", 100, 8),
        ("Hangers", 180, "piece", 50, 12),
        ("Bags (fabric)", 45, "piece", 20, 90),
    ]:
        s.add(InventoryItem(business_id=b.id, name=name, quantity=qty,
                             unit=unit, min_level=mn, unit_cost=cost))
    s.commit()

    # Expenses
    for cat, amt, note in [
        ("Detergent", 1700, "Monthly restock"),
        ("Electricity", 4200, "KPLC token"),
        ("Water", 1200, "September"),
        ("Rent", 18000, "September rent"),
        ("Salaries", 35000, "Staff wages"),
        ("Delivery", 800, "Fuel"),
    ]:
        s.add(Expense(business_id=b.id, category=cat, amount=amt, note=note,
                       recorded_by=admin.id))
    s.commit()

    # Audit
    s.add(AuditLog(business_id=b.id, actor_id=admin.id,
                    action="business_created", entity_type="business", entity_id=b.id))
    s.commit()

    # Booking link
    import secrets
    from app.models import BookingLink
    link = BookingLink(business_id=b.id, token=secrets.token_urlsafe(16))
    s.add(link); s.commit()

    # ---------- Subscription ----------
    from app.models import Subscription, Partnership
    now = datetime.now(timezone.utc)
    s.add(Subscription(
        business_id=b.id, plan="standard", status="active",
        price_monthly=3000.0, currency="KES",
        started_at=now, current_period_start=now,
        current_period_end=now + timedelta(days=30),
        grace_days=7,
    ))

    # ---------- Demo partner business ----------
    b2 = Business(name="Aroma Perfume Shop", phone="0720000000",
                   address="Same mall as FreshFold", next_order_number=1,
                   workflow_stages=["received", "completed"])
    s.add(b2); s.commit(); s.refresh(b2)
    partner_owner = User(business_id=b2.id, name="Partner Owner",
                          phone="0720000001", role="admin",
                          api_key=new_api_key(),
                          password_hash=hash_password("partner123"))
    s.add(partner_owner); s.commit(); s.refresh(partner_owner)
    s.add(Subscription(
        business_id=b2.id, plan="starter", status="active",
        price_monthly=1500.0, currency="KES",
        started_at=now, current_period_start=now,
        current_period_end=now + timedelta(days=30),
    ))

    # Partnership: FreshFold refers customers to Aroma
    p = Partnership(
        from_business_id=b.id, to_business_id=b2.id,
        kind="referral", revenue_split_pct=10.0, status="active",
        terms="10% of first purchase from referred customer",
        created_by_id=admin.id,
    )
    s.add(p); s.commit(); s.refresh(p)

    s.commit()

print("Seeded.")
print(f"Booking link:  http://localhost:8000/book/{link.token}")
print(f"Customer app:  http://localhost:8000/customer?t={link.token}")
print("Partner login: 0720000001 / partner123 (Aroma Perfume Shop)")
print("Subscription:  FreshFold standard KES 3,000/mo")
print("Login: 0700000001 / admin123     (admin)")
print("       0700000002 / attendant123 (attendant)")
print("       0700000003 / attendant2123 (attendant)")
print("       0700000004 / attendant3123 (attendant)")
print("       0700000005 / rider123   (rider)")
