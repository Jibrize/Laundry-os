#!/usr/bin/env bash
# Minimal pre-commit: lint + fast tests. Install with:
#   ln -s ../../scripts/pre-commit.sh .git/hooks/pre-commit
set -e

echo "→ ruff"
ruff check app tests --fix >/dev/null
ruff format app tests >/dev/null

echo "→ fast tests"
pytest -q -x tests/test_money_path.py tests/test_multitenant.py

echo "✓ pre-commit passed"
