# Laundry OS v1 scope

Laundry OS v1 is intentionally small for the first real laundry pilot.

## Core roles
- Admin: full business control
- Attendant: orders, customers, payments and day-to-day laundry work
- Rider: assigned pickups/deliveries only
- Customer: separate customer account/channel

## Core workflow
Customer -> Order -> Count/Weight/Service -> Price -> Payment -> Work -> Ready -> Pickup/Delivery -> Completed.

## Keep in the foundation, but don't force into the first screen
- WhatsApp booking
- Customer booking/app
- Subscription/licensing
- Offline sync
- M-Pesa
- Reports
- Inventory/expenses
- Partnership integrations
- Multi-tenant isolation

Partnerships are not part of the laundry's core accounting or ownership. A perfume or other venture gets a separate agreement and can connect later.
