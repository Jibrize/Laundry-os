import os
import tempfile
from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, SQLModel, create_engine, select

# Set test env BEFORE importing app modules
os.environ["DATABASE_URL"] = "sqlite:///./test_laundryos.db"
os.environ["AUTO_CREATE_TABLES"] = "false"
os.environ["SECRET_SALT"] = "test-salt"

from app.db import engine, init_db, get_session  # noqa: E402
from app.main import app as fastapi_app  # noqa: E402
from app.models import Business, User, Customer, Service  # noqa: E402
from app.auth import hash_password, new_api_key  # noqa: E402

@pytest.fixture(autouse=True)
def fresh_db():
    """Drop and recreate all tables before every test."""
    SQLModel.metadata.drop_all(engine)
    SQLModel.metadata.create_all(engine)
    yield
    SQLModel.metadata.drop_all(engine)

def _make_business(session, name: str = "Test Laundry"):
    b = Business(name=name, phone="0700000000",
                  workflow_stages=["received", "washing", "ready", "completed"],
                  next_order_number=1000)
    session.add(b)
    session.commit()
    session.refresh(b)
    return b

def _make_owner(session, business_id: int, phone: str = "0700000001"):
    u = User(business_id=business_id, name="Owner", phone=phone, role="owner",
             api_key=new_api_key(), password_hash=hash_password("owner123"))
    session.add(u)
    session.commit()
    session.refresh(u)
    return u

def _make_service(session, business_id: int, name: str = "Wash + Fold",
                    measurement: str = "kg", price: float = 120.0,
                    min_charge: float = 200.0):
    s = Service(business_id=business_id, name=name, measurement=measurement,
                 price=price, min_charge=min_charge)
    session.add(s)
    session.commit()
    session.refresh(s)
    return s

@pytest.fixture
def client():
    """FastAPI test client against the same sqlite file the app uses."""
    with TestClient(fastapi_app) as c:
        yield c

@pytest.fixture
def db_session():
    with Session(engine) as s:
        yield s

@pytest.fixture
def business_and_key(db_session):
    b = _make_business(db_session)
    u = _make_owner(db_session, b.id)
    return b, u.api_key

@pytest.fixture
def second_business_and_key(db_session):
    b = _make_business(db_session, name="Second Laundry")
    u = _make_owner(db_session, b.id, phone="0700999999")
    return b, u.api_key

@pytest.fixture
def service(db_session, business_and_key):
    b, _ = business_and_key
    return _make_service(db_session, b.id)
