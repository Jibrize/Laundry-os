"""
M-Pesa callback idempotency: Daraja retries callbacks. One successful callback
per checkout ID must result in exactly one Payment row.
"""
import json
from app.models import MpesaPayment, Order, Payment

def _headers(key):
    return {"x-api-key": key}

def _create_order(client, key, service_id, phone="0714000001"):
    r = client.post("/api/orders", json={
        "customer_name": "M-Pesa Customer", "customer_phone": phone,
        "items": [{"service_id": service_id, "quantity": 5.0}],
    }, headers=_headers(key))
    assert r.status_code == 200
    return r.json()["order"]

def _stk_callback_body(checkout_id: str, receipt: str, amount: int = 600):
    return {
        "Body": {"stkCallback": {
            "MerchantRequestID": "M-1",
            "CheckoutRequestID": checkout_id,
            "ResultCode": 0,
            "ResultDesc": "The service request is processed successfully.",
            "CallbackMetadata": {"Item": [
                {"Name": "Amount", "Value": amount},
                {"Name": "MpesaReceiptNumber", "Value": receipt},
                {"Name": "TransactionDate", "Value": 20260920120000},
                {"Name": "PhoneNumber", "Value": 254714000001},
            ]},
        }}
    }

def test_duplicate_callback_creates_one_payment(db_session, client,
                                                  business_and_key, service):
    b, key = business_and_key
    o = _create_order(client, key, service.id, phone="0714000001")

    # Simulate STK push record (mock mode creates it as success already,
    # so we'll insert a pending one directly to test the callback path)
    from datetime import datetime, timezone
    rec = MpesaPayment(
        business_id=b.id, order_id=o["id"],
        checkout_request_id="CHECKOUT-TEST-1",
        phone="254714000001", amount=600.0, status="pending",
    )
    db_session.add(rec); db_session.commit(); db_session.refresh(rec)

    body = _stk_callback_body("CHECKOUT-TEST-1", "QKABC123", 600)

    # First callback → success
    r = client.post("/api/mpesa/callback", json=body)
    assert r.status_code == 200

    db_session.expire_all()
    rec = db_session.query(MpesaPayment).filter(
        MpesaPayment.checkout_request_id == "CHECKOUT-TEST-1").first()
    assert rec.status == "success"
    assert rec.mpesa_receipt == "QKABC123"

    payments_before = db_session.query(Payment).filter(
        Payment.order_id == o["id"]).all()
    assert len(payments_before) == 1
    assert payments_before[0].amount == 600.0
    assert payments_before[0].reference == "QKABC123"

    # Second callback (retry) → must be ignored
    r = client.post("/api/mpesa/callback", json=body)
    assert r.status_code == 200

    db_session.expire_all()
    payments_after = db_session.query(Payment).filter(
        Payment.order_id == o["id"]).all()
    assert len(payments_after) == 1, "Duplicate callback created a second payment"

    # Order balance unchanged after retry
    order = db_session.get(Order, o["id"])
    assert order.amount_paid == 600.0
    assert order.balance == 0.0

def test_failed_callback_marks_failed_no_payment(db_session, client,
                                                   business_and_key, service):
    b, key = business_and_key
    o = _create_order(client, key, service.id, phone="0714000002")

    from datetime import datetime, timezone
    rec = MpesaPayment(
        business_id=b.id, order_id=o["id"],
        checkout_request_id="CHECKOUT-TEST-2",
        phone="254714000002", amount=600.0, status="pending",
    )
    db_session.add(rec); db_session.commit()

    body = {"Body": {"stkCallback": {
        "CheckoutRequestID": "CHECKOUT-TEST-2",
        "ResultCode": 1032,
        "ResultDesc": "Request cancelled by user",
    }}}
    r = client.post("/api/mpesa/callback", json=body)
    assert r.status_code == 200

    db_session.expire_all()
    rec = db_session.query(MpesaPayment).filter(
        MpesaPayment.checkout_request_id == "CHECKOUT-TEST-2").first()
    assert rec.status == "cancelled"

    payments = db_session.query(Payment).filter(
        Payment.order_id == o["id"]).all()
    assert payments == []

    order = db_session.get(Order, o["id"])
    assert order.amount_paid == 0.0

def test_unknown_callback_ignored(client):
    """A callback for an unknown checkout ID must be a no-op, not a 500."""
    body = _stk_callback_body("NEVER-SEEN", "QKXYZ", 100)
    r = client.post("/api/mpesa/callback", json=body)
    assert r.status_code == 200
