"""
Money path: create order → record payment → balance math is correct.
Covers the most common way a shop loses money: order totals or balances drift.
"""
from app.models import Service, Order, Payment

def _headers(key):
    return {"x-api-key": key}

def test_order_create_computes_subtotal_total_balance(db_session, client, business_and_key, service):
    b, key = business_and_key
    # service: kg @ 120, min_charge 200
    # 8.4 kg → 1008 (above min)
    payload = {
        "customer_name": "Test Customer",
        "customer_phone": "0712000001",
        "items": [{"service_id": service.id, "quantity": 8.4}],
        "delivery_method": "pickup",
        "delivery_fee": 0.0,
    }
    r = client.post("/api/orders", json=payload, headers=_headers(key))
    assert r.status_code == 200, r.text
    data = r.json()
    o = data["order"]
    assert o["subtotal"] == 1008.0
    assert o["total"] == 1008.0
    assert o["amount_paid"] == 0.0
    assert o["balance"] == 1008.0
    assert o["payment_status"] == "unpaid"

def test_min_charge_applies(db_session, client, business_and_key, service):
    b, key = business_and_key
    # 0.5 kg * 120 = 60, below min_charge 200 → 200
    payload = {
        "customer_name": "Small Load",
        "customer_phone": "0712000002",
        "items": [{"service_id": service.id, "quantity": 0.5}],
    }
    r = client.post("/api/orders", json=payload, headers=_headers(key))
    assert r.status_code == 200
    assert r.json()["order"]["subtotal"] == 200.0

def test_partial_payment_updates_balance(db_session, client, business_and_key, service):
    b, key = business_and_key
    payload = {
        "customer_name": "Partial Payer",
        "customer_phone": "0712000003",
        "items": [{"service_id": service.id, "quantity": 10.0}],
    }
    r = client.post("/api/orders", json=payload, headers=_headers(key))
    oid = r.json()["order"]["id"]

    r = client.post(f"/api/orders/{oid}/payments", json={
        "amount": 500.0, "method": "cash",
    }, headers=_headers(key))
    assert r.status_code == 200
    o = r.json()["order"]
    assert o["amount_paid"] == 500.0
    assert o["balance"] == 700.0  # 1200 - 500
    assert o["payment_status"] == "partial"

def test_overpayment_rejected_when_no_credit(db_session, client, business_and_key, service):
    b, key = business_and_key
    payload = {
        "customer_name": "Over Payer",
        "customer_phone": "0712000004",
        "items": [{"service_id": service.id, "quantity": 5.0}],
    }
    r = client.post("/api/orders", json=payload, headers=_headers(key))
    oid = r.json()["order"]["id"]  # total 600

    # Try to pay 700 on a 600 balance
    r = client.post(f"/api/orders/{oid}/payments", json={
        "amount": 700.0, "method": "cash",
    }, headers=_headers(key))
    assert r.status_code == 400
    assert "exceed" in r.text.lower()

def test_full_payment_marks_paid(db_session, client, business_and_key, service):
    b, key = business_and_key
    payload = {
        "customer_name": "Full Payer",
        "customer_phone": "0712000005",
        "items": [{"service_id": service.id, "quantity": 5.0}],
    }
    r = client.post("/api/orders", json=payload, headers=_headers(key))
    oid = r.json()["order"]["id"]

    r = client.post(f"/api/orders/{oid}/payments", json={
        "amount": 600.0, "method": "mpesa", "reference": "QK123",
    }, headers=_headers(key))
    assert r.status_code == 200
    o = r.json()["order"]
    assert o["balance"] == 0.0
    assert o["payment_status"] == "paid"

def test_delivery_fee_lands_in_total(db_session, client, business_and_key, service):
    b, key = business_and_key
    payload = {
        "customer_name": "Delivery Customer",
        "customer_phone": "0712000006",
        "items": [{"service_id": service.id, "quantity": 5.0}],
        "delivery_method": "delivery",
        "delivery_fee": 200.0,
        "delivery_address": "Somewhere",
    }
    r = client.post("/api/orders", json=payload, headers=_headers(key))
    assert r.status_code == 200
    o = r.json()["order"]
    assert o["subtotal"] == 600.0
    assert o["delivery_fee"] == 200.0
    assert o["total"] == 800.0
    assert o["balance"] == 800.0
