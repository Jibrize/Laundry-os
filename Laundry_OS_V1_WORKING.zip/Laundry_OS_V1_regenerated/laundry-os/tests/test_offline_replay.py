"""
Offline sync replay: the cashier's browser may queue an order, go offline,
come back, and replay the same batch twice. Only one order must be created.
"""
from app.models import IdempotencyKey, Order

def _headers(key):
    return {"x-api-key": key}

def _payload(service_id, phone="0715000001"):
    return {
        "customer_name": "Offline Customer",
        "customer_phone": phone,
        "items": [{"service_id": service_id, "quantity": 5.0}],
        "delivery_method": "pickup",
    }

def test_idempotent_order_create_second_call_returns_same(db_session, client,
                                                            business_and_key,
                                                            service):
    b, key = business_and_key
    key_str = "idem-key-1"

    body = {
        "idempotency_key": key_str,
        "payload": _payload(service.id),
    }

    r1 = client.post("/api/orders/idempotent", json=body, headers=_headers(key))
    assert r1.status_code == 200, r1.text
    o1 = r1.json()["order"]
    assert o1["code"]

    # Same idempotency key, same payload — replay
    r2 = client.post("/api/orders/idempotent", json=body, headers=_headers(key))
    assert r2.status_code == 200
    o2 = r2.json()["order"]

    assert o1["id"] == o2["id"], "Idempotent replay created a second order"

    orders = db_session.query(Order).filter(Order.business_id == b.id).all()
    assert len(orders) == 1

def test_batch_replay_across_two_keys_creates_two_orders(db_session, client,
                                                            business_and_key,
                                                            service):
    b, key = business_and_key

    for i in range(2):
        body = {
            "idempotency_key": f"idem-key-{i}",
            "payload": _payload(service.id, phone=f"07150000{i:02d}"),
        }
        r = client.post("/api/orders/idempotent", json=body, headers=_headers(key))
        assert r.status_code == 200

    orders = db_session.query(Order).filter(Order.business_id == b.id).all()
    assert len(orders) == 2

def test_idempotency_key_is_recorded(db_session, client, business_and_key, service):
    b, key = business_and_key
    body = {
        "idempotency_key": "idem-recorded",
        "payload": _payload(service.id),
    }
    client.post("/api/orders/idempotent", json=body, headers=_headers(key))

    keys = db_session.query(IdempotencyKey).filter(
        IdempotencyKey.business_id == b.id).all()
    assert len(keys) == 1
    assert keys[0].key == "idem-recorded"
    assert keys[0].action == "order.create"

def test_offline_payload_from_other_business_fails(client, db_session,
                                                     business_and_key,
                                                     second_business_and_key,
                                                     service):
    """Cross-tenant replay must not succeed."""
    b1, key1 = business_and_key
    b2, key2 = second_business_and_key
    # service belongs to B1

    body = {
        "idempotency_key": "cross-tenant-attempt",
        "payload": _payload(service.id),
    }
    r = client.post("/api/orders/idempotent", json=body, headers=_headers(key2))
    # Service not found in B2 → error
    assert r.status_code == 400
