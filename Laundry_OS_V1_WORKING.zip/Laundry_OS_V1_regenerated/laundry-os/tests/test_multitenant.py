"""
Multi-tenant isolation: laundry A must never see, modify, or pay laundry B's data.
If this test suite fails, you have a data leak between customers.
"""
from app.models import Order, Customer

def _headers(key):
    return {"x-api-key": key}

def _create_customer_and_order(client, key, phone="0713000001", name="Cust A"):
    r = client.post("/api/customers", json={
        "full_name": name, "phone": phone,
    }, headers=_headers(key))
    assert r.status_code == 200, r.text
    cid = r.json()["id"]
    return cid

def test_order_list_is_scoped_by_business(client, db_session,
                                            business_and_key,
                                            second_business_and_key,
                                            service):
    b1, key1 = business_and_key
    b2, key2 = second_business_and_key

    # B1 creates an order
    r = client.post("/api/orders", json={
        "customer_name": "B1 Customer", "customer_phone": "0713000001",
        "items": [{"service_id": service.id, "quantity": 5.0}],
    }, headers=_headers(key1))
    assert r.status_code == 200
    b1_order_id = r.json()["order"]["id"]

    # B2 lists orders — must see nothing
    r = client.get("/api/orders", headers=_headers(key2))
    assert r.status_code == 200
    assert r.json() == []

    # B2 attempts to fetch B1's order directly — must 404
    r = client.get(f"/api/orders/{b1_order_id}", headers=_headers(key2))
    assert r.status_code == 404

def test_customer_list_is_scoped(client, db_session,
                                    business_and_key,
                                    second_business_and_key):
    b1, key1 = business_and_key
    b2, key2 = second_business_and_key

    _create_customer_and_order(client, key1, phone="0713000010", name="Alice")

    r = client.get("/api/customers", headers=_headers(key2))
    assert r.status_code == 200
    assert r.json() == []

def test_cross_tenant_payment_rejected(client, db_session,
                                         business_and_key,
                                         second_business_and_key,
                                         service):
    b1, key1 = business_and_key
    b2, key2 = second_business_and_key

    r = client.post("/api/orders", json={
        "customer_name": "B1 Customer", "customer_phone": "0713000020",
        "items": [{"service_id": service.id, "quantity": 5.0}],
    }, headers=_headers(key1))
    b1_order_id = r.json()["order"]["id"]

    # B2 tries to record payment against B1's order
    r = client.post(f"/api/orders/{b1_order_id}/payments", json={
        "amount": 100.0, "method": "cash",
    }, headers=_headers(key2))
    assert r.status_code == 404

def test_cross_tenant_service_rejected(client, db_session,
                                         business_and_key,
                                         second_business_and_key,
                                         service):
    """B2 cannot create an order using B1's service."""
    b1, key1 = business_and_key
    b2, key2 = second_business_and_key

    # service belongs to B1
    r = client.post("/api/orders", json={
        "customer_name": "Cross Tenant",
        "customer_phone": "0713000030",
        "items": [{"service_id": service.id, "quantity": 5.0}],
    }, headers=_headers(key2))
    assert r.status_code == 400
    assert "not found" in r.text.lower()

def test_missing_key_unauthorized(client):
    r = client.get("/api/orders")
    assert r.status_code == 401

def test_invalid_key_unauthorized(client):
    r = client.get("/api/orders", headers=_headers("nonsense"))
    assert r.status_code == 401
