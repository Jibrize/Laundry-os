const API_KEY = localStorage.getItem("rider_key") || "";
const el = (id) => document.getElementById(id);
const esc = (s) => (s ?? "").toString().replace(/[&<>"']/g,
  c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));

const state = { view: "jobs", jobs: [], done: [], me: null };

async function api(path, opts = {}) {
  const headers = { "Content-Type": "application/json",
                    "x-api-key": API_KEY, ...(opts.headers || {}) };
  const res = await fetch(path, { ...opts, headers });
  if (res.status === 401) { loginScreen(); throw new Error("unauth"); }
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

function loginScreen() {
  el("tabs").innerHTML = "";
  el("main").innerHTML = `
    <div class="card">
      <h3>Sign in as rider</h3>
      <label>Phone</label><input id="r_phone" />
      <label>Password</label><input id="r_pass" type="password" />
      <button class="primary" style="margin-top:12px" onclick="doLogin()">Sign in</button>
    </div>`;
}

window.doLogin = async function () {
  const res = await fetch("/api/auth/login", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: el("r_phone").value, password: el("r_pass").value }),
  });
  if (!res.ok) { alert(await res.text()); return; }
  const data = await res.json();
  if (data.user.role !== "rider" && data.user.role !== "manager" && data.user.role !== "owner") {
    alert("This app is for riders."); return;
  }
  localStorage.setItem("rider_key", data.api_key);
  location.reload();
};

const TABS = [
  { id: "jobs", label: "Jobs" },
  { id: "done", label: "Done" },
  { id: "me", label: "Me" },
];

function renderTabs() {
  const nav = el("tabs"); nav.innerHTML = "";
  TABS.forEach(t => {
    const b = document.createElement("button");
    b.className = state.view === t.id ? "active" : "";
    b.textContent = t.label;
    b.onclick = () => { state.view = t.id; render(); };
    nav.appendChild(b);
  });
}

async function loadJobs() {
  state.jobs = await api("/api/deliveries/me");
  state.done = await api("/api/deliveries?status=delivered").catch(() => []);
}

function viewJobs() {
  return `
    ${state.jobs.map(j => `
      <div class="card">
        <div class="row">
          <div style="flex:1">
            <h3>${esc(j.order_code || '')} · ${esc(j.kind)}</h3>
            <div class="muted">${esc(j.customer_name || '')}</div>
            <div class="muted">${esc(j.address || '')}</div>
          </div>
          <span class="chip ${j.status}">${esc(j.status)}</span>
        </div>
        <div class="actions">
          ${j.phone ? `<a href="tel:${esc(j.phone)}"><button class="ghost sm">📞 Call</button></a>` : ""}
          ${j.address ? `<a href="https://maps.google.com/?q=${encodeURIComponent(j.address)}" target="_blank"><button class="ghost sm">🗺 Map</button></a>` : ""}
          <button class="ghost sm" onclick="setStatus(${j.id},'picked_up')">Picked up</button>
          <button class="ghost sm" onclick="setStatus(${j.id},'out_for_delivery')">Out for delivery</button>
          <button class="ok sm" onclick="setStatus(${j.id},'delivered')">Delivered</button>
        </div>
      </div>`).join("") || `<div class="card"><div class="muted">No jobs today.</div></div>`}`;
}

function viewDone() {
  return `
    ${state.done.slice(0, 20).map(j => `
      <div class="card">
        <div class="muted">${esc(j.order_code || '')} · ${esc(j.customer_name || '')} · ${esc(j.status)}</div>
      </div>`).join("") || `<div class="card"><div class="muted">No completed deliveries yet.</div></div>`}`;
}

function viewMe() {
  return `
    <div class="card">
      <h3>${esc(state.me?.name || '')}</h3>
      <div class="muted">${esc(state.me?.role || '')}</div>
      <button class="ghost sm" style="margin-top:8px" onclick="logout()">Sign out</button>
    </div>`;
}

window.setStatus = async function (id, s) {
  try {
    await api(`/api/deliveries/${id}`, { method: "PATCH",
      body: JSON.stringify({ status: s }) });
    await loadJobs(); render();
  } catch (e) { alert(e.message); }
};

window.logout = () => { localStorage.removeItem("rider_key"); location.reload(); };

async function render() {
  renderTabs();
  const main = el("main");
  if (state.view === "jobs") main.innerHTML = viewJobs();
  else if (state.view === "done") main.innerHTML = viewDone();
  else if (state.view === "me") main.innerHTML = viewMe();
  const online = navigator.onLine;
  el("net").textContent = online ? "online" : "offline";
  el("net").className = "net" + (online ? "" : " offline");
}

if ("serviceWorker" in navigator)
  navigator.serviceWorker.register("/rider/sw.js").catch(() => {});

(async function init() {
  if (!API_KEY) { loginScreen(); return; }
  try {
    state.me = await api("/api/auth/me");
    await loadJobs();
    render();
    setInterval(async () => { try { await loadJobs(); render(); } catch {} }, 20000);
  } catch { loginScreen(); }
})();
